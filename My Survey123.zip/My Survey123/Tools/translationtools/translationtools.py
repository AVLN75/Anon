#!/usr/bin/python3
# -------------------------------------------------------------------------------
# Copyright 2025 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# -------------------------------------------------------------------------------

import requests
import json
import os
import tempfile
import zipfile
import openpyxl
from copy import copy
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table
import unicodedata
import re

# -------------------------------------------------------------------------------


class TranslationTools:
    """Common tools used by the import/export/auto-translate Survey123 Connect tools"""

    def __init__(self, strings, apiurl):
        """Constructor"""
        self._strings = strings
        self._baseurl = f"{apiurl}"

    # -------------------------------------------------------------------------------

    def export(self, file, xlsform, path, portalurl, token, dir) -> str:
        """ /export API call """

        def extractZIP(filename, folder):
            zfile = zipfile.ZipFile(filename)
            zfile.extractall(folder)

        url = f"{self._baseurl}/translation/export"

        files = [
            ('xlsForm', (file,
                         open(xlsform, 'rb'),
                         'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'))
        ]

        try:
            response = requests.request("POST", url, headers={
                                        "X-Esri-Authorization": f"Bearer {token}"}, data={'portalUrl': portalurl}, files=files)
        except requests.exceptions.ConnectionError:
            return self._strings['connectionError']

        try:
            if response.json()['error']['message']:
                return response.json()['error']['message']
        except json.decoder.JSONDecodeError:
            tmpdir = tempfile.TemporaryDirectory()
            tmp_zip = os.path.join(tmpdir.name, "translation.zip")

            with open(tmp_zip, 'wb') as fd:
                for chunk in response.iter_content(chunk_size=128):
                    fd.write(chunk)
            try:
                extractZIP(tmp_zip, path)
            except PermissionError:
                return self._strings['translationFileOpen']

            return self._strings['html_string'].format(html_dir=dir, path=path)

    # -------------------------------------------------------------------------------

    def merge(self, xlsform, translation_zip, portalurl, token):
        """ /merge API call """
        path, file = os.path.split(translation_zip)
        url = f"{self._baseurl}/translation/merge"
        files = [
            ('file', (file,
                      open(translation_zip,
                           'rb'), 'application/zip'))
        ]

        try:
            response = requests.request("POST", url, headers={
                                        "X-Esri-Authorization": f"Bearer {token}"}, data={'portalUrl': portalurl}, files=files)
        except requests.exceptions.ConnectionError:
            print(self._strings['connectionError'])
            exit()

        try:
            if response.json()['error']['message']:
                print(response.json()['error']['message'])
                return response.json()['error']['message']
        except KeyError:
            return self._maptranslations(xlsform, response.json())

    # -------------------------------------------------------------------------------

    def auto_translate(self, xlsform, portalurl, token, dir, root_path):
        """ Auto translate /translate API call"""
        with open(os.path.join(root_path, "env.config"), 'r') as env_config:
            url = json.load(env_config)['translationUrl']

        params = self._gen_params(xlsform)
        if not (isinstance(params, tuple)):
            print(params)
            exit()
        if len(params[1]['string']) == 0:
            print(self._strings['noLocales'].format(html_dir = dir))
            exit()

        try:
            response = requests.request("POST", url, headers={"X-Esri-Authorization": f"Bearer {token}", "Content-Type": "application/json", "x-esri-request-source": "Survey123/Connect"},
                                        data=json.dumps({'portalUrl': portalurl, 'to': params[1]['string'], 'contents': params[0]}))
        except requests.exceptions.ConnectionError:
            print(self._strings['connectionError'])
            exit()

        try:
            if response.json()['error']['message']:
                print(response.json()['error']['message'])
                return response.json()['error']['message']
        except KeyError:
            results = {
                "locales": params[1]['locales'],
                "data": response.json()['results']
            }

            return self._maptranslations(xlsform, results)

    # -------------------------------------------------------------------------------

    def _gen_survey_key(self, ws, ws_header):
        """ Generate reference keys for the `survey` worksheet """
        survey_key = {}
        base = '#/'
        for q_type, q_name in zip(ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=ws_header.index('type') + 1,
                                               max_col=ws_header.index('type') + 1),
                                  ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=ws_header.index('name') + 1,
                                               max_col=ws_header.index('name') + 1)):
            if q_type[0].value != 'begin repeat' and q_type[0].value != 'end repeat' and q_type[
                    0].value is not None and q_type[0].value != 'begin group' and q_type[0].value != 'end group':
                if q_name[0].value is None or q_name[0].value == "":
                    survey_key.update(
                        {base + f'questions["generated_note_name_{q_type[0].row}"]': q_type[0].row})
                else:
                    survey_key.update(
                        {base + f'questions["{unicodedata.normalize("NFKD", str(q_name[0].value)).strip()}"]': q_type[0].row})
            elif q_type[0].value == 'begin repeat' or q_type[0].value == 'begin group':
                survey_key.update(
                    {base + f'questions["{unicodedata.normalize("NFKD", str(q_name[0].value)).strip()}"]': q_type[0].row})
                base = base + \
                    f'questions["{unicodedata.normalize("NFKD", str(q_name[0].value)).strip()}"]/'
            elif q_type[0].value == 'end repeat' or q_type[0].value == 'end group':
                b_list = base.split('/')
                del b_list[-2:]
                base = '/'.join(b_list) + '/'

        return survey_key

    # -------------------------------------------------------------------------------

    def _gen_choice_key(self, ws, ws_header):
        """ Generate reference keys for the `choices` worksheet """
        choice_key = {}
        for cl_name, c_name in zip(
                ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=ws_header.index('list_name') + 1,
                             max_col=ws_header.index('list_name') + 1),
                ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=ws_header.index('name') + 1,
                             max_col=ws_header.index('name') + 1)):
            if cl_name[0].value is not None:
                choice_key.update(
                    {f'#/choicelists["{unicodedata.normalize("NFKD", str(cl_name[0].value)).strip()}"]/choices["{unicodedata.normalize("NFKD", str(c_name[0].value)).strip()}"]': cl_name[0].row})

        return choice_key

    # -------------------------------------------------------------------------------

    def _map_strings(self, wb, loc, data):
        """ Map translation strings in XLSForm """

        rebuild_table = False

        s_worksheet = wb['survey']
        s_ws_header = [x.value for x in s_worksheet[1]]
        survey_key = self._gen_survey_key(s_worksheet, s_ws_header)
        c_worksheet = wb['choices']
        c_ws_header = [x.value for x in c_worksheet[1]]
        choice_key = self._gen_choice_key(c_worksheet, c_ws_header)

        for row in data:
            value = row['translation'][loc['code']]
            row_list = row['key'].split("/")
            column = f"{row_list.pop()}::{loc['fullText']}"
            key = '/'.join(row_list)

            if 'questions' in row_list[1]:
                try:
                    col_idx = s_ws_header.index(column) + 1
                except ValueError:
                    col_idx = s_worksheet.max_column + 1
                    # s_worksheet.insert_cols(col_idx)
                    ft = copy(s_worksheet.cell(row=1, column=col_idx-1).font)
                    fill = copy(s_worksheet.cell(row=1, column=col_idx-1).fill)
                    s_worksheet.cell(row=1, column=col_idx).value = column
                    s_worksheet.cell(row=1, column=col_idx).font = ft
                    s_worksheet.cell(row=1, column=col_idx).fill = fill
                    s_worksheet.cell(row=1, column=col_idx).alignment = Alignment(
                        horizontal="center")
                    s_worksheet.column_dimensions[get_column_letter(
                        col_idx)].width = (len(column) + 2) * 1.2
                    s_ws_header = [x.value for x in s_worksheet[1]]
                    rebuild_table = True
                s_worksheet.cell(
                    row=survey_key[key], column=col_idx).value = value
            elif 'choicelists' in row_list[1]:
                try:
                    col_idx = c_ws_header.index(column) + 1
                except ValueError:
                    col_idx = c_worksheet.max_column + 1
                    # c_worksheet.insert_cols(col_idx)
                    ft = copy(c_worksheet.cell(row=1, column=col_idx - 1).font)
                    fill = copy(c_worksheet.cell(
                        row=1, column=col_idx - 1).fill)
                    c_worksheet.cell(row=1, column=col_idx).value = column
                    c_worksheet.cell(row=1, column=col_idx).font = ft
                    c_worksheet.cell(row=1, column=col_idx).fill = fill
                    c_worksheet.cell(row=1, column=col_idx).alignment = Alignment(
                        horizontal="center")
                    c_worksheet.column_dimensions[get_column_letter(
                        col_idx)].width = (len(column) + 2) * 1.2
                    c_ws_header = [x.value for x in c_worksheet[1]]
                c_worksheet.cell(
                    row=choice_key[key], column=col_idx).value = value

        if rebuild_table:
            if None in s_ws_header:
                val = " "
                for idx, hr in enumerate(s_ws_header):
                    if hr is None:
                        s_worksheet.cell(row=1,column=idx+1).value = val
                        val = val + " "
            self._rebuild_table(s_worksheet)

    # -------------------------------------------------------------------------------

    def _maptranslations(self, xlsform, translation_json):
        """ Map translations to XLSForm  """
        wb = openpyxl.load_workbook(xlsform)
        for locale in translation_json['locales']:
            try:
                if locale['isDefault'] is True:
                    pass
                else:
                    self._map_strings(wb, locale, translation_json['data'])
            except KeyError:
                self._map_strings(wb, locale, translation_json['data'])
        self._rebuild_datavalidation(wb)
        wb.save(xlsform)
        wb.close()
        return xlsform

    # -------------------------------------------------------------------------------

    def _rebuild_table(self, ws):
        """ Rebuild the survey worksheet table if new columns have been added """

        try:
            # Find the table name
            ws_table = ws.tables.items()[0][0]
            # Connect to the table
            my_table = ws.tables[ws_table]
            # Obtain the table style info
            my_table_style = my_table.tableStyleInfo
            # Delete the table
            del ws.tables[ws_table]

        except IndexError:
            pass

        try:
            # Define a new table given the new columns added, setting the headerRowCount to 0 disables the filters
            if ws.max_row > 150:
                tab_rows = ws.max_row
            else:
                tab_rows = 150
            tab = Table(displayName="{}".format(ws_table),
                        ref="$A$1:${}${}".format(get_column_letter(ws.max_column), tab_rows), headerRowCount=1)
            # Style it the same as the old table
            tab.tableStyleInfo = my_table_style
            # Create the table
            ws.add_table(tab)
        except:
            pass

    # -------------------------------------------------------------------------------

    def _rebuild_datavalidation(self, workbook):
        """ Rebuild the data validation in the XLSForm """
        ws = ["survey", "settings"]
        for worksheet in ws:
            current_ws = workbook[worksheet]
            if worksheet == "survey":
                # type column
                current_ws.data_validations.dataValidation[0].showErrorMessage = False
                current_ws.data_validations.dataValidation[0].showInputMessage = False
                current_ws.data_validations.dataValidation[0].allowBlank = True
                # name column
                current_ws.data_validations.dataValidation[1].showInputMessage = False
                current_ws.data_validations.dataValidation[1].allowBlank = True
                # appearance column
                current_ws.data_validations.dataValidation[6].showErrorMessage = False
                current_ws.data_validations.dataValidation[6].showInputMessage = False
                current_ws.data_validations.dataValidation[6].allowBlank = True
                # required & read only columns
                current_ws.data_validations.dataValidation[2].showErrorMessage = False
                current_ws.data_validations.dataValidation[2].showInputMessage = False
                current_ws.data_validations.dataValidation[2].allowBlank = True
                # bind::type column
                current_ws.data_validations.dataValidation[3].showInputMessage = False
                current_ws.data_validations.dataValidation[3].allowBlank = True
                # bind::esri:fieldType column
                current_ws.data_validations.dataValidation[4].showInputMessage = False
                current_ws.data_validations.dataValidation[4].allowBlank = True
                # bind::esri:fieldLength column
                current_ws.data_validations.dataValidation[5].showInputMessage = False
                current_ws.data_validations.dataValidation[5].allowBlank = True
            elif worksheet == "settings":
                # style column
                current_ws.data_validations.dataValidation[0].showErrorMessage = False
                current_ws.data_validations.dataValidation[0].showInputMessage = False
                current_ws.data_validations.dataValidation[0].allowBlank = True

    # -------------------------------------------------------------------------------

    def _gen_params(self, xlsform):
        """ Generates the form-data to be sent to the /translate API endpoint """
        path, file = os.path.split(xlsform)
        url = f"{self._baseurl}/xls2json"
        files = [
            ('xlsform', (file,
                         open(xlsform, 'rb'),
                         'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'))
        ]
        try:
            response = requests.request(
                "POST", url, data={'f': 'json'}, files=files)
        except requests.exceptions.ConnectionError:
            return self._strings['connectionError']

        if response.json()['success'] is False:
            return response.json()['error']['message']

        default_language = response.json()['json']['default_language']
        # Language needs to be a string of comma seperated locales ex. "ar, de, zh-cn"
        # Contents needs to be list of dictionaries set up as [{"key": "id1", "text": "test"}]
        return self._gen_contents(response.json()['json']['children'], default_language, [], "#/", [])

    # -------------------------------------------------------------------------------

    def _gen_contents(self, children, default_language, contents, base, lang_list):
        """ Generates the contents parameter based on fields """
        for question in children:
            type = question.pop('type')
            name = question.pop('name')
            if name == 'meta':
                continue
            bind = question.pop('bind')
            for esri_col in bind:
                if esri_col == 'jr:constraintMsg':
                    question.update({"constraint_message": bind[esri_col]})
                elif esri_col == 'jr:requiredMsg':
                    question.update({"required_message": bind[esri_col]})

            for non_lang_key in ['esri:warning', 'esri:fieldLength', 'esri:workflow', 'saveIncomplete', 'esri:fieldAlias', 'esri:parameters', 'esri:warning_message', 'type', 'default', 'control']:
                if non_lang_key in question:
                    del question[non_lang_key]

            for col in question.keys():
                if default_language in question[col] and question[col][default_language] != '':
                    [lang_list.append(x) for x in question[col] if x not in lang_list and x !=
                     default_language and x != 'language (xx)']
                    contents.append(
                        {"key": f'{base}questions["{name}"]/{col}', "text": question[col][default_language]})
                elif col != 'choices' and type != "repeat":
                    if "image" in question[col] and "audio" in question[col]:
                        for media in question[col]:
                            [lang_list.append(
                                x) for x in question[col][media] if x not in lang_list and x != default_language and x != 'language (xx)']

                if col == 'choices':
                    choice_list_name = question['choicesListName']
                    for choice in question[col]:
                        choice_name = choice.pop('name')
                        for choice_col in choice.keys():
                            if default_language in choice[choice_col] and choice[choice_col][default_language] != '':
                                [lang_list.append(
                                    x) for x in choice[choice_col] if x not in lang_list and x != default_language and x != 'language (xx)']
                                contents.append(
                                    {"key": f'#/choicelists["{choice_list_name}"]/choices["{choice_name}"]/{choice_col}', "text": choice[choice_col][default_language]})
                            else:
                                for media in choice[choice_col]:
                                    [lang_list.append(
                                        x) for x in choice[choice_col][media] if x not in lang_list and x != default_language and x != 'language (xx)' and re.search(r'\([^?!.*(.).*\1]*\)', x)]

            if type == 'repeat' or type == 'group':
                self._gen_contents(
                    question['children'], default_language, contents, f'{base}questions["{name}"]/', lang_list)

        result = {
            "locales": [{"fullText": x, "code": x[x.index("(")+1:x.index(")")], "isDefault": False} for x in lang_list],
            "string": ",".join([x[x.index("(")+1:x.index(")")] for x in lang_list])
        }
        return (contents, result)
