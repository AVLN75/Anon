# New XLSPalette template

Create a new Survey123 XLSPalette template file in the media folder.

## Prerequisites

### Python 3.9 
* Windows Store: https://www.microsoft.com/en-us/p/python-39/9p7qfqmjrfp7
* Python website: https://www.python.org/downloads/

### Python Packages
* `python3 -m pip install chardet`

## Usage

`python3 new_xlspalette_template.py -i <surveyPath>`
