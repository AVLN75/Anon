#!/usr/bin/python3
#-------------------------------------------------------------------------------
# Copyright 2023 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#-------------------------------------------------------------------------------

import argparse
import os
import shutil
import sys
import json
dir_path = os.path.split(os.path.dirname(os.path.realpath(__file__)))[0]
sys.path.insert(0, os.path.join(dir_path, 'i18n_tools'))
from i18n import i18nTools

sys.stdout = open(1, 'w', encoding='utf-8', closefd=False)

#-------------------------------------------------------------------------------

def copy_template(media_folder, local_template, strings):
    i = 1
    while os.path.exists(os.path.join(media_folder, f"myXLSPalette{str(i)}.xlsx")):
        i+=1
    new_template = f"myXLSPalette{str(i)}.xlsx"
    shutil.copy(local_template, os.path.join(media_folder, new_template))
    print(strings['completedExitMessage'], new_template)

#-------------------------------------------------------------------------------

def main(media_folder, locale):

    path = os.path.abspath(os.path.dirname(__file__))
    i18n = i18nTools(locale, path)
    strings = i18n.load_json_strings()
    
    local_template = os.path.join(path, "Survey123_XLSPalette_Template.xlsx")
    print(strings['checkMessage'])
    if os.path.exists(local_template):
        print(strings['foundMessage'])
        copy_template(media_folder, local_template, strings)
    else:
        print(strings['notFoundMessage'])
        print(path)
        print(strings['errorExitMessage'])
    sys.exit()

#-------------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-i",
        help="Survey folder",
        required=True,
        dest="survey_folder"
    )
    parser.add_argument(
        "-l",
        help="Please specify the locale to run the tool with",
        required=True,
        dest="locale"
    )
    args = parser.parse_args()
    media = os.path.join(args.survey_folder, "media")
    loc = args.locale.lower()
    if not os.path.exists(media):
        os.mkdir(media)
    main(media_folder=media, locale=loc)
