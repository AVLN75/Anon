# Import Survey Strings

Imports translation files into your XLSForm. 

## Prerequisites

Requires translation columns to be configured in the XLSForm & the default language set on the Settings worksheet. 

### Python 3.9 
* Windows Store: https://www.microsoft.com/en-us/p/python-39/9p7qfqmjrfp7
* Python website: https://www.python.org/downloads/

### Python Packages
* `python3 -m pip install openpyxl`
* `python3 -m pip install requests`
* `python3 -m pip install chardet`

## Usage

`python3 importstrings.py -x <XLSFormPath> -l <locale> -t <token>`
