# Analyze Survey

Python tool to analyze your Survey123 XLSForm checking for best practices. 

## Prequisites

### Python 3.9 
* Windows Store : https://www.microsoft.com/en-us/p/python-39/9p7qfqmjrfp7
* Python website: https://www.python.org/downloads/

### Python Packages
* `python3 -m pip install openpyxl`
* `python3 -m pip install chardet`

## Usage

`python3 analyzesurvey.py -x "<filename>.xlsx" -l "en-US" -v "3.19.123"`
