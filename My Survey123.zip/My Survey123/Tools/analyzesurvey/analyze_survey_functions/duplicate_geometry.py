import os
import re
import xml.etree.ElementTree as ET


def get_schema(element):
    return re.sub("[{][^}]*[}]", "", element.tag), dict(map(get_schema, element)) or element.text


def iter_schema(d, nodeset, layer_name, ns_dict):
    geom_count = {}
    for k, v in d.items():
        if isinstance(v, dict):
            geom_count.update(iter_schema(v, f"{nodeset}/{k}", k, ns_dict))
        else:
            try:
                if ns_dict[f"/{nodeset}/{k}"] == 'geopoint' or ns_dict[f"/{nodeset}/{k}"] == 'geotrace' or ns_dict[
                    f"/{nodeset}/{k}"] == 'geoshape':
                    if layer_name not in geom_count:
                        geom_count.update({layer_name: 1})
                    else:
                        geom_count[layer_name] += 1
            except KeyError:
                pass
    return geom_count


def duplicate_geometry(head, xform, strings, messages, results_ws, rtl):
    """Checks if more than 1 geo* question exists in the XLSForm without being in a repeat."""
    a = os.path.split(xform)[1]
    xml = os.path.join(head, f"{os.path.splitext(a)[0]}.xml")
    root = ET.parse(xml).getroot()
    instance = root.findall('.//{http://www.w3.org/2002/xforms}instance')[0][0]
    model = root.findall('.//{http://www.w3.org/2002/xforms}model')[0]

    name, schema = get_schema(instance)
    try:
        schema.pop('meta')
    except KeyError:
        pass

    ns_dict = {}
    for x in model:
        if len(x.attrib) > 1 and 'nodeset' in x.attrib and 'type' in x.attrib:
            if '{http://esri.com/xforms}fieldType' in x.attrib and x.attrib['{http://esri.com/xforms}fieldType'] == 'null':
                pass
            else:
                ns_dict.update({x.attrib['nodeset']: x.attrib['type']})

    s_geometry = iter_schema(schema, name, name, ns_dict)
    for layer in s_geometry:
        if s_geometry[layer] > 1:
            if layer == name:
                messages['critical'] += 1
                if rtl is False:
                    results_ws.append([strings['messageCritical'], strings['dupGeomMsg'],
                                    strings['dupGeomDesc'], 'survey', "",
                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/geopoints.htm"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/geopoints.htm",
                                       "", 'survey', strings['dupGeomDesc'], 
                                       strings['dupGeomMsg'], strings['messageCritical']])
            else:
                messages['critical'] += 1
                if rtl is False:
                    results_ws.append([strings['messageCritical'], strings['rpDupGeomMsg'].format(repeatName=layer),
                                    strings['rpDupGeomDesc'].format(repeatName=layer), 'survey', "",
                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformrepeats.htm"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformrepeats.htm",
                                       "", 'survey', strings['rpDupGeomDesc'].format(repeatName=layer),
                                       strings['rpDupGeomMsg'].format(repeatName=layer), strings['messageCritical']])
