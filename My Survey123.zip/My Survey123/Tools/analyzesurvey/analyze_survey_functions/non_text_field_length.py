
def non_text_field_length(xlsform, strings, messages, results_ws, rtl):
    ''' Checks if a non text question has a field length set '''

    text_type = ['select_one', 'select_multiple', 'text', 'rank', 'note', 'calculate', 'hidden', 'username', 'email',
                 'deviceid']

    sheet_obj = xlsform['survey']
    workbook_header = [x.value for x in sheet_obj[1]]
    if 'type' in workbook_header and 'name' in workbook_header and 'bind::esri:fieldLength' in workbook_header:
        for q_type, q_name, field_length in zip(
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index('type') + 1,
                                    max_col=workbook_header.index('type') + 1),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index('name') + 1,
                                    max_col=workbook_header.index('name') + 1),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                    min_col=workbook_header.index('bind::esri:fieldLength') + 1,
                                    max_col=workbook_header.index('bind::esri:fieldLength') + 1)):
            if q_type[0].value is not None and not (any(map(q_type[0].value.__contains__, text_type))) and field_length[
                0].value is not None and field_length[0].value != "":
                messages['info'] += 1
                if rtl is False:
                    results_ws.append([strings['messageInfo'],
                                    strings['fieldLengthMsg'].format(questionType=q_type[0].value),
                                    strings['fieldLengthDesc'].format(questionName=q_name[0].value, questionType=q_type[0].value),
                                    'survey', q_name[0].coordinate,
                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#ESRI_SECTION1_20AEFB1D9EDA4EA29358DA927AE4BB8D"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#ESRI_SECTION1_20AEFB1D9EDA4EA29358DA927AE4BB8D",
                                       q_name[0].coordinate, 'survey', strings['fieldLengthDesc'].format(questionName=q_name[0].value, questionType=q_type[0].value),
                                       strings['fieldLengthMsg'].format(questionType=q_type[0].value), strings['messageInfo']])
    else:
        pass
