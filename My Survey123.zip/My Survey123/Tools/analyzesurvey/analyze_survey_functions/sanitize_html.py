from html.parser import HTMLParser


class sanitizeHTMLParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.tags = {}
        self.counter = 0

    def handle_starttag(self, tag, attrs):
        self.tags.update({self.counter: {tag:attrs}})
        self.counter += 1

def sanitize_html(xlsform, strings, messages, results_ws, rtl):
    ''' Checks for unsupported HTML in the XLSForm '''

    supported = {
        'a': ['href', 'style'],
        'img': ['src', 'width', 'height', 'border', 'alt', 'style'],
        'video': ['autoplay', 'controls', 'height', 'loop', 'muted', 'poster', 'preload', 'width'],
        'audio': ['autoplay', 'controls', 'loop', 'muted', 'preload'],
        'source': ['media', 'src', 'type'],
        'span': ['style'],
        'table': ['width', 'height', 'cellpadding', 'cellspacing', 'border', 'style'],
        'div': ['style', 'align'],
        'font': ['size', 'color', 'style'],
        'figure': ['style'],
        'figcaption': ['style'],
        'dd': ['style'],
        'dl': ['style'],
        'dt': ['style'],
        'h1': ['style'],
        'h2': ['style'],
        'h3': ['style'],
        'h4': ['style'],
        'h5': ['style'],
        'h6': ['style'],
        'tr': ['height', 'valign', 'align', 'style'],
        'td': ['height', 'width', 'valign', 'align', 'colspan', 'rowspan', 'nowrap', 'style'],
        'th': ['height', 'width', 'valign', 'align', 'colspan', 'rowspan', 'nowrap', 'style'],
        'p': ['style'],
        'b': [],
        'strong': [],
        'i': [],
        'em': [],
        'u': [],
        'ul': [],
        'ol': [],
        'li': [],
        'tbody': [],
        'br': [],
        'hr': [],
        'abbr': ['title'],
        'sub': ['style'],
        'sup': ['style']
    }

    worksheets = ['survey', 'choices', 'settings']

    for worksheet in worksheets:
        sheet_obj = xlsform[worksheet]
        for v in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=1, max_col=sheet_obj.max_column):
            for i in v:
                if i.value is not None:
                    parser = sanitizeHTMLParser()
                    parser.feed(str(i.value))
                    tags = parser.tags
                    if len(tags) > 0:
                        for tag in tags:
                            # check to make sure key is valid
                            key = list(tags[tag].keys())[0]
                            if key not in list(supported.keys()):
                                messages['warning'] += 1
                                if rtl is False:
                                    results_ws.append([strings['messageWarning'], strings['htmlTagMsg'].format(htmlTag=key),
                                                    strings['htmlTagDesc'].format(htmlTag=key), worksheet, i.coordinate,
                                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformnotes.htm#GUID-1106E413-7BD0-4F71-97B8-807C4BE219FD"])
                                else:
                                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformnotes.htm#GUID-1106E413-7BD0-4F71-97B8-807C4BE219FD",
                                                       i.coordinate, worksheet, strings['htmlTagDesc'].format(htmlTag=key), 
                                                       strings['htmlTagMsg'].format(htmlTag=key), strings['messageWarning']])
                            else:
                                if len(tags[tag][key]) > 0:
                                    for attr in tags[tag][key]:
                                        # check to make sure attribute is valid
                                        if attr[0] not in supported[key]:
                                            messages['warning'] += 1
                                            if rtl is False:
                                                results_ws.append(
                                                    [strings['messageWarning'], strings['htmlAttrMsg'].format(attribute=attr[0], htmlTag=key),
                                                    strings['htmlAttrDesc'].format(attribute=attr[0], htmlTag=key), worksheet, i.coordinate,
                                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformnotes.htm#GUID-1106E413-7BD0-4F71-97B8-807C4BE219FD"])
                                            else:
                                                results_ws.append(
                                                ["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformnotes.htm#GUID-1106E413-7BD0-4F71-97B8-807C4BE219FD",
                                                 i.coordinate, worksheet, strings['htmlAttrDesc'].format(attribute=attr[0], htmlTag=key), 
                                                 strings['htmlAttrMsg'].format(attribute=attr[0], htmlTag=key), strings['messageWarning']])
