

def find_duplicate_choices(xlsform, strings, messages, results_ws, rtl):
    """ Detects if there are duplicate choices in a choice list """
    sheet_obj = xlsform['choices']
    workbook_header = [x.value for x in sheet_obj[1]]
    if "list_name" in workbook_header and "name" in workbook_header:
        list_items = []
        counter = 0
        for ln, n in zip(
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("list_name") + 1,
                                    max_col=workbook_header.index("list_name") + 1, values_only=True),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("name") + 1,
                                    max_col=workbook_header.index("name") + 1, values_only=True)):

            if {ln[0]: n[0]} not in list_items:
                list_items.append({ln[0]: n[0]})
            else:
                if ln[0] != None and counter == 0:
                    messages['info'] += 1
                    if rtl is False:
                        results_ws.append([strings['messageInfo'], strings['dupChoiceMsg'].format(choiceList=ln[0]),
                                        strings['dupChoiceDesc'].format(choiceList=ln[0]), 'choices', '',
                                        "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#GUID-434FA35B-48E1-4309-8F3F-752F725AC596"])
                    else:
                        results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#GUID-434FA35B-48E1-4309-8F3F-752F725AC596",
                                           '', 'choices', strings['dupChoiceDesc'].format(choiceList=ln[0]), 
                                           strings['dupChoiceMsg'].format(choiceList=ln[0]), strings['messageInfo']])
                    counter += 1
    else:
        pass
