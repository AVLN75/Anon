
def survey_title(xlsform, strings, messages, results_ws, rtl):
    """Checks if a survey title is set."""
    sheet_obj = xlsform['settings']
    workbook_header = [x.value for x in sheet_obj[1]]

    if "form_title" in workbook_header:
        if sheet_obj.cell(row=2, column=workbook_header.index("form_title")+1).value is None or sheet_obj.cell(row=2, column=workbook_header.index("form_title")+1).value == "Survey title not set":
            messages['info'] += 1
            if rtl is False:
                results_ws.append([strings['messageInfo'], strings['surveyTitleMsg'],
                                strings['surveyTitleDesc'], 'settings', sheet_obj.cell(row=2, column=workbook_header.index("form_title")+1).coordinate,
                                "https://doc.arcgis.com/en/survey123/desktop/create-surveys/styleyourform.htm#ESRI_SECTION1_1AEBEC0CCD8C4766B72AFB5FB75FC192"])
            else:
                results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/styleyourform.htm#ESRI_SECTION1_1AEBEC0CCD8C4766B72AFB5FB75FC192",
                                   sheet_obj.cell(row=2, column=workbook_header.index("form_title")+1).coordinate, 'settings', strings['surveyTitleDesc'], 
                                   strings['surveyTitleMsg'], strings['messageInfo']])
    else:
        pass

