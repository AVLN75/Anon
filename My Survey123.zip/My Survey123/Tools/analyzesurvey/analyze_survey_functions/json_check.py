import re

def json_check(xlsform, strings, messages, results_ws, rtl):
    """ Checks if someone is working with JSON in their survey and suggests they set the fieldType to null """

    sheet_obj = xlsform['survey']
    workbook_header = [x.value for x in sheet_obj[1]]
    if 'name' in workbook_header and 'calculation' in workbook_header and 'bind::esri:fieldType' in workbook_header and 'bind::esri:fieldLength' in workbook_header:
        for q_type, q_name, calculate, fieldType, fieldLength in zip(
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                    min_col=workbook_header.index("type") + 1,
                                    max_col=workbook_header.index("type") + 1),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                    min_col=workbook_header.index("name") + 1,
                                    max_col=workbook_header.index("name") + 1),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                    min_col=workbook_header.index("calculation") + 1,
                                    max_col=workbook_header.index("calculation") + 1),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                    min_col=workbook_header.index("bind::esri:fieldType") + 1,
                                    max_col=workbook_header.index("bind::esri:fieldType") + 1),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                    min_col=workbook_header.index("bind::esri:fieldLength") + 1,
                                    max_col=workbook_header.index("bind::esri:fieldLength") + 1)
        ):            
            if ("@javascript" in str(calculate[0].value) or 
                ("@layer" in str(calculate[0].value) and ("getRecord" in str(calculate[0].value) or "getRecordAt" in str(calculate[0].value))) or 
                ("@geopoint" in str(calculate[0].value) and (re.search(r"reversegeocode(?!\.)", str(calculate[0].value)) is not None or re.search(r"reversegeocode.address(?!\.)", str(calculate[0].value)) is not None or re.search(r"reversegeocode.location(?!\.)", str(calculate[0].value)) is not None))) and \
                    str(fieldType[0].value) != "null" and fieldLength[0].value is None and ((str(q_type[0].value) in ['text', 'calculate', 'hidden']) or (str(q_type[0].value) == 'note' and q_name[0].value is not None and 'generated_note' not in q_name[0].value)):
                messages['warning'] += 1
                if rtl is False:
                    results_ws.append([strings['messageWarning'], strings['jsonMsg'],
                                    strings['jsonDesc'].format(questionName=q_name[0].value), 'survey',
                                    q_name[0].coordinate,
                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm", 
                                       q_name[0].coordinate, 'survey', strings['jsonDesc'].format(questionName=q_name[0].value), strings['jsonMsg'], strings['messageWarning']])
