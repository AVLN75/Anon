def group_design(xlsform, strings, messages, results_ws, rtl):
    """Checks if there are greater than 20 questions in a survey without a group."""
    questions = []
    sheet_obj = xlsform["survey"]
    workbook_header = [x.value for x in sheet_obj[1]]
    if "type" in workbook_header:
        count = len(list([x[0] for x in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("type") + 1,
                                 max_col=workbook_header.index("type") + 1, values_only=True) if x[0] is not None]))
        if count > 20:
            for v in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                         min_col=workbook_header.index("type") + 1,
                                         max_col=workbook_header.index("type") + 1):
                for i in v:
                    questions.append(i.value)
            if "begin group" not in questions:
                messages['info'] += 1
                if rtl is False:
                    results_ws.append([strings['messageInfo'], strings['grpDesignMsg'],
                                    strings['grpDesignDesc'], 'survey', "",
                                    "https://community.esri.com/t5/arcgis-survey123-blog/survey123-tricks-of-the-trade-groups-grids-and/ba-p/895267"])
                else:
                    results_ws.append(["https://community.esri.com/t5/arcgis-survey123-blog/survey123-tricks-of-the-trade-groups-grids-and/ba-p/895267",
                                       "", 'survey', strings['grpDesignDesc'], strings['grpDesignMsg'], strings['messageInfo']])
    else:
        pass
