def hidden_question_type(xlsform, strings, messages, results_ws, rtl):
    """ Checks if using a hidden question type instead of hidden appearance """
    sheet_obj = xlsform["survey"]
    workbook_header = [x.value for x in sheet_obj[1]]
    if 'type' in workbook_header:
        for v in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("type") + 1,
                                     max_col=workbook_header.index("type") + 1):
            for i in v:
                if i.value == "hidden":
                    messages['info'] += 1
                    if rtl is False:
                        results_ws.append([strings['messageInfo'], strings['hiddenMsg'],
                                        strings['hiddenDesc'].format(
                                            questionName=sheet_obj.cell(row=i.row, column=2).value),
                                        'survey', i.coordinate,
                                        "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformsappearance.htm#ESRI_SECTION1_2098744208D1448EA7EAD4F692B7F9D1"])
                    else:
                        results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformsappearance.htm#ESRI_SECTION1_2098744208D1448EA7EAD4F692B7F9D1",
                                           i.coordinate, 'survey', strings['hiddenDesc'].format(questionName=sheet_obj.cell(row=i.row, column=2).value),
                                           strings['hiddenMsg'], strings['messageInfo']])
    else:
        pass
