def note_question_name_value(xlsform, strings, messages, results_ws, rtl):
    """ Checks if a note question has a name value """
    sheet_obj = xlsform['survey']
    workbook_header = [x.value for x in sheet_obj[1]]
    if 'type' in workbook_header and 'name' in workbook_header:
        for v in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("type") + 1,
                                     max_col=workbook_header.index("type") + 1):
            if v[0].value is not None and v[0].value == 'note':
                row_index = v[0].row
                name_value = sheet_obj.cell(row=row_index, column=workbook_header.index("name") + 1).value
                if name_value is not None and 'generated_note' not in name_value:
                    messages['info'] += 1
                    q_name = sheet_obj.cell(row=row_index, column=workbook_header.index("name") + 1).value
                    if rtl is False:
                        results_ws.append([strings['messageInfo'], strings['noteNameMsg'].format(
                            questionName=q_name),
                                        strings['noteNameDesc'].format(questionName=q_name), 'survey',
                                        v[0].coordinate,
                                        "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformnotes.htm#ESRI_SECTION1_B2D6F75A3A5349D39DE269007686A0BC"])
                    else:
                        results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformnotes.htm#ESRI_SECTION1_B2D6F75A3A5349D39DE269007686A0BC", 
                                           v[0].coordinate, 'survey', strings['noteNameDesc'].format(questionName=q_name), 
                                           strings['noteNameMsg'].format(questionName=q_name), strings['messageInfo']])
    else:
        pass
