def theme_grid(xlsform, strings, messages, results_ws, rtl):
    """Checks if a survey is using theme-grid and directs the user toward
    the latest options."""
    sheet_obj = xlsform['settings']
    workbook_header = [x.value for x in sheet_obj[1]]

    if "style" in workbook_header:
        if sheet_obj.cell(row=2, column=workbook_header.index("style") + 1).value is None:
            pass
        elif "theme-grid" in sheet_obj.cell(row=2, column=workbook_header.index("style") + 1).value:
            messages['info'] += 1
            if rtl is False:
                results_ws.append([strings['messageInfo'], strings['themeGridMsg'],
                                strings['themeGridDesc'], 'settings',
                                sheet_obj.cell(row=2, column=workbook_header.index("style") + 1).coordinate,
                                "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformsappearance.htm#ESRI_SECTION1_8BFD43516DE1437FAD8DBFBD21A27B90"])
            else:
                results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformsappearance.htm#ESRI_SECTION1_8BFD43516DE1437FAD8DBFBD21A27B90",
                                   sheet_obj.cell(row=2, column=workbook_header.index("style") + 1).coordinate, 'settings', strings['themeGridDesc'],
                                   strings['themeGridMsg'], strings['messageInfo']])
    else:
        pass
