def check_js_function(xlsform, strings, messages, results_ws, rtl):
    """ Checks to see if pulldata @javascript is use in the survey and warns the user that
    pulldata @javascript cannot be used in public surveys"""
    sheet_obj = xlsform['survey']
    workbook_header = [x.value for x in sheet_obj[1]]
    if "calculation" in workbook_header:
        for v in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("calculation") + 1,
                                     max_col=workbook_header.index("calculation") + 1):
            if v[0].value is not None:
                if 'pulldata("@javascript"' in str(v[0].value):
                    messages['info'] += 1
                    if rtl is False:
                        results_ws.append([strings['messageInfo'], strings['jsMsg'],
                                        strings['jsDesc'], 'survey', v[0].coordinate,
                                        "https://doc.arcgis.com/en/survey123/desktop/create-surveys/pulldatajavascript.htm"])
                    else:
                        results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/pulldatajavascript.htm",
                                           v[0].coordinate, 'survey', strings['jsDesc'], 
                                           strings['jsMsg'], strings['messageInfo']])
    else:
        pass
