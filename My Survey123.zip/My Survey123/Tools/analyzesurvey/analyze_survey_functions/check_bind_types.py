def check_bind_types(xlsform, strings, messages, results_ws, rtl):
    """ Checks to ensure that values in the bind::type and bind::esri:fieldType columns are valid """
    valid_bind_types = ['int', 'decimal', 'string', 'time', 'dateTime', 'date']
    valid_field_types = ['esriFieldTypeDate', 'esriFieldTypeSingle', 'esriFieldTypeDouble', 'esriFieldTypeInteger',
                         'esriFieldTypeSmallInteger', 'esriFieldTypeString', 'esriFieldTypePointZ', 'esriFieldTypeGUID', 
                         'esriFieldTypeTimestampOffset', 'esriFieldTypeDateOnly', 'esriFieldTypeTimeOnly', 'esriFieldTypeBigInteger',
                         'null']
    sheet_obj = xlsform['survey']
    workbook_header = [x.value for x in sheet_obj[1]]
    if "bind::type" in workbook_header:
        for bt in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("bind::type") + 1,
                                      max_col=workbook_header.index("bind::type") + 1):
            if bt[0].value is not None and bt[0].value not in valid_bind_types:
                messages['critical'] += 1
                if rtl is False:
                    results_ws.append([strings['messageCritical'], strings['bindTypeMsg'].format(bindType=bt[0].value),
                                    strings['bindTypeDesc'].format(bindType=bt[0].value), 'survey',
                                    bt[0].coordinate,
                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#GUID-1176C96B-41CA-4607-8F19-86AC2E9A66E0"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#GUID-1176C96B-41CA-4607-8F19-86AC2E9A66E0",
                                       bt[0].coordinate, 'survey', strings['bindTypeDesc'].format(bindType=bt[0].value),
                                       strings['bindTypeMsg'].format(bindType=bt[0].value), strings['messageCritical']])
    else:
        pass
    if "bind::esri:fieldType" in workbook_header:
        for ft in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                      min_col=workbook_header.index("bind::esri:fieldType") + 1,
                                      max_col=workbook_header.index("bind::esri:fieldType") + 1):
            if ft[0].value is not None and ft[0].value not in valid_field_types and ft[0].value != "":
                messages['critical'] += 1
                if rtl is False:
                    results_ws.append([strings['messageCritical'], strings['fieldTypeMsg'].format(fieldType=ft[0].value),
                                    strings['fieldTypeDesc'].format(fieldTypeValue=ft[0].value), 'survey',
                                    ft[0].coordinate,
                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#GUID-1176C96B-41CA-4607-8F19-86AC2E9A66E0"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#GUID-1176C96B-41CA-4607-8F19-86AC2E9A66E0", 
                                       ft[0].coordinate, 'survey', strings['fieldTypeDesc'].format(fieldTypeValue=ft[0].value), 
                                       strings['fieldTypeMsg'].format(fieldType=ft[0].value), strings['messageCritical']])
    else:
        pass
