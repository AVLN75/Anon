

def single_image_repeat(xlsform, strings, messages, results_ws, rtl):
    """Checks if a repeat exists with a single image question."""
    sheet_obj = xlsform['survey']

    workbook_header = [x.value for x in sheet_obj[1]]
    if 'type' in workbook_header:
        type_rows = sheet_obj.iter_cols(min_col=workbook_header.index("type") + 1,
                                        max_col=workbook_header.index("type") + 1,
                                        min_row=2, max_row=sheet_obj.max_row)
        for q_type in type_rows:
            for q_type_cell in q_type:
                if q_type_cell.value == "begin repeat":
                    rp_questions = []
                    for question in q_type[q_type.index(q_type_cell)+1:]:
                        rp_questions.append(question.value)
                        if question.value == "end repeat":
                            rp_questions.remove("end repeat")
                            break
                    if len(rp_questions) < 2 and "image" in rp_questions:
                        messages['info'] += 1
                        if rtl is False:
                            results_ws.append([strings['messageInfo'], strings['imgRpMsg'],
                                            strings['imgRpDesc'], 'survey', q_type_cell.coordinate,
                                            "https://community.esri.com/t5/arcgis-survey123-blog/survey123-tricks-of-the-trade-photos/ba-p/897907"])
                        else:
                            results_ws.append(["https://community.esri.com/t5/arcgis-survey123-blog/survey123-tricks-of-the-trade-photos/ba-p/897907",
                                               q_type_cell.coordinate, 'survey', strings['imgRpDesc'], strings['imgRpMsg'], strings['messageInfo']])
    else:
        pass
