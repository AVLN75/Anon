import re
import openpyxl

def survey_template_version(xlsform, strings, messages, results_ws, version, rtl):
    """ Checks if the XLSForm template used is old """

    s = xlsform.sheetnames
    if 'Version' in s:
        sheet_obj = xlsform['Version']
        for val in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=1, max_col=1):
            if "Template version:" == val[0].value:
                ws_version = sheet_obj.cell(row=val[0].row, column=val[0].column + 1).value
                try:
                    if isinstance(ws_version, openpyxl.worksheet.formula.ArrayFormula):
                        ws_version = ws_version.text
                except AttributeError:
                    pass
                ws_version = str(ws_version)
                if "=TEXT(" in ws_version:
                    searched_string = re.search(r"3\.\d\d", ws_version)
                    if searched_string != None:
                        template_version = float(searched_string[0])
                    else:
                        sub_string = re.search(r"3\.\d", ws_version)[0]
                        template_version = float(f'{sub_string}0')
                else:
                    template_version = float(ws_version)
                if template_version < float(".".join(version.split(".")[:2])):
                    messages['info'] += 1
                    if rtl is False:
                        results_ws.append([strings['messageInfo'], strings['templateVersionMsg'],
                                        strings['templateVersionDesc'],
                                        'Version', sheet_obj.cell(row=val[0].row, column=val[0].column+1).coordinate,
                                        "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#ESRI_SECTION1_443EF43AA24A4AFCA2BDCF3F02F0BF09"])
                    else:
                        results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#ESRI_SECTION1_443EF43AA24A4AFCA2BDCF3F02F0BF09",
                                           sheet_obj.cell(row=val[0].row, column=val[0].column+1).coordinate, 'Version', strings['templateVersionDesc'],
                                           strings['templateVersionMsg'], strings['messageInfo']])
                break
    else:
        messages['info'] += 1
        if rtl is False:
            results_ws.append([strings['messageInfo'], strings['templateVersionMsg'],
                                        strings['templateVersionDesc'],
                                        'Version', "",
                                        "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#ESRI_SECTION1_443EF43AA24A4AFCA2BDCF3F02F0BF09"])
        else:
            results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#ESRI_SECTION1_443EF43AA24A4AFCA2BDCF3F02F0BF09", 
                               "", 'Version', strings['templateVersionDesc'], strings['templateVersionMsg'], strings['messageInfo']])
