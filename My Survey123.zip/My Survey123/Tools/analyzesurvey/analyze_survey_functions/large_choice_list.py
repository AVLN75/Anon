

def large_choice_list(xlsform, strings, messages, results_ws, rtl):
    """Checks if there is a choice list in the choices worksheet that 
    exceed 200 choices."""
    sheet_obj = xlsform['choices']
    workbook_header = [x.value for x in sheet_obj[1]]
    if "list_name" in workbook_header:
        list_items = []
        for r in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("list_name")+1, max_col=workbook_header.index("list_name")+1, values_only=True):
            if r[0] is not None:
                list_items.append(r[0])
        list_counter = {}
        for item in list_items:
            if item in list_counter.keys():
                list_counter[item] += 1
            else:
                list_counter[item] = 1
        for lst in list_counter:
            if list_counter[lst] >= 3500:
                messages['critical'] += 1
                if rtl is False:
                    results_ws.append([strings['messageCritical'], strings['choiceListCriticalMsg'].format(choiceListName=lst),
                                    strings['choiceListCriticalDesc'].format(choiceListName=lst), 'choices', '',
                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#ESRI_SECTION1_34A4D88BA6A64C48AA0E113DC61099DD"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#ESRI_SECTION1_34A4D88BA6A64C48AA0E113DC61099DD", 
                                       '', 'choices', strings['choiceListCriticalDesc'].format(choiceListName=lst), 
                                       strings['choiceListCriticalMsg'].format(choiceListName=lst), strings['messageCritical']])
            elif 500 <= list_counter[lst] < 3500:
                messages['warning'] += 1
                if rtl is False:
                    results_ws.append([strings['messageWarning'], strings['choiceListWarningMsg'].format(choiceListName=lst),
                                    strings['choiceListWarningDesc'].format(choiceListName=lst), 'choices', '',
                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#ESRI_SECTION1_34A4D88BA6A64C48AA0E113DC61099DD"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#ESRI_SECTION1_34A4D88BA6A64C48AA0E113DC61099DD",
                                       '', 'choices', strings['choiceListWarningDesc'].format(choiceListName=lst),
                                       strings['choiceListWarningMsg'].format(choiceListName=lst), strings['messageWarning']])
            elif 200 <= list_counter[lst] < 500:
                messages['info'] += 1
                if rtl is False:
                    results_ws.append([strings['messageInfo'], strings['choiceListInfoMsg'].format(choiceListName=lst),
                                    strings['choiceListInfoDesc'].format(choiceListName=lst), 'choices', '',
                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#ESRI_SECTION1_34A4D88BA6A64C48AA0E113DC61099DD"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformessentials.htm#ESRI_SECTION1_34A4D88BA6A64C48AA0E113DC61099DD",
                                       '', 'choices', strings['choiceListInfoDesc'].format(choiceListName=lst),
                                       strings['choiceListInfoMsg'].format(choiceListName=lst), strings['messageInfo']])
    else:
        pass
