def multilingual(xlsform, strings, messages, results_ws, rtl):
    """ Checks if the user has a multilingual survey with untranslated values """
    default_language = False
    hidden_questions = ['start', 'end', 'deviceid', 'username', 'email', 'calculate', 'hidden']
    ws = ['survey', 'choices']
    if 'external_choices' in xlsform.sheetnames:
        ws.append('external_choices')

    settings_ws = xlsform["settings"]
    settings_header = [x.value for x in settings_ws[1]]
    if "default_language" in settings_header:
        def_language_cell = settings_ws.cell(row=2, column=settings_header.index("default_language") + 1)
        if def_language_cell.value is not None and len(str(def_language_cell.value)) != 0:
            default_language = def_language_cell.value[def_language_cell.value.index("(") + 1: def_language_cell.value.index(")")]
            def_language = True
        else:
            def_language = False
    else:
        def_language = False
    multilingual = False
    for worksheet in ws:
        sheet_obj = xlsform[worksheet]
        workbook_header = [x.value for x in sheet_obj[1] if x.value is not None]
        if "label" in ascii(workbook_header) and "type" in workbook_header and "appearance" in workbook_header:
            if not default_language:
                label_indices = [i for i, s in enumerate(workbook_header) if "label" in s]
                implicit_def_language_cell = workbook_header[label_indices[0]]
                try:
                    default_language = implicit_def_language_cell[implicit_def_language_cell.index("(") + 1: implicit_def_language_cell.index(")")]
                except ValueError:
                    # User is not using a multilingual survey
                    pass
            try:
                workbook_header.remove("label::language (xx)")
                workbook_header.remove("hint::language (xx)")
                workbook_header.remove("guidance_hint::language (xx)")
                workbook_header.remove("required_message::language (xx)")
                workbook_header.remove("media::audio::language (xx)")
                workbook_header.remove("media::image::language (xx)")
            except:
                pass
            source_cols = [x for x in workbook_header if "({})".format(default_language) in x]
            cois = [x for x in workbook_header if x not in source_cols]

            for col in cois:
                if "label::" in col or "hint::" in col or "guidance_hint::" in col or "required_message::" in col \
                        or "media::audio::" in col or "media::image::" in col:
                    try:
                        source_col = [element for element in source_cols if element.startswith(col[0:col.index(":")])][0]
                        multilingual = True
                        for v in sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                                     min_col=workbook_header.index(col) + 1,
                                                     max_col=workbook_header.index(col) + 1):
                            if v[0].value is None and sheet_obj.cell(row=v[0].row, column=workbook_header.index(
                                    source_col) + 1).value is not None and sheet_obj.cell(row=v[0].row,
                                                                                          column=workbook_header.index(
                                                                                                  'type') + 1).value not in hidden_questions and sheet_obj.cell(
                                    row=v[0].row, column=workbook_header.index('appearance') + 1).value != 'hidden':
                                messages['warning'] += 1
                                if rtl is False:
                                    results_ws.append([strings['messageWarning'], strings['multiTranslationMsg'],
                                                    strings['multiTranslationDesc'].format(cellCoordinate=v[0].coordinate,
                                                                                            worksheetRef=worksheet),
                                                    worksheet, v[0].coordinate,
                                                    "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformmultiplelanguagesupport.htm"])
                                else:
                                    results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformmultiplelanguagesupport.htm", 
                                                       v[0].coordinate, worksheet, strings['multiTranslationDesc'].format(cellCoordinate=v[0].coordinate,worksheetRef=worksheet),
                                                       strings['multiTranslationMsg'], strings['messageWarning']])
                    except IndexError:
                        pass
                    except ValueError:
                        pass
        else:
            pass

    if multilingual and not def_language:
        messages['info'] += 1
        if rtl is False:
            results_ws.append([strings['messageInfo'], strings['defLangMsg'],
                            strings['defLangDesc'], 'settings', def_language_cell.coordinate,
                            "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformmultiplelanguagesupport.htm"])
        else:
            results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformmultiplelanguagesupport.htm",
                               def_language_cell.coordinate, 'settings', strings['defLangDesc'], 
                               strings['defLangMsg'], strings['messageInfo']])
