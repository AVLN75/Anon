def input_mask_numeric(xlsform, strings, messages, results_ws, rtl):
    """ Checks to see if an input mask has been applied to an integer or decimal question type """
    sheet_obj = xlsform['survey']
    workbook_header = [x.value for x in sheet_obj[1]]
    if "type" in workbook_header and "name" in workbook_header and "body::esri:inputMask" in workbook_header:
        for q_type, q_name, input_mask in zip(
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("type") + 1,
                                    max_col=workbook_header.index("type") + 1, values_only=True),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("name") + 1,
                                    max_col=workbook_header.index("name") + 1, values_only=True),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                    min_col=workbook_header.index("body::esri:inputMask") + 1,
                                    max_col=workbook_header.index("body::esri:inputMask") + 1)):
            if (q_type[0] is not None and (q_type[0] == 'integer' or q_type[0] == 'decimal')) and input_mask[0].value is not None:
                messages['warning'] += 1
                if q_type[0] == 'integer':
                    if rtl is False:
                        results_ws.append([strings['messageWarning'], strings['inMaskIntMsg'].format(questionName=q_name[0]),
                                        strings['inMaskIntDesc'].format(questionName=q_name[0]), 'survey',
                                        input_mask[0].coordinate,
                                        "https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#ESRI_SECTION1_2D9AA8F82B714D7DB922D766E56FF3F6"])
                    else:
                        results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#ESRI_SECTION1_2D9AA8F82B714D7DB922D766E56FF3F6", 
                                           input_mask[0].coordinate, 'survey', strings['inMaskIntDesc'].format(questionName=q_name[0]),
                                           strings['inMaskIntMsg'].format(questionName=q_name[0]), strings['messageWarning']])
                elif q_type[0] == 'decimal':
                    if rtl is False:
                        results_ws.append([strings['messageWarning'], strings['inMaskDecMsg'].format(questionName=q_name[0]),
                                        strings['inMaskDecDesc'].format(questionName=q_name[0]), 'survey',
                                        input_mask[0].coordinate,
                                        "https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#ESRI_SECTION1_2D9AA8F82B714D7DB922D766E56FF3F6"])
                    else:
                        results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#ESRI_SECTION1_2D9AA8F82B714D7DB922D766E56FF3F6",
                                           input_mask[0].coordinate, 'survey', strings['inMaskDecDesc'].format(questionName=q_name[0]),
                                           strings['inMaskDecMsg'].format(questionName=q_name[0]), strings['messageWarning']])
    else:
        pass
