def check_choice_name_length(xlsform, strings, messages, results_ws, rtl):
    """ Detects if there are duplicate choices in a choice list """
    sheet_obj = xlsform['choices']
    workbook_header = [x.value for x in sheet_obj[1]]
    list_items = {}
    for ln, n in zip(
            sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("list_name") + 1,
                                max_col=workbook_header.index("list_name") + 1, values_only=True),
            sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row, min_col=workbook_header.index("name") + 1,
                                max_col=workbook_header.index("name") + 1, values_only=True)):
        if ln[0] != None and ln[0] not in list_items.keys():
            list_items.update({ln[0]: [n[0]]})
        elif ln[0] != None and ln[0] in list_items.keys():
            list_items[ln[0]].append(n[0])

    questions = {}
    survey_ws = xlsform['survey']
    survey_ws_header = [x.value for x in survey_ws[1]]
    if 'bind::esri:fieldLength' in survey_ws_header and 'type' in survey_ws_header:
        for q_type, field_length in zip(
                survey_ws.iter_rows(min_row=2, max_row=survey_ws.max_row, min_col=survey_ws_header.index('type') + 1,
                                    max_col=survey_ws_header.index('type') + 1, values_only=True),
                survey_ws.iter_rows(min_row=2, max_row=survey_ws.max_row,
                                    min_col=survey_ws_header.index('bind::esri:fieldLength') + 1,
                                    max_col=survey_ws_header.index('bind::esri:fieldLength') + 1, values_only=True)):
            if q_type[0] is not None:
                questions.update({q_type[0]: field_length[0]})

        question_keys = [x for x in questions.keys()]

        for list_name in list_items:
            s_question = [s for s in question_keys if str(list_name) in s]
            for question in s_question:
                if questions[question] is not None and len(
                        [c_name for c_name in list_items[list_name] if len(str(c_name)) > int(questions[question])]) > 0:
                    messages['critical'] += 1
                    if rtl is False:
                        results_ws.append([strings['messageCritical'],
                                        strings['choiceLengthMsg'].format(choiceListName=list_name, questionName=question),
                                        strings['choiceLengthDesc'].format(choiceListName=list_name, questionName=question, choices=', '.join(str(x) for x in [c_name for c_name in list_items[list_name] if len(str(c_name)) > questions[question]])),
                                        'choices', '',
                                        "https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#ESRI_SECTION1_20AEFB1D9EDA4EA29358DA927AE4BB8D"])
                    else:
                        results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/esricustomcolumns.htm#ESRI_SECTION1_20AEFB1D9EDA4EA29358DA927AE4BB8D",
                                           '', 'choices', strings['choiceLengthDesc'].format(choiceListName=list_name, questionName=question, choices=', '.join(str(x) for x in [c_name for c_name in list_items[list_name] if len(str(c_name)) > questions[question]])),
                                           strings['choiceLengthMsg'].format(choiceListName=list_name, questionName=question), strings['messageCritical']])
    else:
        pass
