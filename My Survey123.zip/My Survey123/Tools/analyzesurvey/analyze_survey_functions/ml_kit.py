def ml_kit(xlsform, strings, messages, results_ws, rtl):
    """ Checks if someone is using functionality that takes advantage of Google ML Kit """

    sheet_obj = xlsform['survey']
    workbook_header = [x.value for x in sheet_obj[1]]
    if 'name' in workbook_header and 'type' in workbook_header and 'bind::esri:parameters' in workbook_header:
        for name, q_type, parameters in zip(
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                    min_col=workbook_header.index("name") + 1,
                                    max_col=workbook_header.index("name") + 1),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                    min_col=workbook_header.index("type") + 1,
                                    max_col=workbook_header.index("type") + 1),
                sheet_obj.iter_rows(min_row=2, max_row=sheet_obj.max_row,
                                    min_col=workbook_header.index("bind::esri:parameters") + 1,
                                    max_col=workbook_header.index("bind::esri:parameters") + 1)
        ):
            if str(q_type[0].value) == 'barcode':
                messages['info'] += 1
                if rtl is False:
                    results_ws.append([strings['messageInfo'], strings['smartBarcodeMsg'],
                                    strings['smartBarcodeDesc'].format(questionName=name[0].value), 'survey',
                                    name[0].coordinate,
                                    "https://doc.arcgis.com/en/survey123/get-started/smartassistants.htm#ESRI_SECTION1_DF9EBE040CC6431A8402CDF713696624"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/get-started/smartassistants.htm#ESRI_SECTION1_DF9EBE040CC6431A8402CDF713696624",
                                       name[0].coordinate, 'survey', strings['smartBarcodeDesc'].format(questionName=name[0].value), 
                                       strings['smartBarcodeMsg'], strings['messageInfo']])
            elif '@faces' in str(parameters[0].value).lower() and "engine=vision" in str(parameters[0].value).lower():
                messages['info'] += 1
                if rtl is False:
                    results_ws.append([strings['messageInfo'], strings['visionEngineMsg'],
                                    strings['visionEngineDesc'].format(questionName=name[0].value), 'survey',
                                    name[0].coordinate,
                                    "https://doc.arcgis.com/en/survey123/get-started/smartassistants.htm#ESRI_SECTION1_DF9EBE040CC6431A8402CDF713696624"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/get-started/smartassistants.htm#ESRI_SECTION1_DF9EBE040CC6431A8402CDF713696624",
                                       name[0].coordinate, 'survey', strings['visionEngineDesc'].format(questionName=name[0].value), 
                                       strings['visionEngineMsg'], strings['messageInfo']])
            elif '@faces' in str(parameters[0].value).lower():
                messages['info'] += 1
                if rtl is False:
                    results_ws.append([strings['messageInfo'], strings['smartRedactionMsg'],
                                    strings['smartRedactionDesc'].format(questionName=name[0].value), 'survey',
                                    name[0].coordinate,
                                    "https://doc.arcgis.com/en/survey123/get-started/smartassistants.htm#ESRI_SECTION1_DF9EBE040CC6431A8402CDF713696624"])
                else:
                    results_ws.append(["https://doc.arcgis.com/en/survey123/get-started/smartassistants.htm#ESRI_SECTION1_DF9EBE040CC6431A8402CDF713696624",
                                       name[0].coordinate, 'survey', strings['smartRedactionDesc'].format(questionName=name[0].value), 
                                       strings['smartRedactionMsg'], strings['messageInfo']])
            
