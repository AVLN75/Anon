

def survey_instance_name(xlsform, strings, messages, results_ws, rtl):
    """Checks if a survey title is set."""
    sheet_obj = xlsform['settings']
    workbook_header = [x.value for x in sheet_obj[1]]

    if "instance_name" in workbook_header:
        if sheet_obj.cell(row=2, column=workbook_header.index("instance_name")+1).value is None:
            messages['info'] += 1
            if rtl is False:
                results_ws.append([strings['messageInfo'], strings['instanceNameMsg'],
                                strings['instanceNameDesc'], 'settings', sheet_obj.cell(row=2, column=workbook_header.index("instance_name")+1).coordinate,
                                "https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsforminstancename.htm"])
            else:
                results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsforminstancename.htm", 
                                   sheet_obj.cell(row=2, column=workbook_header.index("instance_name")+1).coordinate, 'settings', 
                                   strings['instanceNameDesc'], strings['instanceNameMsg'], strings['messageInfo']])
    else:
        pass
