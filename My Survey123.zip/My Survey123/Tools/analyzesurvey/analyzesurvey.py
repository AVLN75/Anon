#!/usr/bin/python3
#-------------------------------------------------------------------------------
# Copyright 2025 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#-------------------------------------------------------------------------------

import openpyxl
from openpyxl.styles import Font, colors, Alignment
from openpyxl.worksheet.table import Table, TableStyleInfo
import argparse
import datetime
import os
import tempfile
import shutil
import json
from analyze_survey_functions.group_design import group_design
from analyze_survey_functions.hidden_question_type import hidden_question_type
from analyze_survey_functions.large_choice_list import large_choice_list
from analyze_survey_functions.note_question_name_value import note_question_name_value
from analyze_survey_functions.single_image_repeat import single_image_repeat
from analyze_survey_functions.survey_template_version import survey_template_version
from analyze_survey_functions.survey_title import survey_title
from analyze_survey_functions.survey_instance_name import survey_instance_name
from analyze_survey_functions.theme_grid import theme_grid
from analyze_survey_functions.check_js_function import check_js_function
from analyze_survey_functions.duplicate_geometry import duplicate_geometry
from analyze_survey_functions.multilingual import multilingual
from analyze_survey_functions.check_bind_types import check_bind_types
from analyze_survey_functions.input_mask_numeric import input_mask_numeric
from analyze_survey_functions.sanitize_html import sanitize_html
from analyze_survey_functions.find_duplicate_choices import find_duplicate_choices
from analyze_survey_functions.check_choice_name_length import check_choice_name_length
from analyze_survey_functions.non_text_field_length import non_text_field_length
from analyze_survey_functions.json_check import json_check
from analyze_survey_functions.ml_kit import ml_kit
import warnings

dir_path = os.path.split(os.path.dirname(os.path.realpath(__file__)))[0]
import sys 
sys.path.insert(0, os.path.join(dir_path, 'i18n_tools'))
from i18n import i18nTools

sys.stdout = open(1, 'w', encoding='utf-8', closefd=False)

warnings.simplefilter("ignore")


def generate_html(resources_folder, results_xlsx, messages, issues, strings, i18n):
    if issues:
        paragraph = strings['issueParagraph'].format(xlsxPath=str(results_xlsx), xlsxName=os.path.basename(results_xlsx))
    else:
        paragraph = strings['nonIssueParagraph']
    
    html_string = i18n.load_html_strings()
    
    html_string = html_string.replace('{paragraph}', paragraph)
    html_string = html_string.replace('{exclamation-mark-circle}',
                                      os.path.join(resources_folder, 'exclamation-mark-circle.svg'))
    html_string = html_string.replace('{exclamation-mark-triangle}',
                                      os.path.join(resources_folder, 'exclamation-mark-triangle.svg'))
    html_string = html_string.replace('{information-icon}', os.path.join(resources_folder, 'information.svg'))
    html_string = html_string.replace('{criticalCount}', str(messages['critical']))
    html_string = html_string.replace('{warningCount}', str(messages['warning']))
    html_string = html_string.replace('{infoCount}', str(messages['info']))
    return html_string


def format_results_ws(results_ws, strings, rtl):
    if rtl is False:
        results_ws.column_dimensions['A'].width = 13
        results_ws.column_dimensions['B'].width = 70
        results_ws.column_dimensions['C'].width = 70
        results_ws.column_dimensions['D'].width = 13
        results_ws.column_dimensions['E'].width = 16
        results_ws.column_dimensions['F'].width = 13
    else:
        results_ws.column_dimensions['F'].width = 13
        results_ws.column_dimensions['E'].width = 70
        results_ws.column_dimensions['D'].width = 70
        results_ws.column_dimensions['C'].width = 13
        results_ws.column_dimensions['B'].width = 16
        results_ws.column_dimensions['A'].width = 13

    for row in range(2, results_ws.max_row + 1):
        if rtl is False:
            hyperlink_cell = results_ws.cell(row, 6)
        else:
            hyperlink_cell = results_ws.cell(row, 1)
        link = hyperlink_cell.value
        hyperlink_cell.value = strings['headerLearnMore']
        hyperlink_cell.hyperlink = link
        hyperlink_cell.style = "Hyperlink"
        hyperlink_cell.font = Font(size=11, u='single', color=colors.BLUE)
        
        if rtl is False:
            message_cell = results_ws.cell(row, 2)
        else:
            message_cell = results_ws.cell(row, 5)
        message_cell.alignment = Alignment(wrap_text=True)

        if rtl is False:
            description_cell = results_ws.cell(row, 3)
        else:
            description_cell = results_ws.cell(row, 4)
        description_cell.alignment = Alignment(wrap_text=True)

    tab = Table(displayName="Table1", ref=f"A1:F{results_ws.max_row}")
    style = TableStyleInfo(name='TableStyleMedium4', showRowStripes=True, showColumnStripes=False)
    tab.tableStyleInfo = style
    results_ws.add_table(tab)


def analyze_survey(xform, strings, messages, results_ws, head, version, rtl):
    """
    Performs an analysis on your XLSForm to check for best practices when designing your survey.
    """
    wb_obj = openpyxl.load_workbook(xform)

    # Critical type:
    duplicate_geometry(head, xform, strings, messages, results_ws, rtl)
    check_bind_types(wb_obj, strings, messages, results_ws, rtl)
    input_mask_numeric(wb_obj, strings, messages, results_ws, rtl)
    large_choice_list(wb_obj, strings, messages, results_ws, rtl)
    check_choice_name_length(wb_obj, strings, messages, results_ws, rtl)

    # Warning type
    multilingual(wb_obj, strings, messages, results_ws, rtl)
    sanitize_html(wb_obj, strings, messages, results_ws, rtl)
    single_image_repeat(wb_obj, strings, messages, results_ws, rtl)
    non_text_field_length(wb_obj, strings, messages, results_ws, rtl)
    json_check(wb_obj, strings, messages, results_ws, rtl)

    # Info type
    find_duplicate_choices(wb_obj, strings, messages, results_ws, rtl)
    theme_grid(wb_obj, strings, messages, results_ws, rtl)
    group_design(wb_obj, strings, messages, results_ws, rtl)
    hidden_question_type(wb_obj, strings, messages, results_ws, rtl)
    check_js_function(wb_obj, strings, messages, results_ws, rtl)
    ml_kit(wb_obj, strings, messages, results_ws, rtl)
    note_question_name_value(wb_obj, strings, messages, results_ws, rtl)
    survey_instance_name(wb_obj, strings, messages, results_ws, rtl)
    survey_template_version(wb_obj, strings, messages, results_ws, version, rtl)
    survey_title(wb_obj, strings, messages, results_ws, rtl)


def main(usr_xform, locale, version):
    
    path = os.path.abspath(os.path.dirname(__file__))
    i18n = i18nTools(locale, path)
    strings = i18n.load_json_strings()

    head, a = os.path.split(usr_xform)
 
    
    # The XLSForm needs to be opened in r/w mode so create a backup in temp directory
    # as the user may have the XLSForm open
    tmpdir = tempfile.TemporaryDirectory()
    tmp_xls = tmpdir.name
    xlsform = shutil.copy(usr_xform, tmp_xls)

    debug_path = os.path.join(head, "debug")
    if not os.path.exists(debug_path):
        os.makedirs(debug_path)
    update_path = os.path.join(debug_path, "analyze_survey")
    if not os.path.exists(update_path):
        os.makedirs(update_path)

    # Local folder doesn't need to be translated
    resources_folder = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'resources')
    # Local variables doesn't need to be translated
    messages = {
        "info": 0,
        "warning": 0,
        "critical": 0
    }

    timestamp = str(datetime.datetime.now().strftime('%Y%m%d%H%M%S'))

    results_xlsx = os.path.join(update_path,
                                f"analysis-{timestamp}.xlsx")
    results_wb = openpyxl.Workbook()
    results_ws = results_wb.active
    results_ws.title = strings['worksheetName']

    if locale[:2] not in ['ar', 'he']:
        results_ws.append([strings['headerSeverity'], strings['headerMessage'], strings['headerDescription'],
                           strings['headerWorksheet'], strings['headerCellReference'], strings['headerLearnMore']])
        rtl = False
    else:
        results_ws.append([strings['headerLearnMore'], strings['headerCellReference'], strings['headerWorksheet'], 
                           strings['headerDescription'], strings['headerMessage'], strings['headerSeverity']])
        rtl = True

    analyze_survey(xlsform, strings, messages, results_ws, head, version, rtl)
    if messages['info'] == 0 and messages['warning'] == 0 and messages['critical'] == 0:
        issues = False
    else:
        format_results_ws(results_ws, strings, rtl)
        results_wb.save(results_xlsx)
        issues = True
    
    print(generate_html(resources_folder, results_xlsx, messages, issues, strings, i18n))
    tmpdir.cleanup()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-x", help="Please specify the path to the XLSForm",
                        required=True, dest="xlsform")
    parser.add_argument("-l", help="Please specify the locale to run the tool with",
                        required=True, dest="locale"
                        )
    parser.add_argument("-v", help="Please specify the version of Survey123 Connect",
                        required=True, dest="version"
                        )
    args = parser.parse_args()
    xls_form = args.xlsform
    version = args.version
    locale = args.locale.lower()
    main(xls_form, locale, version)
