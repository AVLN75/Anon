# Export survey to a map

Exports your survey to a map with feature forms.

## Prerequisites

TBD 

### Python 3.11 
* Windows Store: https://www.microsoft.com/en-us/p/python-39/9p7qfqmjrfp7
* Python website: https://www.python.org/downloads/

### Python Packages
arcgis

## Usage

`python survey2mapform.py -s <surveypath> -l <locale> -t <token>`
