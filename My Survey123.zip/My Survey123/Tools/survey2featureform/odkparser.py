
"""
Copyright © 2024 ESRI

Trade Secrets: ESRI Proprietary and Confidential
Unpublished material - all rights reserved under the
Copyright Laws of the United States.

For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts Dept
380 New York Street
Redlands, California, USA 92373

Email: contracts@esri.com
"""

#-------------------------------------------------------------------------------

from enum import Enum
import re
import arcadeFunctions

TOKEN_MAPPINGS = dict({
    "and"  : "&&",
    "or"   : "||",
    "="    : "==",
    "div"  : "/",
    "mod"  : "%",
    "not(" : "!(",
})

# key = "ODK function" Value = "Arcade equivalent"
FUNC_MAPPINGS = dict({
#Date functions start
    "today" :                  "Today",
    "now" :                    "Now",
    "decimal-date-time" :      "decimal_date_time",
    "date" :                   "Date",
    "decimal-time" :           "decimal_time",
    "format-date" :            "Text",
    "format-date-time" :       "Text",
    "date-time" :              "Date",     
#Date functions end
#Logical functions start
    "if" :                     "IIf",
#Logical functions end
#Math functions start
    "round" :                  "Round",
    "int" :                    "Number",
    "number" :                 "Number",
    "pow" :                    "Pow",
    "log" :                    "Log",
    "log10" :                  "Log10",
    "abs" :                    "Abs",
    "sin" :                    "Sin",
    "cos" :                    "Cos",
    "tan" :                    "Tan",
    "asin" :                   "Asin",
    "acos" :                   "Acos",
    "atan" :                   "Atan",
    "atan2" :                  "Atan2",
    "sqrt" :                   "Sqrt",
    "exp" :                    "Exp",
    "exp10" :                  "Exp10",
    "Pi" :                     "Pi_",
#Math functions end
#String functions start
    "concat" :                 "Concatenate",
    "join" :                   "NotImplementedOrSupported",
    "regex" :                  "NotImplementedOrSupported",
    "contains" :               "contains_string",
    "starts-with" :            "starts_with",
    "ends-with" :              "ends_with",
    "substr" :                 "Substr",
    "substring-before" :       "substring_before", 
    "substring-after" :        "substring_after", 
    "translate" :              "Replace",
    "string-length" :          "Count",
    "normalize-space" :        "normalize_space",
    "boolean-from-string" :    "bool_from_string",
    "string" :                 "Text",
    "digest" :                 "NotImplementedOrSupported",
    "base64-decode" :          "NotImplementedOrSupported",
#String functions end
#Utility functions start
    "random" :                 "Random",
    "uuid" :                   "Guid",
    "boolean" :                "Boolean",
    "not" :                    "Not",
    "coalesce" :               "coalesce",
    "checklist" :              "Checklist",
    "true" :                   "true",
    "false" :                  "false",
    "version" :                "NotImplementedOrSupported",
#Utility functions end
#Select and repeat functions start
    "count-selected" :         "NotImplementedOrSupported",  
    "count" :                  "NotImplementedOrSupported",
    "indexed-repeat" :         "NotImplementedOrSupported",
    "jr:choice-name" :         "NotImplementedOrSupported",
    "selected" :               "NotImplementedOrSupported",
    "selected-at" :            "NotImplementedOrSupported",
    "sum" :                    "NotImplementedOrSupported",
    "count-non-empty" :        "NotImplementedOrSupported",
    "indexed-repeat" :         "NotImplementedOrSupported",
#Select and repeat functions end    
#other functions start
    "max" :                    "Max",
    "min" :                    "Min",
    "once" :                   "NotImplementedOrSupported",
    "positon" :                "NotImplementedOrSupported",
    "jr:itext" :               "NotImplementedOrSupported", 
#other functions end    
#pulldata functions start
    "pulldata" :               "NotImplementedOrSupported"
#pulldata functions end
})

#i.e. ODK functions which we do not need to inject a function for
FUNCTIONS_WITH_DIRECT_REPLACEMENT = [
                                    "concat",
                                    "false",
                                    "date",
                                    "datetime",
                                    "format-date",
                                    "format-date-time",
                                    "if",
                                    "int",
                                    "max",
                                    "min",
                                    "now",
                                    "number",
                                    "random",
                                    "string",
                                    "string-length",
                                    "true",
                                    "uuid",
                                    "acos",
                                    "asin",
                                    "atan",
                                    "atan2",
                                    "cos",
                                    "sin",
                                    "tan",
                                    "exp",
                                    "log",
                                    "pow",
                                    "round",
                                    "sqrt",
                                    "abs",
                                    "translate",
                                    "uuid",
                                 ]

UNIMPLEMENTED_FUNCTION_DEF = "NotImplementedOrSupported(Concatenate(\""

UNIMPLEMENTED_FUNCTION_NAME = "NotImplementedOrSupported"

class ODKTokenType(Enum):
    UNKNOWN = 0
    NUMBER = 1
    NODE = 2
    STRING = 3
    OPERATOR = 4
    FUNCTION = 5
    SYMBOL = 6
    PULLDATA = 7
    PULLDATA_EXIF = 8
    PULLDATA_JAVASCRIPT = 9
    PULLDATA_PROPERTY = 10

class ODKTokenState(Enum):
    PRIMARY = 1
    OPERATION = 2
    POST_OPERATION = 3

class ODKParser:
    def __init__(self):
        self.expression = ""
        self.cursor = 0
        self.is_valid = True
        self.matched_string = ""
        self.tokens = [ ]
        self.functionsAdded = []      
        self.func_name = ""
        self.func_token = None  

    def parse_expression(self, expression: str) -> bool:
        self.expression = expression
        self.cursor = 0
        self.is_valid = True
        self.matched_string = ""
        self.tokens.clear()
        self.is_valid = self.__parse_expr() and self.__finished()
        return self.is_valid

    def __parse_expr(self) -> bool:
        return self.__parse_logical_or()

    def __parse_logical_or(self) -> bool:
        return self.__parse_binary_operation(r'^(or)', self.__parse_logical_and)

    def __parse_logical_and(self) -> bool:
        return self.__parse_binary_operation(r'^(and)', self.__parse_equality)

    def __parse_equality(self) -> bool:
        return self.__parse_binary_operation(r'^(=|!=)', self.__parse_comparison)

    def __parse_comparison(self) -> bool:
        return self.__parse_binary_operation(r'^(<=|<|>=|>)', self.__parse_sum)

    def __parse_sum(self) -> bool:
        return self.__parse_binary_operation(r'^(\+|\-)', self.__parse_product)

    def __parse_product(self) -> bool:
        return self.__parse_binary_operation(r'^(\*|div|mod)', self.__parse_primary)

    def __parse_primary(self) -> bool:
        if self.__parse_node():
            self.tokens.append([ ODKTokenType.NODE, ODKTokenState.PRIMARY, self.matched_string, None ])
            return True
        if self.__parse_pattern(r'^(-?(?:\d+\.\d+|\d+))'):
            self.tokens.append([ ODKTokenType.NUMBER, ODKTokenState.PRIMARY, self.matched_string, None ])
            return True
        if self.__parse_string():
            return True
        if self.__parse_function():
            return True
        index = self.cursor
        if self.__parse_pattern(r'^(\()'):
            if not self.__parse_expr():
                self.cursor = index
                return False
            if not self.__parse_pattern(r'^(\))'):
                self.cursor = index
                return False
            return True
        return False

    def __finished(self) -> bool:
        m = re.search(r'(\s+)', self.expression[self.cursor:])
        if m is not None:
            self.cursor += len(m.group())
        return self.cursor >= len(self.expression)
    
    def __parse_pattern(self, pattern: str) -> bool:
        m = re.search(r'^(\s+)', self.expression[self.cursor:])
        if m is not None:
            self.cursor += len(m.group())
        m = re.search(pattern, self.expression[self.cursor:])
        if m is None:
            return False
        self.matched_string = m.group()
        self.cursor += len(m.group())
        m = re.search(r'^(\s+)', self.expression[self.cursor:])
        if m is not None:
            self.cursor += len(m.group())
        return True

    def __parse_node(self) -> bool:
        if self.__parse_pattern(r'^(\.\.?)'):
            return True
        if self.__parse_pattern(r'^((?:\/[A-Za-z_][A-Za-z0-9_-]*)+)'):
            return True
        index = self.cursor
        if not self.__parse_pattern(r'^(\${)'):
            return False
        if not self.__parse_pattern(r'^([A-Za-z_][A-Za-z0-9_-]*)'):
            self.cursor = index
            return False
        node_name = self.matched_string
        if not self.__parse_pattern(r'^(})'):
            self.cursor = index
            return False
        self.matched_string = node_name
        return True

    def __parse_binary_operation(self, pattern: str, parse_next: str) -> bool:
        if not parse_next():
            return False
        index = self.cursor
        while self.__parse_pattern(pattern):
            operator = self.matched_string
            self.tokens.append([ ODKTokenType.OPERATOR, ODKTokenState.OPERATION, operator])
            if not parse_next():
                self.cursor = index
                return False
            self.tokens.append([ ODKTokenType.OPERATOR, ODKTokenState.POST_OPERATION, operator])
            index = self.cursor
        return True

    def __parse_string(self) -> bool:
        if self.__parse_quoted_string(r'^(\')', r'^([^\']*)'):
            return True
        if self.__parse_quoted_string(r'^(\")', r'^([^\"]*)'):
            return True
        return False

    def __parse_quoted_string(self, quote_pattern: str, body_pattern: str) -> bool:
        index = self.cursor
        if not self.__parse_pattern(quote_pattern):
            return False
        index2 = self.cursor
        if self.__parse_node():
            node_name = self.matched_string
            if self.__parse_pattern(quote_pattern):
                self.tokens.append([ ODKTokenType.NODE, ODKTokenState.PRIMARY, node_name, None ])
                return True
            self.cursor = index2
        if not self.__parse_pattern(body_pattern):
            self.cursor = index
            return False
        txt = self.matched_string
        if not self.__parse_pattern(quote_pattern):
            self.cursor = index
            return False
        self.tokens.append([ ODKTokenType.STRING, ODKTokenState.PRIMARY, txt, None ])
        return True

    def __parse_function(self) -> bool:
        index = self.cursor
        if not self.__parse_pattern(r'^([A-Za-z_][A-Za-z0-9_:-]*)'):
            return False

        self.func_name = self.matched_string
        self.func_type = ODKTokenType.FUNCTION

        if not self.__parse_pattern(r'^(\()'):
            self.cursor = index
            return False

        if self.__parse_pattern(r'^(\))'):
            self.tokens.append([ ODKTokenType.FUNCTION, ODKTokenState.OPERATION, self.func_name, 0])
            self.tokens.append([ ODKTokenType.FUNCTION, ODKTokenState.POST_OPERATION, self.func_name, 0])
            return True

        self.tokens.append([ ODKTokenType.FUNCTION, ODKTokenState.OPERATION, self.func_name, None])
        self.func_token = self.tokens[-1]

        if self.func_token[2] == 'pulldata':
            self.__parse_function_pulldata()

        if not self.__parse_expr():
            return False
        arg_count = 1
        while self.__parse_pattern(r'^(,)'):
            self.tokens.append([ ODKTokenType.SYMBOL, ODKTokenState.OPERATION, self.matched_string, None])
            if not self.__parse_expr():
                self.cursor = index
                return False
            arg_count = arg_count + 1
        if not self.__parse_pattern(r'^(\))'):
            self.cursor = index
            return False
        self.tokens.append([ self.func_type, ODKTokenState.POST_OPERATION, self.func_name, arg_count])
        self.func_token[3] = arg_count
        return True
    
    def __parse_function_pulldata(self) -> bool:
        self.tokens.pop()

        self.func_type = ODKTokenType.PULLDATA

        if not self.__parse_string():
            return False

        self.func_name = self.tokens[-1][2]
        self.tokens.pop()

        if not self.__parse_pattern(r'^(,)'):
            return False

        if self.func_name == '@javascript':
            self.func_type = ODKTokenType.PULLDATA_JAVASCRIPT
            if not self.__parse_string():
                return False
            self.func_name = self.tokens[-1][2]
            self.tokens.pop()
            if not self.__parse_pattern(r'^(,)'):
                return False
            self.tokens.append([ self.func_type, ODKTokenState.OPERATION, self.func_name, None])
            self.func_token = self.tokens[-1]
        elif self.func_name == '@exif':
            self.func_type = ODKTokenType.PULLDATA_EXIF
            self.tokens.append([ self.func_type, ODKTokenState.OPERATION, self.func_name, None])
            self.func_token = self.tokens[-1]
        elif self.func_name == '@property':
            self.func_type = ODKTokenType.PULLDATA_PROPERTY
            self.tokens.append([ self.func_type, ODKTokenState.OPERATION, self.func_name, None])
            self.func_token = self.tokens[-1]
        else:
            self.tokens.append([ self.func_type, ODKTokenState.OPERATION, self.func_name, None])
            self.func_token = self.tokens[-1]

    def odk_to_arcade_expression(self) -> str:
        arcade_expression = ""
        for t in self.tokens:
            match t[0]:
                case ODKTokenType.NUMBER:
                    arcade_expression += f'{t[2]} '
                case ODKTokenType.NODE:
                    arcade_expression += f'$feature.{get_node_field_name(t[2])} '
                case ODKTokenType.STRING:
                    arcade_expression += f'\'{t[2]}\' '
                case ODKTokenType.OPERATOR:
                    if t[1] == ODKTokenState.OPERATION:
                        operator = t[2]
                        if operator in TOKEN_MAPPINGS:
                            operator = TOKEN_MAPPINGS[operator]
                        arcade_expression += f'{operator} '
                case ODKTokenType.FUNCTION:
                    func_name = t[2]
                    if func_name in FUNC_MAPPINGS:
                        func_name = FUNC_MAPPINGS[func_name]
                    if t[3] == 0:
                        if t[1] == ODKTokenState.OPERATION:
                            if t[2] == 'true':
                                arcade_expression += f'true '
                            elif t[2] == 'false':
                                arcade_expression += f'false '
                            elif t[2] == 'version':
                                arcade_expression += f'{UNIMPLEMENTED_FUNCTION_DEF}version"))'
                            else:
                                arcade_expression += f'{func_name}() '
                    else:
                        if t[1] == ODKTokenState.OPERATION:
                            arcade_expression += f'{func_name}( '
                        if t[1] == ODKTokenState.POST_OPERATION:
                            arcade_expression += f") "
                case ODKTokenType.PULLDATA:
                    if t[1] == ODKTokenState.OPERATION:
                        arcade_expression += f'{UNIMPLEMENTED_FUNCTION_DEF} ", "{ODKTokenType.PULLDATA.name} ", "{t[2]} ",'
                    if t[1] == ODKTokenState.POST_OPERATION:
                        arcade_expression += f")) "
                case ODKTokenType.PULLDATA_JAVASCRIPT:
                    if t[1] == ODKTokenState.OPERATION:
                        arcade_expression += f'{UNIMPLEMENTED_FUNCTION_DEF} ", "{ODKTokenType.PULLDATA_JAVASCRIPT.name} ", "{t[2]} ",'
                    if t[1] == ODKTokenState.POST_OPERATION:
                        arcade_expression += f")) "
                case ODKTokenType.PULLDATA_EXIF:
                    if t[1] == ODKTokenState.OPERATION:
                        arcade_expression += f'{UNIMPLEMENTED_FUNCTION_DEF} ", "{ODKTokenType.PULLDATA_EXIF.name} ", "{t[2]} ",'
                    if t[1] == ODKTokenState.POST_OPERATION:
                        arcade_expression += f")) "
                case ODKTokenType.PULLDATA_PROPERTY:
                    if t[1] == ODKTokenState.OPERATION:
                        arcade_expression += f'{UNIMPLEMENTED_FUNCTION_DEF} ", "{ODKTokenType.PULLDATA_PROPERTY.name} ", "{t[2]} ",'
                    if t[1] == ODKTokenState.POST_OPERATION:
                        arcade_expression += f")) "
                case ODKTokenType.SYMBOL:
                    arcade_expression += f"{t[2]} "
        return arcade_expression  

    def get_arcade_function(self, functionName: str) -> str:
        if functionName not in self.functionsAdded and functionName not in FUNCTIONS_WITH_DIRECT_REPLACEMENT:
            self.functionsAdded.append(functionName)
            match functionName: 
                #function name in this switch matches the ODK function name.
                case "boolean-from-string":
                    return arcadeFunctions.bool_from_string
                case "coalesce":
                    return arcadeFunctions.coalesce
                case "contains":
                    return arcadeFunctions.contains
                case "decimal-date-time":
                    return arcadeFunctions.decimal_date_time
                case "decimal-time":
                    return arcadeFunctions.decimal_time
                case "ends-with":
                    return arcadeFunctions.ends_with
                case "not":
                    return arcadeFunctions.not_
                case "starts-with":
                    return arcadeFunctions.startswith
                case "SubStr":
                    return arcadeFunctions.Substr
                case "today":
                    return arcadeFunctions.Today
                case "exp10":
                    return arcadeFunctions.Exp10
                case "log10":
                    return arcadeFunctions.Log10
                case "Pi":
                    return arcadeFunctions.Pi_
                case "substring-before":
                    return arcadeFunctions.substring_before
                case "substring-after":
                    return arcadeFunctions.substring_after
                case "normalize-space":
                    return arcadeFunctions.normalize_space
                case "checklist":
                    return arcadeFunctions.checklist
                case _:
                    if UNIMPLEMENTED_FUNCTION_NAME not in self.functionsAdded:
                        self.functionsAdded.append(UNIMPLEMENTED_FUNCTION_NAME)
                        return arcadeFunctions.unimplemented
        return ""
    
def get_node_field_name(node_name: str) -> str:
    return node_name[node_name.rindex('/')+1:]
