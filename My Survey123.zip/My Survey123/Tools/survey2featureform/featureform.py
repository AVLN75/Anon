"""
Copyright © 2025 ESRI

Trade Secrets: ESRI Proprietary and Confidential
Unpublished material - all rights reserved under the
Copyright Laws of the United States.

For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts Dept
380 New York Street
Redlands, California, USA 92373

Email: contracts@esri.com
"""

import logging
from pprint import pformat
import json
import openpyxl
from openpyxl import Workbook
import xml.etree.ElementTree as ET 
from arcgis.features import FeatureLayer, Table
import openpyxl.worksheet
import openpyxl.worksheet.worksheet
from openpyxl.styles import Font, PatternFill, Alignment
from bs4 import BeautifulSoup
from survey import Survey

import xforms as XF
from xforms import XForm, XControl, XBinding
import xpath as XPath

def jformat(object:object):
    return json.dumps(object, ensure_ascii=False, indent=4) if isinstance(object, dict) or isinstance(object, list) else pformat(object)

#-------------------------------------------------------------------------------

EXPR_TRUE:str = "expr/system/true"
EXPR_FALSE:str =  "expr/system/false"

VALUE_TYPE_BOOLEAN:str = "boolean"
VALUE_TYPE_STRING:str = "string"
VALUE_TYPE_NUMBER:str = "number"
VALUE_TYPE_DATE:str = "date"
VALUE_TYPE_DATEONLY:str = "dateOnly"
VALUE_TYPE_TIME:str = "time"

FIELD_TYPE_NULL:str = "null"
FIELD_TYPE_STRING:str = "esriFieldTypeString"
FIELD_TYPE_INTEGER:str = "esriFieldTypeInteger"
FIELD_TYPE_FLOAT:str = "esriFieldTypeSingle"
FIELD_TYPE_DOUBLE:str = "esriFieldTypeDouble"
FIELD_TYPE_DATE:str = "esriFieldTypeDate"
FIELD_TYPE_DATEONLY:str = "esriFieldTypeDateOnly"
FIELD_TYPE_TIMEONLY:str = "esriFieldTypeTimeOnly"
FIELD_TYPE_TIMESTAMP_OFFSET:str = "esriFieldTypeTimestampOffset"

ELEMENT_TYPE_FIELD:str = "field"
ELEMENT_TYPE_ATTACHMENT:str = "attachment"
ELEMENT_TYPE_GROUP:str = "group"
ELEMENT_TYPE_RELATIONSHIP:str = "relationship"
ELEMENT_TYPE_TEXT:str = "text"

STATUS_OK:int = 0
STATUS_WARNING:int = 1
STATUS_UNSUPPORTED:int = 2

SYMBOL_FORM:str = "📝"
SYMBOL_OK:str = "✔️"
SYMBOL_WARNING:str = "⚠️"
SYMBOL_UNSUPPORTED:str = "⛔" # "❌" "🚫"

OPTION_NOATTACHMENTELEMENT: str = "noattachmentelement"
OPTION_NORELATIONSHIPELEMENT: str = "norelationshipelement"
OPTION_NODATEPICKERINPUT: str = "nodatepickerinput"
OPTION_NOTIMEINPUT: str = "notimeinput"
OPTION_NESTEDGROUPS: str = "nestedgroups"
OPTION_CUSTOMPROPERTIES: str = "customproperties"
OPTION_INLINEDOMAINS: str = "inlinedomains"
OPTION_CHOICES: list = [
    OPTION_NOATTACHMENTELEMENT,
    OPTION_NORELATIONSHIPELEMENT,
    OPTION_NODATEPICKERINPUT, 
    OPTION_NOTIMEINPUT,
    OPTION_NESTEDGROUPS,
    OPTION_CUSTOMPROPERTIES,
    OPTION_INLINEDOMAINS
    ]

#-------------------------------------------------------------------------------

class FeatureForm:
    survey: Survey
    xform: XForm
    app: str
    layer: FeatureLayer
    options: list
    wb: Workbook
    ws: openpyxl.worksheet.worksheet.Worksheet
    status_count: list


    def __init__(self, survey:Survey, options:list = [], wb:Workbook = None):
        self.survey = survey
        self.xform = survey.xform
        self.options = options
        self.wb = wb

    # https://developers.arcgis.com/web-map-specification/objects/formFieldElement/

    def process_input(self, formInfo: dict, xcontrol: XControl) -> dict:
        # print("Input:", input_element.tag, "attributes:", input_element.attrib)

        if self.is_generated_note(xcontrol):
            return self.process_note(formInfo, xcontrol)
        
        if xcontrol.binding.esri_field_type == FIELD_TYPE_NULL:
            return self.process_null_field(formInfo, xcontrol)

        inputType: dict = {
            "type": "text-box" 
        }

        if xcontrol.binding.type == XF.BIND_TYPE_STRING:
            if xcontrol.take_appearance('multiline'):
                inputType["type"] = 'text-area'

        elif xcontrol.binding.type == XF.BIND_TYPE_BARCODE:
            inputType["type"] = 'barcode-scanner'

        elif xcontrol.binding.type == XF.BIND_TYPE_INT or xcontrol.binding.type == XF.BIND_TYPE_DECIMAL:
            pass

        elif xcontrol.binding.type == XF.BIND_TYPE_DATETIME:
            inputType["type"] = 'datetime-picker'
            inputType["includeTime"] = True

        elif xcontrol.binding.type == XF.BIND_TYPE_DATE:
            if OPTION_NODATEPICKERINPUT in self.options:
                xcontrol.status = STATUS_WARNING
                xcontrol.add_message(f"Using date time picker input type, date picker input disabled by option: {OPTION_NODATEPICKERINPUT}")
                inputType["type"] = 'datetime-picker'
                inputType["includeTime"] = False
            else:
                inputType["type"] = 'date-picker'

        elif xcontrol.binding.type == XF.BIND_TYPE_TIME:
            inputType["type"] = 'text-box'
            # TODO Get field type from feature service to select correct input type
            # if OPTION_NODATEPICKERINPUT in self.options:
            #     logging.warning("time-picker disabled: %s", OPTION_NOTIMEINPUT)
            #     inputType["type"] = 'datetime-picker'
            #     inputType["includeTime"] = True
            # else:
            #     inputType["type"] = 'time-picker'

        elif xcontrol.binding.type == XF.BIND_TYPE_GEOPOINT:
            self.process_geopoint(formInfo, xcontrol)
            return
        
        elif xcontrol.binding.type == XF.BIND_TYPE_GEOTRACE:
            self.process_geotrace(formInfo, xcontrol)
            return
        
        elif xcontrol.binding.type == XF.BIND_TYPE_GEOSHAPE:
            self.process_geoshape(formInfo, xcontrol)
            return
        
        else:
            logging.warning("Unhandled input bind type: %s", xcontrol.binding.type)
            return
        
        formElement: dict = {
            "fieldName": xcontrol.binding.field_name, 
            "label": xcontrol.label_text,
            "description": xcontrol.hint_text,
            "hint": xcontrol.guidance_hint_text,
            "type": ELEMENT_TYPE_FIELD,
            "inputType": inputType,
        }

        if xcontrol.esri_input_mask is not None:
            xcontrol.status = STATUS_WARNING
            xcontrol.add_message(f'Input mask is unsupported ({xcontrol.esri_input_mask})')

        return formElement

    def process_geopoint(self, formInfo: dict, xcontrol: XControl) -> dict:
        if formInfo["settings"].get('geometry') is not None:
            logging.warning("geopoint: Multiple geo* elements")
            return
        
        geometry = self.process_geo(formInfo, xcontrol)

        # TODO geopoint specific properties

        accuracyThreshold = xcontrol.element.attrib.get('accuracyThreshold')
        if accuracyThreshold is not None:
            geometry["miminumHorizontalAccuracy"] = float(accuracyThreshold)

        return None # geometry

    def process_geotrace(self, formInfo: dict, xcontrol: XControl) -> dict:
        if formInfo["settings"].get('geometry') is not None:
            logging.warning("geotrace: Multiple geo* elements")
            return
        
        geometry = self.process_geo(formInfo, xcontrol)

        # TODO geotrace specific properties

        return None # geometry

    def process_geoshape(self, formInfo: dict, xcontrol: XControl) -> dict:
        if formInfo["settings"].get('geometry') is not None:
            logging.warning("geoshape: Multiple geo* elements")
            return
        
        geometry = self.process_geo(formInfo, xcontrol)

        # TODO geoshape specific properties

        return None # geometry
    
    def process_geo(self, formInfo: dict, xcontrol: XControl) -> dict:

        xcontrol.status = STATUS_UNSUPPORTED
        xcontrol.add_message(f"Geometry type {xcontrol.binding.type} is not supported as a form element")

        geometry = {
            "label": xcontrol.label_text,
            "description": xcontrol.hint_text,
            "visible": True,
            "editable": True,
            "required": False,
            "expanded": True,
            "layoutOptions": "top",
        }
        
        formInfo["settings"]["geometry"] = geometry

        return geometry

    # https://developers.arcgis.com/web-map-specification/objects/formTextElement/
    # https://doc.arcgis.com/en/survey123/desktop/create-surveys/xlsformnotes.htm

    def process_note(self, formInfo: dict, xcontrol: XControl) -> dict:

        formSettings = formInfo["settings"]

        if xcontrol.binding.calculate_expression is not None:
            xcontrol.status = STATUS_WARNING
            xcontrol.add_message(f"Calculation expressions in notes are not supported")
 
        match xcontrol.binding.field_name:
            case 'generated_note_form_title':
                formInfo["title"] = xcontrol.label_text
                return
            
            case 'generated_note_form_submit_text':
                formSettings["submitLabel"] = xcontrol.label_text
            
            case 'generated_note_form_footer':
                formSettings["footerLabel"] = xcontrol.label_text
            
            case 'generated_note_prompt_submitted':
                formSettings["postSubmitPromptMessage"] = xcontrol.label_text
            
            case _: 
                return {
                    "type": ELEMENT_TYPE_TEXT,
                    "textFormat": "markdown",
                    "text": xcontrol.label_text
                }

        xcontrol.status = STATUS_UNSUPPORTED
        xcontrol.add_message(f"Unsupported note field")

    def process_null_field(self, formInfo: dict, xcontrol: XControl) -> dict:
        xcontrol.status = STATUS_UNSUPPORTED
        xcontrol.add_message(f"Null fields types are not supported as form elements")

    def process_range(self, formInfo: dict, xcontrol: XControl) -> dict:

        xcontrol.status = STATUS_WARNING
        xcontrol.add_message("Range is converted, but may not be supported in all apps.")

        start = xcontrol.element.attrib.get('start')
        end = xcontrol.element.attrib.get('end')
        step = xcontrol.element.attrib.get('step')
        if step is not None and step != "1":
            xcontrol.add_message(f"Range step parameter not supported (step={step})")

        domain = { 
            "type": "range",
            "name": f"range_{xcontrol.binding.field_name}",
            "range": [
                start if start is not None else 0, 
                end if end is not None else 10]}

        formElement: dict = {
            "fieldName": xcontrol.binding.field_name, 
            "label": xcontrol.label_text, 
            "description": xcontrol.hint_text,
            "type": ELEMENT_TYPE_FIELD,
            "inputType": {
                "type": "text-box",
            },
            "domain": domain
        }

        return formElement


    # https://developers.arcgis.com/web-map-specification/objects/formComboBoxInput/
    # https://developers.arcgis.com/web-map-specification/objects/formRadioButtonsInput/
    
    def process_select1(self, formInfo: dict, xcontrol: XControl) -> dict:

        for appearance in xcontrol.appearances:
            if appearance.startswith('search('):
                xcontrol.status = STATUS_UNSUPPORTED
                xcontrol.add_message(f"search() choice lists are not supported")
                xcontrol.appearances.remove(appearance)
                return

        itemset_element = xcontrol.element.find('xforms:itemset', XF.XFORMS_NS)
        if itemset_element is not None:
            xcontrol.status = STATUS_UNSUPPORTED
            xcontrol.add_message(f"Filtered choice lists are not supported")
            return

        formElement = {
            "fieldName": xcontrol.binding.field_name,
            "label": xcontrol.label_text, 
            "description": xcontrol.hint_text,
            "type": ELEMENT_TYPE_FIELD
        }

        if xcontrol.field_info.get("domain") is None or OPTION_INLINEDOMAINS in self.options:
            domain = self.get_domain_codeValues(xcontrol)
            formElement["domain"] = domain
        else:
            domain = xcontrol.field_info["domain"]

        codedValues = xcontrol.field_info["domain"].get("codedValues")


        if xcontrol.take_appearances(['minimal']):
            input_type = "combo-box"
        elif len(codedValues) <= 5:
            input_type = 'radio-buttons'
        else:
            input_type = "combo-box"

        required_expresion = self.get_boolean_expression_name(formInfo, xcontrol.binding, "required")
        show_no_value_option = xcontrol.field_info.get("nullable") == True and required_expresion is None
        if xcontrol.take_appearance("list-nolabel"):
            show_no_value_option = False

        formElement["inputType"] = {
            "type": input_type,
            "noValueOptionLabel": "No value" if show_no_value_option else None,
            "showNoValueOption": show_no_value_option
            }

        return formElement
    
    def get_domain_codeValues(self, xcontrol: XControl) -> dict:
        items = xcontrol.element.findall('xforms:item', XF.XFORMS_NS)

        codedValues:list = []

        for item in items:
            value_element = item.find('xforms:value', XF.XFORMS_NS)
            codedValues.append({
                    "code": value_element.text,
                    "name": self.xform.get_itext(item.find('xforms:label', XF.XFORMS_NS))
                    })

        return { 
            "type": "codedValue",
            "name": f"codedValues_{xcontrol.binding.field_name}",
            "codedValues": codedValues
            }

    # https://developers.arcgis.com/web-map-specification/objects/formAttachmentElement/

    def process_upload(self, formInfo: dict, xcontrol: XControl):
        if OPTION_NOATTACHMENTELEMENT in self.options:
            xcontrol.status = STATUS_UNSUPPORTED
            xcontrol.add_message(f"Attachment element disabled by option: {OPTION_NOATTACHMENTELEMENT}")
            return

        if logging.debug_level > 0:
            logging.debug("Upload: %s attributes: %s", xcontrol.element.tag, xcontrol.element.attrib)

        media_type = xcontrol.element.attrib.get('mediatype')

        if media_type.startswith('image/'):
            if xcontrol.take_appearance('signature'):
                inputType: dict = {
                    "type": "signature",
                    "inputMethod": "capture"
                }
            else:
                inputType: dict = {
                    "type": "image",
                    "inputMethod": "any"
                }

        elif media_type.startswith('audio'):
            inputType: dict = {
                "type": "audio",
                "inputMethod": "any"
            }

        elif media_type.startswith('video/'):
            inputType: dict = {
                "type": "video",
                "inputMethod": "any"
            }

        else:
            inputType: dict = {
                "type": "document"
            }


        formElement: dict = {
            "allowUserRename" : True,
            "attachmentKeyword": xcontrol.binding.field_name, 
            "description": xcontrol.hint_text,
            "displayFilename" : True,
            "inputType": inputType,
            "label": xcontrol.label_text, 
            "type": ELEMENT_TYPE_ATTACHMENT,
            "useOriginalFilename" : True
        }

        if xcontrol.binding.required_expression is not None:
            if xcontrol.binding.required_expression == XF.XPATH_FALSE:
                pass

            formElement["minAttachmentCount"] = 1
            
            if xcontrol.binding.required_expression != XF.XPATH_TRUE:
                xcontrol.add_message("Required expressions are not supported for attachments, setting minAttachmentCount to 1")
                xcontrol.status = STATUS_WARNING

        self.set_editableExpression(formInfo, formElement, xcontrol)

        return formElement

    def process_control(self, formInfo: dict, group: dict, xcontrol: XControl) -> dict:
        formElement: dict

        if xcontrol.type == XF.CONTROL_TYPE_INPUT:
            formElement = self.process_input(formInfo, xcontrol)
            
        elif xcontrol.type == XF.CONTROL_TYPE_RANGE:
            formElement = self.process_range(formInfo, xcontrol) 
            
        elif xcontrol.type == XF.CONTROL_TYPE_RANK:
            xcontrol.status = STATUS_UNSUPPORTED
            xcontrol.add_message(f"Rank questions are not supported")
            return
            
        elif xcontrol.type == XF.CONTROL_TYPE_SELECT:
            xcontrol.status = STATUS_UNSUPPORTED
            xcontrol.add_message(f"Multiple selection questions are not supported")
            return
            
        elif xcontrol.type == XF.CONTROL_TYPE_SELECT1:
            formElement = self.process_select1(formInfo, xcontrol) 
            
        elif xcontrol.type == XF.CONTROL_TYPE_UPLOAD:
            formElement = self.process_upload(formInfo, xcontrol)
            
        else:
            xcontrol.status = STATUS_UNSUPPORTED
            xcontrol.add_message(f"Unsupported control type: {xcontrol.type}")
            return

        
        if formElement is None:
            return
        
        if formElement["type"] == ELEMENT_TYPE_FIELD:
            formElement["hint"] = xcontrol.guidance_hint_text
            self.set_requiredExpression(formInfo, formElement, xcontrol)
            if self.set_valueExpression(formInfo, formElement, xcontrol) is None:
                self.set_editableExpression(formInfo, formElement, xcontrol)


        if OPTION_CUSTOMPROPERTIES in self.options:
            properties: dict = {}

            appearance = xcontrol.element.attrib.get('appearance')
            if appearance is not None:
                properties["appearance"] = appearance

            if xcontrol.binding.default_value is not None:
                properties["defaultValue"] = xcontrol.binding.default_value

            if len(properties) > 0:
                formElement["properties"] = properties

        for key in list(formElement.keys()):
            if formElement[key] is None:
                del formElement[key]

        if group is not None:
            group["formElements"].append(formElement)
        else:
            formInfo["formElements"].append(formElement)

        return formElement

    # https://developers.arcgis.com/web-map-specification/objects/formGroupElement/
    
    def process_group(self, formInfo: dict, group: dict, xcontrol: XControl) -> dict:
        logging.debug("Group: %s attributes: %s", xcontrol.type, xcontrol.element.attrib)

        formElement = {
            "type": ELEMENT_TYPE_GROUP,
            "label": xcontrol.label_text,
            "initialState": "collapsed" if xcontrol.take_appearance("compact") else "expanded",
            "formElements": [],
        }

        if xcontrol.take_appearance("field-list"):
            xcontrol.status = STATUS_UNSUPPORTED
            xcontrol.add_message(f"Field list appearance is not supported")
            self.process_elements(formInfo, None if group is None else group, xcontrol.element)
            return

        self.process_elements(formInfo, formElement, xcontrol.element)

        if OPTION_NESTEDGROUPS in self.options and group is not None:
            group["formElements"].append(formElement)
        else:
            if group is None:
                formInfo["formElements"].append(formElement)
            else:
                group["formElements"].append({
                    "type": ELEMENT_TYPE_TEXT,
                    "textFormat": "markdown",
                    "text": formElement["label"]
                    })

                for element in formElement["formElements"]:
                   group["formElements"].append(element)
                xcontrol.status = STATUS_WARNING
                xcontrol.add_message(f"Nested groups are not supported, the child elements were merged in to the parent group")
                return

        return formElement

    # https://developers.arcgis.com/web-map-specification/objects/formRelationshipElement/

    def process_repeat(self, formInfo:dict, group:dict, xcontrol:XControl):
        if OPTION_NORELATIONSHIPELEMENT in self.options:
            xcontrol.status = STATUS_UNSUPPORTED
            xcontrol.add_message(f"Releationship element disabled by option: {OPTION_NORELATIONSHIPELEMENT}")
            return
        
        layer = self.survey.get_layer_or_table_by_name(xcontrol.repeat_table_name)

        if xcontrol.repeat_count_nodeset is not None:
            xcontrol.status = STATUS_WARNING
            xcontrol.add_message(f"Repeat counts are not supported")
            return

        order_by_fields = []

        child_xcontrol:XControl
        for child in xcontrol.repeat_element:
            child_xcontrol = XF.XControl(self.xform, child)
            if child_xcontrol.binding.field_name is None:
                continue

            field_info = self.get_layer_field(child_xcontrol.binding.field_name, layer)
            if field_info is None:
                continue

            order_by_fields.append({
                "field": field_info["name"],
                "order": "asc"
            })
            break

        formElement: dict = {
            "label": xcontrol.label_text, 
            "type": ELEMENT_TYPE_RELATIONSHIP,
            "displayType": "list",
            "displayCount": 3,
            "relationshipId": self.get_relationship_id(xcontrol.repeat_table_name),
            "orderByFields": order_by_fields
            }
        
        self.set_editableExpression(formInfo, formElement, xcontrol)

        if group is not None:
            group["formElements"].append(formElement)
        else:
            formInfo["formElements"].append(formElement)

        return formElement
    
    def get_relationship_id(self, related_table_name) -> str:
        relationships = self.layer.properties.get("relationships")

        for relationship in relationships:
            related_table_id = relationship.get("relatedTableId")
            for layer in self.survey.service_layers.layers:
                if layer.properties.get("id") == related_table_id and layer.properties.get("name") == related_table_name:
                    return relationship.get("id")

            for table in self.survey.service_layers.tables:
                if table.properties.get("id") == related_table_id and table.properties.get("name") == related_table_name:
                    return relationship.get("id")
                
        print(f"Relationship not found for table: {related_table_name}")
        print(f"Properties: {jformat(self.layer.properties)}")
        exit(1)

    #--------------------------------------------------------------------------
    
    def set_visibilityExpression(self, formInfo:dict, formElement:dict, xcontrol:XControl) -> str:
        if xcontrol.binding.relevant_expression is None:
            return
        
        expr_name = self.get_boolean_expression_name(formInfo, xcontrol.binding, 'relevant')

        if expr_name is not None:
            formElement["visibilityExpression"] = expr_name
            xcontrol.add_message(f"Relevant expression translated to visibility expression")

        if is_translated_expression(expr_name):
            xcontrol.has_arcade = True

        return expr_name

    def set_requiredExpression(self, formInfo:dict, formElement:dict, xcontrol:XControl) -> str:
        expr_name = self.get_boolean_expression_name(formInfo, xcontrol.binding, 'required')

        if expr_name is not None:
            formElement["requiredExpression"] = expr_name
            if is_translated_expression(expr_name):
                xcontrol.has_arcade = True
                xcontrol.add_message(f"Required expression translated to Arcade")

        return expr_name

    def set_editableExpression(self, formInfo:dict, formElement:dict, xcontrol:XControl) -> str:
        expr_name = self.get_boolean_expression_name(formInfo, xcontrol.binding, 'readonly', True)

        formElement["editableExpression"] = expr_name if expr_name is not None else EXPR_TRUE

        if expr_name is not None:
            xcontrol.add_message(f"Readonly expression translated to editable expression")

            if is_translated_expression(expr_name):
                xcontrol.has_arcade = True

        return expr_name

    def set_valueExpression(self, formInfo:dict, formElement:dict, xcontrol:XControl) -> str:
        if xcontrol.binding.calculate_expression is None:
            return

        match xcontrol.binding.type:
            case XF.BIND_TYPE_STRING:
                return_type = VALUE_TYPE_STRING

            case XF.BIND_TYPE_INT:
                return_type = VALUE_TYPE_NUMBER

            case XF.BIND_TYPE_DECIMAL:
                return_type = VALUE_TYPE_NUMBER
                
            case XF.BIND_TYPE_DATETIME:
                return_type = VALUE_TYPE_DATE
            
            case XF.BIND_TYPE_DATE:
                return_type = VALUE_TYPE_DATEONLY

            case XF.BIND_TYPE_TIME:
                return_type = VALUE_TYPE_TIME
            
            case _:
                return_type = VALUE_TYPE_STRING

        expr_name = self.add_xpath_expression(
            formInfo, 
            f"{xcontrol.binding.nodeset}/calculate", 
            None, 
            xcontrol.binding.calculate_expression, 
            return_type)
        
        formElement["valueExpression"] = expr_name
        formElement["editable"] = False

        if expr_name is not None:
            xcontrol.add_message(f"Calculation expression translated to value expression")

        if is_translated_expression(expr_name):
            xcontrol.has_arcade = True

        return formElement["valueExpression"]

    def get_boolean_expression_name(self, formInfo: dict, binding:XBinding, attribute:str, negate:bool = False) -> str:
        if binding.element is None:
            return
        
        xpath_expression = binding.element.attrib.get(attribute)
        if xpath_expression is None:
            return

        if xpath_expression == XF.XPATH_TRUE:
            if negate:
                return EXPR_FALSE
            else:
                return EXPR_TRUE
        elif xpath_expression == XF.XPATH_FALSE:
            if negate:
                return EXPR_TRUE
            else:
                return EXPR_FALSE
        else:
            return self.add_xpath_expression(
                formInfo, 
                f'{"not " if negate else ""}{binding.nodeset}/{attribute}', 
                None,
                f"not( {xpath_expression} )" if negate else xpath_expression, 
                VALUE_TYPE_BOOLEAN)

    # https://developers.arcgis.com/web-map-specification/objects/formExpressionInfo/

    def add_xpath_expression(self, formInfo:dict, name:str, title:str, xpath_expression:str, return_type:str) -> str:
        if xpath_expression == XF.XPATH_TRUE:    
            return EXPR_TRUE
        elif xpath_expression == XF.XPATH_FALSE:    
            return EXPR_FALSE

        expressionInfos = formInfo.get('expressionInfos')

        if title is None:
            title = name

        arcade_expression = escaped_text(XPath.xpath_to_arcade(xpath_expression))

        for expressionInfo in expressionInfos:
            if expressionInfo.get('expression') == arcade_expression and expressionInfo.get("returnType") == return_type:
                return expressionInfo.get('name')

        expressionInfo = {
            "name": name,
            "title": title,
            "expression": arcade_expression,
            "returnType": return_type,
        }

        expressionInfos.append(expressionInfo)

        formInfo["expressions"].append({
            "xpath": xpath_expression,
            "expressionInfo": expressionInfo
            })

        return name

    #--------------------------------------------------------------------------

    def process_elements(self, formInfo: dict, group: dict, element: ET.Element):

        formElement: dict

        for child in element:
            xcontrol = XF.XControl(self.xform, child)

            if xcontrol.type == XF.CONTROL_TYPE_LABEL: # Group label
                continue

            if xcontrol.binding.field_name is not None and xcontrol.binding.field_name.startswith('reserved_name_for_field_list'):
                continue

            self.initialize_control(xcontrol)
            self.ws_add_row(xcontrol)

            if xcontrol.type == XF.CONTROL_TYPE_GROUP:
                formElement = self.process_group(formInfo, group, xcontrol)

            elif xcontrol.type == XF.CONTROL_TYPE_REPEAT:
                formElement = self.process_repeat(formInfo, group, xcontrol)

            else:
                formElement = self.process_control(formInfo, group, xcontrol)   

            if formElement is not None:
                self.set_visibilityExpression(formInfo, formElement, xcontrol)

            xcontrol.formElement = formElement
            self.finalize_control(xcontrol)
            self.status_count[xcontrol.status] += 1
            self.ws_update_row(xcontrol)

    def initialize_control(self, xcontrol:XControl):
        xcontrol.field_info = self.get_layer_field(xcontrol.binding.field_name)

        xcontrol.has_arcade = False
        xcontrol.status = STATUS_OK

        if xcontrol.label_text is not None:
            plain_text = to_plain_text(xcontrol.label_text)
            if plain_text != xcontrol.label_text:
                xcontrol.add_message("HTML label converted to plain text")
                xcontrol.label_text = plain_text

            maxlen = 1000 if xcontrol.binding.field_name is not None and self.is_generated_note(xcontrol) else 255
            xcontrol.label_text = plain_text[:maxlen]
            if xcontrol.label_text is not None and len(xcontrol.label_text) < len(plain_text):
                xcontrol.add_message(f"Label truncated from {len(plain_text)} to {maxlen} characters")

        if xcontrol.hint_text is not None:
            plain_text = to_plain_text(xcontrol.hint_text)
            if plain_text != xcontrol.hint_text:
                xcontrol.add_message("HTML hint converted to plain text")
                xcontrol.hint_text = plain_text

            xcontrol.hint_text = plain_text[:255]
            if xcontrol.hint_text is not None and len(xcontrol.hint_text) < len(plain_text):
                xcontrol.add_message(f"Hint truncated from {len(plain_text)} to 255 characters")

        if xcontrol.guidance_hint_text is not None:
            plain_text = to_plain_text(xcontrol.guidance_hint_text)
            if plain_text != xcontrol.guidance_hint_text:
                xcontrol.add_message("HTML guidance hint converted to plain text")
                xcontrol.guidance_hint_text = plain_text

            xcontrol.guidance_hint_text = plain_text[:255]
            if xcontrol.guidance_hint_text is not None and len(xcontrol.guidance_hint_text) < len(plain_text):
                xcontrol.add_message(f"Guidance hint truncated from {len(plain_text)} to 255 characters")

        if xcontrol.esri_style is not None :
            xcontrol.add_message(f'Style is unsupported ({xcontrol.esri_style})')

        if xcontrol.esri_visible_expression is not None:
            xcontrol.add_message('Visible expressions and messages are unsupported')

        if xcontrol.binding.esri_workflow is not None:
            xcontrol.add_message(f'Workflow is unsupported ({xcontrol.binding.esri_workflow})')

        if xcontrol.binding.constraint_expression is not None:
            xcontrol.add_message('Constraint expressions and messages are unsupported')

        if xcontrol.binding.required_message is not None:
            xcontrol.add_message(f"Required messages are not supported")

        if xcontrol.binding.esri_warning_expression is not None:
            xcontrol.add_message('Warning expressions and messages are unsupported')

        if xcontrol.binding.default_value is not None:
            xcontrol.add_message(f'Default values are unsupported in form elements ({xcontrol.binding.default_value}), a feature template will be created.')

        if xcontrol.messages is not None and len(xcontrol.messages) > 0:
            xcontrol.status = STATUS_WARNING


    def finalize_control(self, xcontrol:XControl):
        if len(xcontrol.appearances) > 0:
            self.set_warning_status(xcontrol)
            xcontrol.add_message(f'One or more appearances are not supported ({", ".join(xcontrol.appearances)})')

        if xcontrol.has_arcade:
            self.set_warning_status(xcontrol)
            xcontrol.add_message(f'Translation of expressions to Arcade is limited, please check and adjust expression conversions to ensure they work as expected.')

    def set_warning_status(self, xcontrol:XControl):
        if xcontrol.status != STATUS_UNSUPPORTED:
            xcontrol.status = STATUS_WARNING

    def is_generated_note(self, xcontrol:XControl) -> bool:
        return xcontrol.binding.field_name is not None and (
            xcontrol.binding.field_name.startswith('generated_note_') or
            xcontrol.binding.field_name.startswith('generated_table_list_label_'))
        
    #--------------------------------------------------------------------------

    def get_form(self, layer:FeatureLayer, repeat_nodeset:str = None) -> dict:

        logging.debug("Layer: %s repeat_nodeset: %s", layer, repeat_nodeset)

        self.layer = layer

        self.status_count = [0, 0, 0] # [ok, warning, unsupported]
        self.initialize_worksheet()

        expressionInfo_true =  {
            "expression": "true",
            "name": EXPR_TRUE,
            "returnType": VALUE_TYPE_BOOLEAN,
            "title": "True"
        }

        expressionInfo_false = {
            "expression": "false",
            "name": EXPR_FALSE,
            "returnType": VALUE_TYPE_BOOLEAN,
            "title": "False"
        }

        formInfo = {
            "title": self.xform.title_element.text,
            "formElements": [],
            "preserveFieldValuesWhenHidden": False,
            "expressionInfos": [
                expressionInfo_true,
                expressionInfo_false
            ],
            "settings": {
                "displayStyle": "list",
                "groupDisplayStyle": "list",
            },
            "themes": [],
            "expressions": [
                {
                    "xpath": XF.XPATH_TRUE,
                    "expressionInfo": expressionInfo_true
                },
                {
                    "xpath": XF.XPATH_FALSE,
                    "expressionInfo": expressionInfo_false
                }
            ]
        }   
        
        templates:list = None
        if repeat_nodeset is not None:
            repeat_control = XF.XControl(self.xform, self.xform.get_repeat_group_element(repeat_nodeset))
            formInfo["title"] = repeat_control.label_text
            self.process_elements(formInfo, None, repeat_control.repeat_element)

            # repeat_element:ET.Element = self.xform.body_element.find(f'*/ns1:repeat[@nodeset="{repeat_nodeset}"]', XF.XFORMS_NS)
            # # formInfo["title"] = nodeset.split('/')[-1]
            # self.process_elements(formInfo, None, repeat_element)
        else:
            self.process_elements(formInfo, None, self.xform.body_element)
            templates = self.get_templates(formInfo)

        form = {
            "settings": formInfo["settings"],
            "themes": formInfo["themes"],
            "templates": templates
        }

        del formInfo["settings"]
        del formInfo["themes"]

        self.finalize_bindings()
        self.finalize_worksheet(formInfo)

        self.add_expressions_worksheeet(formInfo)
        del formInfo["expressions"]

        form["formInfo"] = formInfo
        form["status_count"] = self.status_count

        self.ws = None

        return form
    
    #--------------------------------------------------------------------------

    def get_templates(self, formInfo:dict) -> list:
        template = self.get_template(
            f'New {formInfo["title"]} feature',
            f'This template was created from the default values in {formInfo["title"]}')
        
        prototype = template["prototype"]
        if prototype is None:
            return None
        
        attributes = prototype.get("attributes")
        if attributes is None:
            return None
        
        if len(attributes.items()) == 0:
            return None 
        
        return [template]

    def get_template(self, name:str, description:str) -> dict:
        fields = self.layer.properties.get("fields")

        attributes: dict = {}

        self.instance2attributes(fields, f"/{self.xform.primary_instance_id}", self.xform.primary_instance_element, attributes)

        drawingTool:str = None

        match self.layer.properties.get("geometryType"):
            case "esriGeometryPoint":
                drawingTool = "esriFeatureEditToolPoint"

            case "esriGeometryPolyline":
                drawingTool = "esriFeatureEditToolLine"

            case "esriGeometryPolygon":
                drawingTool = "esriFeatureEditToolPolygon"

        template = {
            "name": name,
            "description": description,
            "drawingTool": drawingTool,       
            "prototype": {
                "attributes": attributes
            }
        }

        return template

    def instance2attributes(self, fields: list, nodeset_path: str, instance_element: ET.Element, attributes: dict):
        for value_element in instance_element:
            logging.debug("Value: %s attributes: %s", value_element.tag, value_element.attrib)

            fieldName = value_element.tag.split('}')[-1]
            if fieldName == 'meta':
                continue

            nodeset = f"{nodeset_path}/{fieldName}"
            field = find_field(fields, fieldName)

            if value_element.text is not None:
                value = value_element.text.strip()
                if value == 'now()' or value == 'today()':
                    continue

                if len(value) > 0 and field is not None:
                    attributes[fieldName] = value
            
            self.instance2attributes(fields, f"{nodeset_path}/{fieldName}", value_element, attributes)

    # https://developers.arcgis.com/web-map-specification/objects/field/

    #--------------------------------------------------------------------------

    def get_layer_field(self, name: str, layer:FeatureLayer = None) -> dict:
        if layer is None:
            layer = self.layer

        fields: list = layer.properties.get("fields")
        for field in fields:
            if field["name"] == name:
                return field

        return None
    
    def finalize_bindings(self):

        bindings = self.xform.get_bindings()
        binding:XBinding

        for binding in bindings:
            if binding.field_name == "instanceID":
                continue

            if binding.preload is not None:
                self.ws_add_unsupported(
                    binding.field_name,
                    binding.type,
                    [f"{binding.preload} is not supported ({binding.preload_parameters})"])
                continue

            ref_element = self.xform.body_element.find(f'.//*[@ref="{binding.nodeset}"]', XF.XFORMS_NS)
            if ref_element is None:
                self.ws_add_unsupported(
                    binding.field_name,
                    binding.type,
                    ["Calculate questions are not supported"])
                continue

    #--------------------------------------------------------------------------

    def initialize_worksheet(self):
        ws = self.wb.create_sheet(title = self.xform.title_element.text[:31])

        ws.append([
            "Status",                   # A 1
            "Field name",               # B 2
            "Label",                    # C 3
            "Hint",                     # D 4
            "Guidance hint",            # E 5
            "Element",                  # F 6
            "Type",                     # G 7
            "Form element",             # H 8
            "Input type",               # I 9
            "Field type",               # J 10
            "Visibility expression",    # K 11
            "Required expression",      # L 12
            "Editable expression",      # M 13
            "Value expression",         # N 14
            "Status messages"           # O 15
            ])
        
        ws.freeze_panes = 'C2'

        self.ws_initialize_column(ws, 'A', 8)
        
        self.ws_initialize_column(ws, 'B', 30)
        self.ws_initialize_column(ws, 'C', 40)
        self.ws_initialize_column(ws, 'D', 40, True)
        self.ws_initialize_column(ws, 'E', 40, True)
        self.ws_initialize_column(ws, 'F', 10, True)
        self.ws_initialize_column(ws, 'G', 12, True)

        self.ws_initialize_column(ws, 'H', 12, True)
        self.ws_initialize_column(ws, 'I', 15, True)
        self.ws_initialize_column(ws, 'J', 20, True)
        self.ws_initialize_column(ws, 'K', 40, True)
        self.ws_initialize_column(ws, 'L', 40, True)
        self.ws_initialize_column(ws, 'M', 40, True)
        self.ws_initialize_column(ws, 'N', 40, True)

        self.ws_initialize_column(ws, 'O', 50)
    
        for cell in ws["1:1"]:
            cell.style = 'header_style'

        self.ws = ws

    def ws_initialize_column(self, ws:openpyxl.worksheet.worksheet.Worksheet, column:str, width:int, hidden:bool = False):
        dimensions = ws.column_dimensions[column]
        dimensions.width = width
        dimensions.hidden = hidden

    def finalize_worksheet(self, formInfo: dict):
        self.ws.title = formInfo["title"][:31]

        for cell in self.ws["A:A"]:
            cell.alignment = Alignment(horizontal='center')

    def ws_add_row(self, xcontrol: XControl) -> None:

        xcontrol.row = self.ws.max_row + 1

        self.ws.append([
            None,
            xcontrol.binding.field_name,
            xcontrol.label_text,
            xcontrol.hint_text,
            xcontrol.guidance_hint_text,
            xcontrol.type, 
            xcontrol.binding.type
            ])

    def ws_add_unsupported(self, field_name:str, type:str, messages:list) -> None:

        self.status_count[STATUS_UNSUPPORTED] += 1

        row = self.ws.max_row + 1

        self.ws.append([
            SYMBOL_UNSUPPORTED,
            field_name,
            None, 
            None, 
            None, 
            None, 
            type
            ])
        
        cell = self.ws.cell(row = row, column = 1)
        cell.style = 'status_style'

        cell = self.ws.cell(row = row, column = 15)
        cell.style = 'status_style'
        cell.value = ", ".join(messages)


    def ws_update_row(self, xcontrol: XControl) -> None:
        cell = self.ws.cell(row = xcontrol.row, column = 1)

        if xcontrol.status == STATUS_OK:
            cell.value = SYMBOL_OK
        
        elif xcontrol.status == STATUS_WARNING:
            cell.value = SYMBOL_WARNING
            cell.style = 'status_style'

        elif xcontrol.status == STATUS_UNSUPPORTED:
            cell.value = SYMBOL_UNSUPPORTED
            cell.style = 'status_style'

        if xcontrol.formElement is not None:
            cell = self.ws.cell(row = xcontrol.row, column = 8)
            cell.style = 'featureform_style'
            cell.value = xcontrol.formElement.get('type')

            inputType = xcontrol.formElement.get('inputType')
            if inputType is not None:
                cell = self.ws.cell(row = xcontrol.row, column = 9)
                cell.style = 'featureform_style'
                cell.value = inputType.get('type')

            visibility_expression = xcontrol.formElement.get('visibilityExpression')
            if visibility_expression is not None:
                cell = self.ws.cell(row = xcontrol.row, column = 11)
                cell.style = 'featureform_style'
                cell.value = visibility_expression

            required_expression = xcontrol.formElement.get('requiredExpression')
            if required_expression is not None:
                cell = self.ws.cell(row = xcontrol.row, column = 12)
                cell.style = 'featureform_style'
                cell.value = required_expression

            editable_expression = xcontrol.formElement.get('editableExpression')
            if editable_expression is not None:
                cell = self.ws.cell(row = xcontrol.row, column = 13)
                cell.style = 'featureform_style'
                cell.value = editable_expression

            value_expression = xcontrol.formElement.get('valueExpression')
            if value_expression is not None:
                cell = self.ws.cell(row = xcontrol.row, column = 14)
                cell.style = 'featureform_style'
                cell.value = value_expression

        if xcontrol.field_info is not None:
            cell = self.ws.cell(row = xcontrol.row, column = 10)
            cell.style = 'featureform_style'
            cell.value = xcontrol.field_info["type"]

        if xcontrol.messages is not None:
            cell = self.ws.cell(row = xcontrol.row, column = 15)
            cell.style = 'status_style'
            cell.value = ", ".join(xcontrol.messages)

    #--------------------------------------------------------------------------

    def add_expressions_worksheeet(self, formInfo: dict) -> None:
        expressions = formInfo.get("expressions")
        if expressions is None or len(expressions) == 0:
            return
        
        title = f'{formInfo["title"]} (Expressions)'
        ws = self.wb.create_sheet(title = title[:31] )

        ws.append([
            "Name",                 # A
            "Title",                # B
            "Return Type",          # C
            "Arcade Expression",    # D
            "XPath Expression"      # E
        ])

        self.ws_initialize_column(ws, 'A', 40)
        self.ws_initialize_column(ws, 'B', 20)
        self.ws_initialize_column(ws, 'C', 15)
        self.ws_initialize_column(ws, 'D', 50)
        self.ws_initialize_column(ws, 'E', 50)

        ws.freeze_panes = 'B2'

        for cell in ws["1:1"]:
            cell.style = 'header_style'

        for expression in expressions:
            expressionInfo = expression["expressionInfo"]
            ws.append([
                expressionInfo["name"],
                expressionInfo["title"],
                expressionInfo["returnType"],
                expressionInfo["expression"],
                expression["xpath"]
            ])

        ws.sheet_state = 'hidden'

    #--------------------------------------------------------------------------

def find_field(fields: list, fieldName: str) -> dict:
    for field in fields:
        if field["name"] == fieldName:
            return field

    return None

def to_plain_text(html: str) -> str:
    if html is None:
        return None
    
    soup = BeautifulSoup(html, 'html.parser')

    if soup is None:
        return html
    else:
        return soup.get_text()
    
def escaped_text(text: str) -> str:
    if text is None:
        return None
    else:
        return text.replace('"', '\\"')

def is_translated_expression(expression_name: str) -> bool:
    if expression_name is None:
        return False

    return not (expression_name == EXPR_TRUE or expression_name == EXPR_FALSE)

