
"""
Copyright © 2025 ESRI

Trade Secrets: ESRI Proprietary and Confidential
Unpublished material - all rights reserved under the
Copyright Laws of the United States.

For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts Dept
380 New York Street
Redlands, California, USA 92373

Email: contracts@esri.com
"""

#-------------------------------------------------------------------------------

import logging
import odkparser as ODKParser

PULLDATA_TYPES = [ODKParser.ODKTokenType.PULLDATA, ODKParser.ODKTokenType.PULLDATA_JAVASCRIPT, ODKParser.ODKTokenType.PULLDATA_EXIF, ODKParser.ODKTokenType.PULLDATA_PROPERTY]

def xpath_to_arcade(xpath_expression: str) -> str:
    parser = ODKParser.ODKParser()
    arcade_expression = ""
    parser.functionsAdded.clear()
    if parser.parse_expression(xpath_expression):
        # Build function libary needed for the expression       
        for token in parser.tokens:                        
            if token[0] == ODKParser.ODKTokenType.FUNCTION and token[1] == ODKParser.ODKTokenState.OPERATION:
                arcade_expression +=  parser.get_arcade_function(token[2])
            elif token[0] in PULLDATA_TYPES and token[1] == ODKParser.ODKTokenState.OPERATION:
                arcade_expression += parser.get_arcade_function(token[2])
        
        #append the expression execution
        arcade_expression += parser.odk_to_arcade_expression()

        logging.info("Expression XPath: %s --> Arcade: %s", xpath_expression, arcade_expression)

    else:
        logging.error("Error parsing XPath expression: %s", xpath_expression)
        arcade_expression = "Invalid XPath expression"

    return arcade_expression
