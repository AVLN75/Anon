#!/usr/bin/python3
# -------------------------------------------------------------------------------
# Copyright 2025 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# -------------------------------------------------------------------------------

import argparse
import os
import logging
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, NamedStyle, Alignment

from arcgis.gis import GIS, Item
from arcgis.features import FeatureLayer, Table
from survey import Survey
from survey2map import Survey2Map, OPTION_CHOICES as survey2map_CHOICES
from featureform import OPTION_CHOICES as featureform_CHOICES
import featureform as FF

import sys

sys.stdout = open(1, 'w', encoding='utf-8', closefd=False)
tools_path = os.path.split(os.path.dirname(os.path.realpath(__file__)))[0]

CHOICES: list = featureform_CHOICES + survey2map_CHOICES

args: argparse.Namespace = None

#-------------------------------------------------------------------------------

def main(survey_path:str, token:str, referer:str, tag:str, snippet:str = None, title_suffix:str = None, locale:str = None, debug_level:int = None, options: list = []) -> None:
    """ main """

    log_path = initialize_logging(
        survey_path,
        tag,
        debug_level)

    if (len(token) == 0):
        print("ERROR: You must be signed in to use this tool.")
        logging.critical("Access token not provided")
        sys.exit(1)

    gis = GIS(token=token, referer=referer)
    
    logging.info("Portal: %s", gis.properties.portalName)
    logging.info("User: %s", gis.properties.user.username)

    logging.info("Loading survey")

    wb_path = get_content_path(survey_path, f"{tag}_exportSummary.xlsx")
    if os.path.exists(wb_path):
        try:
            os.remove(wb_path)
        except Exception as e:
            print(f"Unable to delete the previous summary file {wb_path}, it may be open in another application.")
            print("")
            print("")
            print(f"Error details: {e}")
            logging.error(f"Failed to remove file {wb_path}: {e}")
            exit(1)

    wb = Workbook()

    survey2map = Survey2Map(gis, options, wb)
    survey2map.initialize_from_path(survey_path)

    check_compatibility(survey2map.survey)

    survey2map.survey.xform.set_current_locale(locale)
    initialize_workbook(wb, survey2map.survey, options)

    logging.info(f"Survey name: {survey2map.survey.survey_name}")
    logging.info(f"Survey content path: {survey2map.survey.content_path}")
    logging.info("Creating/Updating map")

    item = survey2map.create_or_update_related_map(tag, snippet, title_suffix)
    item.url = f"{gis.url}/home/item.html?id={item.itemid}"

    finalize_workbook(wb, wb_path, survey2map, item)

    print ((
        '<!DOCTYPE html>'
        '<html><body>'
    ))

    print ((
        '<!DOCTYPE html>'
        '<html><body>'
        f'{"Created" if survey2map.item_created else "Updated"} {item.get("type").lower()} item: <b><a href="{item.url}">{item.get("title")}</a></b>.<br/><br/>'
        f'{FF.SYMBOL_FORM}<b>Forms generated</b>: {len(survey2map.forms)}<br/>'
        '<small>The number of forms generated from the survey. A survey that contains repeats generates multiple forms.</small><br/><br/>'
        f'<b>Questions processed</b>: {sum(survey2map.status_count)}<br/>'
        f'<small>Total number of questions processed from the survey.</small><br/><br/>'
        f'{FF.SYMBOL_OK} <b>Converted</b>: {survey2map.status_count[0]}<br/>'
        f'<small>The number of questions converted to form elements.</small><br/><br/>'
        f'{FF.SYMBOL_WARNING} <b>Partially converted</b>: {survey2map.status_count[1]}<br/>'
        '<small>The number of questions that have been converted to form elements, but with some limitations.</small><br/><br/>'
        f'{FF.SYMBOL_UNSUPPORTED} <b>Not converted</b>: {survey2map.status_count[2]}<br/>'
        f'<small>The number of questions not converted to form elements.</small><br/><br/>'
        f'<br/>For detailed information, see <a href="file:///{wb_path}">{tag}_exportSummary.xlsx</a>.<br/><br/>'
        f'<a href="https://links.esri.com/survey123/exportsurvey">Learn more about this tool</a>.<br/>'
    ))

    if log_path is not None:
        print ((
            f'<br/>A debug <a href="file:///{log_path}">log file</a> has been created.<br/>'
        ))

    print ((
        '</body></html>'
    ))


def check_compatibility(survey:Survey) -> None:
    if survey.survey_id is None:
        print("<big>The survey is unpublished. The survey must be published to run this tool.</big>")
        logging.critical("Unpublished survey")
        sys.exit(1)

    layer:FeatureLayer
    for layer in survey.service_layers.layers:
        if layer.properties.get("timeInfo") is not None:
            print(f"<big>Surveys with time enabled layers are not currently supported by this tool.</big>")
            exit(1)

#-------------------------------------------------------------------------------

def get_content_path(survey_path:str, filename:str) -> str:
    path = os.path.join(survey_path, "esriinfo")
    if not os.path.exists(path):
        path = survey_path

    return os.path.join(path, filename)


def initialize_logging(path:str, tag:str, debug_level:int) -> str:
    # https://docs.python.org/3/howto/logging.html

    log_filepath = get_content_path(path, f"{tag}.log")

    if os.path.exists(log_filepath):
        try:
            os.remove(log_filepath)
        except Exception as e:
            pass
 
    logging.basicConfig(
        filename=log_filepath, 
        level=logging.INFO if debug_level is not None else logging.CRITICAL, 
        encoding='utf-8',
        # format="%(asctime)s:%(levelname)s:%(name)s - %(message)s"
    )

    if debug_level is None:
        logging.debug_level = -1
        logging.disable()
        logging.shutdown()
        if os.path.exists(log_filepath):
            try:
                os.remove(log_filepath)
            except Exception as e:
                pass
        return None

    logging.debug_level = debug_level

    logging.info(f"Tools path: {tools_path}")
    logging.info(f"Tool: {__file__}")
    logging.info("Log level: %s", logging.getLevelName(logging.getLogger().getEffectiveLevel()))
    logging.info("Debug level: %s", logging.debug_level)

    return log_filepath


#-------------------------------------------------------------------------------

def initialize_workbook(wb:Workbook, survey:Survey, options:list):
    header_style = NamedStyle(name='header_style')
    header_style.font = Font(color='00FFFFFF', bold=True)
    header_style.fill = PatternFill(start_color='00008000', end_color='00008000', fill_type='solid')
    header_style.alignment = Alignment(horizontal='center')
    wb.add_named_style(header_style)

    status_style = NamedStyle(name='status_style')
    status_style.font = Font(color='00A80000', bold=False)
    wb.add_named_style(status_style)

    featureform_style = NamedStyle(name='featureform_style')
    featureform_style.font = Font(color='000000F0', bold=False)
    wb.add_named_style(featureform_style)

    ws_info = wb.active
    ws_info.title = "Summary"

    ws_info.column_dimensions['A'].width = 25
    ws_info.column_dimensions['B'].width = 30

    ws_info.append(['=HYPERLINK("https://links.esri.com/survey123/exportsurvey", "Learn more about the export tool")'])
    ws_info[ws_info.max_row][0].style = 'Hyperlink'
    ws_info.append([''])
    ws_info.append(['Survey item', f'=HYPERLINK("{survey.survey_url}", "{survey.survey_url}")'])
    ws_info[ws_info.max_row][1].style = 'Hyperlink'
    ws_info.append(["Survey ID", survey.survey_id])
    ws_info.append(["Survey title", survey.survey_item.get('title')])
    
    ws_options = wb.create_sheet("Options")
    ws_options.title = "Options"
    ws_options.column_dimensions['A'].width = 30
    ws_options.column_dimensions['B'].width = 30

    ws_options.append(["Name", "Value"])

    for cell in ws_options["1:1"]:
        cell.style = 'header_style'

    for arg in vars(args):
        if arg in ['token']:
            continue

        ws_options.append([arg, f"{getattr(args, arg)}"])

    ws_options.append([''])
    row = ws_options.max_row + 1
    ws_options.append(["Option"])
    for cell in ws_options[f"{row}:{row}"]:
        cell.style = 'header_style'

    for choice in CHOICES:
        ws_options.append([choice, "✔️" if choice in options else None])

    ws_options.sheet_state = 'hidden'

def finalize_workbook(wb:Workbook, wb_path:str, survey2map:Survey2Map, item:Item) -> None:
    ws_info = wb.worksheets[0]

    item_url = f"{survey2map.gis.url}/home/item.html?id={item.itemid}"
  
    ws_info.append([''])
    ws_info.append([f'{"Created" if survey2map.item_created else "Updated"}  {item.get("type").lower()}  item', f'=HYPERLINK("{item.url}", "{item.url}")'])
    ws_info[ws_info.max_row][1].style = 'Hyperlink'
    ws_info.append(['Web map ID', item.itemid])
    ws_info.append(['Web map title', item.get('title')])

    ws_info.append([''])
    ws_info.append([f'Forms converted', len(survey2map.forms)])
    for form in survey2map.forms:
        ws_info.append([FF.SYMBOL_FORM, form["formInfo"]["title"]])

    ws_info.append([''])
    ws_info.append(['Questions processed', sum(survey2map.status_count)])
    ws_info.append([f'{FF.SYMBOL_OK} Converted', survey2map.status_count[0]])
    ws_info.append([f'{FF.SYMBOL_WARNING} Partially converted', survey2map.status_count[1]])
    ws_info.append([f'{FF.SYMBOL_UNSUPPORTED} Not converted', survey2map.status_count[2]])

    wb.save(wb_path)

#-------------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    """ parse_args """
    parser = argparse.ArgumentParser(
        description="Export survey to feature form"
    )

    parser.add_argument(
        "--surveypath",
        help="Path to the survey",
        required=True,
        type=str,
        dest="survey_path"
    )
    
    parser.add_argument(
        "--token",
        help="Access token",
        required=True,
        type=str,
        dest="token"
    )

    parser.add_argument(
        "--locale",
        help="The locale to run the tool with",
        required=False,
        dest="locale"
    )

    parser.add_argument(
        "--referer",
        help="referer",
        required=False,
        type=str,
        default="https://www.arcgis.com",
        dest="referer"
    )

    parser.add_argument(
        "--tag",
        help="Export item tag",
        required=False,
        type=str,
        default="survey2featureform",
        dest="tag"
    )

    parser.add_argument(
        "--snippet",
        help="Item snippet",
        required=False,
        type=str,
        default=None,
        dest="snippet"
    )

    parser.add_argument(
        "--titlesuffix",
        help="Item title suffix",
        required=False,
        type=str,
        default=None,
        dest="title_suffix"
    )
    parser.add_argument(
        "--debug",
        help="Debug output level (0=Basic, 1=Verbose)",
        required=False,
        type=int,
        default=None,
        dest="debug_level"
    )

    parser.add_argument(
        "--options",
        help="Options",
        nargs="+",
        required=False,
        choices=CHOICES,
        default=[],
        dest="options"
    )

    return parser.parse_args()

#-------------------------------------------------------------------------------

def tool_main() -> None:
    global args
    args = parse_args()

    main(
        survey_path=args.survey_path,
        token=args.token,
        referer=args.referer,
        locale=args.locale,
        debug_level=args.debug_level,
        tag=args.tag,
        snippet=args.snippet,
        title_suffix=args.title_suffix,
        options=args.options
    )


#-------------------------------------------------------------------------------

if __name__ == "__main__":
    tool_main()
