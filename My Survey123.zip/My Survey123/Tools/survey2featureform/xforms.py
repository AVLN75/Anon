"""
Copyright © 2025 ESRI

Trade Secrets: ESRI Proprietary and Confidential
Unpublished material - all rights reserved under the
Copyright Laws of the United States.

For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts Dept
380 New York Street
Redlands, California, USA 92373

Email: contracts@esri.com
"""

import logging

import xml.etree.ElementTree as ET
import re

#-------------------------------------------------------------------

NS_XHTML:str = "http://www.w3.org/1999/xhtml"
NS_XFORMS:str = "http://www.w3.org/2002/xforms"
NS_JAVAROSA:str = "http://openrosa.org/javarosa"
NS_ESRI:str = "http://esri.com/xforms"

XFORMS_NS: dict = {
    "html": NS_XHTML,
    "xforms" : NS_XFORMS,
    "ns0": NS_XFORMS,
    "ns1": NS_XFORMS,
    "jr": NS_JAVAROSA,
    "esri": NS_ESRI,
    }

CONTROL_TYPE_GROUP: str = 'group'
CONTROL_TYPE_INPUT: str = 'input'
CONTROL_TYPE_RANGE: str = 'range'
CONTROL_TYPE_RANK: str = 'rank'
CONTROL_TYPE_REPEAT: str = 'repeat'
CONTROL_TYPE_SELECT: str = 'select'
CONTROL_TYPE_SELECT1: str = 'select1'
CONTROL_TYPE_UPLOAD: str = 'upload'
CONTROL_TYPE_LABEL: str = 'label'

BIND_TYPE_STRING: str = 'string'
BIND_TYPE_INT: str = 'int'
BIND_TYPE_DECIMAL: str = 'decimal'
BIND_TYPE_DATETIME: str = 'dateTime'
BIND_TYPE_DATE: str = 'date'
BIND_TYPE_TIME: str = 'time'
BIND_TYPE_BARCODE: str = 'barcode'
BIND_TYPE_GEOPOINT: str = 'geopoint'
BIND_TYPE_GEOTRACE: str = 'geotrace'
BIND_TYPE_GEOSHAPE: str = 'geoshape'

XPATH_TRUE: str = 'true()'
XPATH_FALSE: str = 'false()'

#-------------------------------------------------------------------

class XForm:
    tree: ET.ElementTree = None
    head_element: ET.Element = None
    title_element: ET.Element = None
    model_element: ET.Element = None
    body_element: ET.Element = None

    instance_element: ET.Element = None
    primary_instance_id: str = None
    primary_instance_element: ET.Element = None

    translations: list = None
    default_translation: dict = None

    current_locale: str = None
    current_translation: dict = None

#-------------------------------------------------------------------------------

    def __init__(self, text: str):
        logging.info("XForm")

        if logging.debug_level > 0:
            logging.debug("XForm text:\n%s", text)

        self.tree = ET.fromstring(text)

        self.head_element = self.tree.find('html:head', XFORMS_NS)
        self.title_element = self.head_element.find('html:title', XFORMS_NS)
        self.model_element = self.head_element.find('ns1:model', XFORMS_NS)
        self.body_element = self.tree.find('html:body', XFORMS_NS)

        self.instance_element = self.model_element.find('ns1:instance', XFORMS_NS)
        self.primary_instance_element = self.instance_element[0]
        self.primary_instance_id = self.primary_instance_element.attrib.get('id')

        self._initialize_translations()

        logging.info("Title: %s", self.title_element.text)
        logging.info("Primary instance id: %s", self.primary_instance_id)
        logging.info("Primary instance: %s", ET.tostring(self.primary_instance_element, encoding='utf-8', method='xml').decode('utf-8'))

#-------------------------------------------------------------------------------

    def __str__(self) -> str:
        return ET.tostring(self.tree, encoding='utf-8', method='xml').decode('utf-8')

#-------------------------------------------------------------------------------

    def get_bind_element(self, control_element: ET.Element) -> ET.Element:
        ref = control_element.attrib.get('ref')
        if ref is not None:
            return self.model_element.find(f'ns1:bind[@nodeset="{ref}"]', XFORMS_NS)
        else:
            logging.debug("No bind element for ref: %s", ref)
            return None
        
    def get_bind_attrib(self, control_element: ET.Element) -> dict:
        bind_element = self.get_bind_element(control_element)
        if bind_element is not None:
            logging.debug("Bind: %s attributes: %s", bind_element.tag, bind_element.attrib) 
            return bind_element.attrib
        else:
            return None
        
#-------------------------------------------------------------------------------

    def get_itext(self, text_element: ET.Element, form: str = None) -> str:
        if text_element is None:
            return None
        
        default_text = text_element.text if form is None else None
        
        if self.default_translation is None:
            return default_text

        ref = text_element.attrib.get('ref')
        if ref is None:
            return default_text
        
        match = re.search(r"jr:itext\(\S*'(.+)'\S*\)", ref)
        id = match.group(1) if match else None
        if id is None:
            return default_text
        
        if form is not None:
            id += f".{form}"

        logging.debug("itext id: %s --> %s", id, self.default_translation["strings"].get(id, default_text))
        
        text = self.default_translation["strings"].get(id, default_text)

        if self.current_translation is not None:
            return self.current_translation["strings"].get(id, text)
        else:
            return text

#-------------------------------------------------------------------------------

    def get_repeat_nodesets(self) -> list:
        elements = self.body_element.findall(".//ns1:repeat", XFORMS_NS)
        nodesets = []
        for element in elements:
            nodesets.append(element.attrib.get('nodeset'))

        return nodesets
    
    def get_repeat_group_element(self, nodeset:str) -> ET.Element:
        group_elements = self.body_element.findall('.//ns1:group', XFORMS_NS)
        for group_element in group_elements:
            for repeat_element in group_element.findall('ns1:repeat', XFORMS_NS):
                if repeat_element.get('nodeset') == nodeset:
                    return group_element

#-------------------------------------------------------------------------------

    def get_instance_value(self, nodeset: str) -> str:
        # TODO lookup using nodeset path
        value_element = self.primary_instance_element.find(f"*/ns0:{nodeset.split('/')[-1]}", XFORMS_NS)
        return value_element.text if value_element is not None else None


#-------------------------------------------------------------------------------

    def _initialize_translations(self):
        
        itext_element = self.model_element.find('xforms:itext', XFORMS_NS)
        if itext_element is None:
            return

        self.translations = []
        
        translation_elements = self.model_element.findall('*/xforms:translation', XFORMS_NS)
        for translation_element in translation_elements:
            lang = translation_element.attrib["lang"]
            is_default = translation_element.attrib.get("default") == "true()"

            match = re.search(r'\((.*?)\)', lang)
            language_code = match.group(1) if match else None

            logging.debug("lang: %s code: %s default: %s", lang, language_code, is_default)

            strings = {}

            text_elements = translation_element.findall('xforms:text', XFORMS_NS)
            for text_element in text_elements:
                id = text_element.attrib["id"]
                value_elements = text_element.findall("xforms:value", XFORMS_NS)
                for value_element in value_elements:
                    value = value_element.text

                    form = value_element.attrib.get("form")
                    if form is not None:
                        id += f".{form}"

                    logging.debug("id: %s value: %s", id, value)

                    strings[id] = value

            translation = {
                "lang": lang,
                "default": is_default,
                "code": language_code,
                "strings": strings
            }

            self.translations.append(translation)
            if is_default:
                self.default_translation = translation


    def get_bindings(self) -> list:
        """
        Returns a list of XBinding objects for all bind elements in the XForm.
        """
        bindings = []
        bind_elements = self.model_element.findall('ns1:bind', XFORMS_NS)
        for bind_element in bind_elements:
            binding = XBinding(self, bind_element)
            bindings.append(binding)

        return bindings
    
    def set_current_locale(self, locale: str) -> None:
        self.current_locale = None
        self.current_translation = None
        
        if locale is None:
            return

        lang_code, country_code = locale.split('_', 1)

        if self.translations is not None:
            for translation in self.translations:
                if translation.get("code") == lang_code:
                    self.current_locale = locale
                    self.current_translation = translation
                    break

        if self.current_translation is None:
            logging.warning("No translation found for locale: %s", locale)

#-------------------------------------------------------------------------------

class XBinding:
    xform: XForm = None
    element: ET.Element = None
    type: str = None
    nodeset: str = None
    required_expression: str = None
    required_message: str = None
    readonly_expression: str = None
    relevant_expression: str = None
    calculate_expression: str = None
    constraint_expression: str = None
    constraint_message: str = None

    preload: str = None
    preload_parameters: str = None

    esri_field_alias: str = None
    esri_field_type: str = None
    esri_parameters: str = None
    esri_warning_expression: str = None
    esri_warning_message: str = None
    esri_workflow: str = None

    field_name: str = None
    default_value: str = None


    def __init__(self, xform: XForm, element: ET.Element):
        self.xform = xform
        if element is None:
            return
        
        self.element = element
        self.type = element.attrib.get('type')
        self.nodeset = element.attrib.get('nodeset')
        self.required_expression = element.attrib.get('required')
        self.required_message = element.attrib.get(f'{{{NS_JAVAROSA}}}requiredMsg')
        self.readonly_expression = element.attrib.get('readonly')
        self.relevant_expression = element.attrib.get('relevant')
        self.calculate_expression = element.attrib.get('calculate')
        self.constraint_expression = element.attrib.get('constraint')
        self.constraint_message = element.attrib.get('constraint_message')

        self.preload = element.attrib.get(f'{{{NS_JAVAROSA}}}preload')
        self.preload_parameters = element.attrib.get(f'{{{NS_JAVAROSA}}}preloadParams')

        self.esri_field_alias = element.attrib.get(f'{{{NS_ESRI}}}fieldAlias')
        self.esri_field_type = element.attrib.get(f'{{{NS_ESRI}}}fieldType')
        self.esri_parameters = element.attrib.get(f'{{{NS_ESRI}}}parameters')
        self.esri_warning_expression = element.attrib.get(f'{{{NS_ESRI}}}warning')
        self.esri_warning_message = element.attrib.get(f'{{{NS_ESRI}}}warning_message')
        self.esri_workflow = element.attrib.get(f'{{{NS_ESRI}}}workflow')

        # self.field_name = self.esri_field_alias if self.esri_field_alias is not None else self.nodeset.split('/')[-1]
        self.field_name = self.nodeset.split('/')[-1]
        self.default_value = self.xform.get_instance_value(self.nodeset)

#-------------------------------------------------------------------------------

class XControl:
    xform: XForm = None
    element: ET.Element = None
    type: str = None
    ref: str = None
    nodeset: str = None

    label_element: ET.Element = None
    label_text: str = None

    hint_element: ET.Element = None
    hint_text: str = None
    guidance_hint_text: str = None

    binding: XBinding = None
    field_info: dict = None

    appearances: list = None
    accuracyThreshold: str = None

    esri_input_mask: str = None
    esri_style: str = None
    esri_visible_expression: str = None

    repeat_element: ET.Element = None
    repeat_nodeset: str = None
    repeat_table_name: str = None
    repeat_count_nodeset: str = None

    messages: list = None

    def __init__(self, xform: XForm, element: ET.Element):

        self.xform = xform
        self.element = element
        self.type = element.tag.split('}')[-1]
        self.ref = element.attrib.get('ref')
        self.nodeset = element.attrib.get('nodeset')

        self.label_element = get_label_element(element)
        if self.label_element is not None:
            self.label_text = self.xform.get_itext(self.label_element)

        self.hint_element = get_hint_element(element)
        if self.hint_element is not None:
            self.hint_text = self.xform.get_itext(self.hint_element)
            self.guidance_hint_text = self.xform.get_itext(self.hint_element, "guidance")

        appearances = element.attrib.get('appearance')
        self.appearances = appearances.split() if appearances is not None else []
        self.accuracyThreshold = element.attrib.get(f'accuracyThreshold')

        self.esri_input_mask = element.attrib.get(f'{{{NS_ESRI}}}inputMask')
        self.esri_style = element.attrib.get(f'{{{NS_ESRI}}}style')
        self.esri_visible_expression = element.attrib.get(f'{{{NS_ESRI}}}visible')

        self.binding = XBinding(self.xform, self.xform.get_bind_element(self.element))

        if self.type == CONTROL_TYPE_GROUP:
            self.repeat_element = self.element.find('xforms:repeat', XFORMS_NS)
            if self.repeat_element is not None:
                self.type = CONTROL_TYPE_REPEAT
                self.repeat_nodeset = self.repeat_element.attrib.get('nodeset')
                self.repeat_table_name = self.repeat_nodeset.split('/')[-1]
                self.repeat_count_nodeset = self.repeat_element.attrib.get(f'{{{NS_JAVAROSA}}}count')

    def has_appearance(self, appearance: str) -> bool:
        return has_appearance(self.element, appearance)
    
    def has_appearances(self, appearances: list) -> bool:
        return has_appearances(self.element, appearances)
    
    def take_appearance(self, appearance: str) -> bool:
        if appearance in self.appearances:
            self.appearances.remove(appearance)
            return True
        else:
            return False

    def take_appearances(self, appearances: list) -> bool:
        taken = False

        for appearance in appearances:
            if appearance in self.appearances:
                self.appearances.remove(appearance)
                taken = True

        return taken

    def add_message(self, message: str) -> None:
        if self.messages is None:
            self.messages = []

        self.messages.append(message)

#-------------------------------------------------------------------------------

def get_label_element(control_element: ET.Element):
    label = control_element.find('xforms:label', XFORMS_NS)
    if label is not None:
        return label
    else:
        return None

def get_hint_element(control_element: ET.Element):
    hint = control_element.find('xforms:hint', XFORMS_NS)
    if hint is not None:
        return hint
    else:
        return None
        
#-------------------------------------------------------------------------------

def has_appearance(control_element: ET.Element, appearance: str) -> bool:
    appearances = control_element.attrib.get('appearance')
    if appearances is None:
        return False
    else:
        return appearance in appearances.split()

def has_appearances(control_element: ET.Element, appearances: list) -> bool:
    for appearance in appearances:
        if has_appearance(control_element, appearance):
            return True
        
    return False

#-------------------------------------------------------------------------------



