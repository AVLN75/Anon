"""
Copyright © 2025 ESRI

Trade Secrets: ESRI Proprietary and Confidential
Unpublished material - all rights reserved under the
Copyright Laws of the United States.

For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts Dept
380 New York Street
Redlands, California, USA 92373

Email: contracts@esri.com
"""

import os
import json
import tempfile
import logging
from openpyxl import Workbook
from pprint import pformat
from datetime import datetime
from zipfile import ZipFile

from arcgis.gis import GIS
from arcgis.gis import Item
from arcgis.map import Map
from arcgis.features import FeatureLayer, Table

from survey import Survey
from featureform import FeatureForm

def jformat(object:object):
    return json.dumps(object, ensure_ascii=False, indent=4) if isinstance(object, dict) else pformat(object)

#-------------------------------------------------------------------------------

TAG_SURVEY123EXPRESS:str = "Survey123Express"

OPTION_NOFIELDMAPSCONFIG: str = "nofieldmapsconfig"
OPTION_NOFEATURETEMPLATES: str = "nofeaturetemplates"
OPTION_SURVEY123: str = "survey123"

OPTION_CHOICES: list = [
    OPTION_NOFIELDMAPSCONFIG,
    OPTION_SURVEY123
    ]

#-------------------------------------------------------------------------------

class Survey2Map:
    gis: GIS
    options: list
    survey:Survey
    item_resources:list = None
    wb:Workbook

    item_created:bool = False
    forms:list = []
    status_count: list = [0, 0, 0]

    #---------------------------------------------------------------------------

    def __init__(self, gis: GIS, options: list = [], wb:Workbook = None):
        self.gis = gis
        self.options = options
        self.wb = wb
        self.survey = Survey(self.gis)

    #---------------------------------------------------------------------------

    def initialize_from_path(self, survey_path:str):
        self.survey.initialize_from_path(survey_path)

    #---------------------------------------------------------------------------

    def initialize_from_item(self, survey_id:str):
        self.survey.initialize_from_item(survey_id)

    #---------------------------------------------------------------------------

    def get_express_project_settings(self):
        settings = {
            "drafts": {
                "enabled": True,
            },
            "overview": {
                "enabled": True,
            },
            "tasks": {
                "enabled": True,
            },
        }

        return settings

    #---------------------------------------------------------------------------

    def create_or_update_related_map(self, tag:str, snippet:str = None, title_suffix:str = None) -> Item:
        created:bool = False
        map_item = self.find_related_map(tag)
        if map_item is None:
            created = True
            tags = [tag]
            if OPTION_SURVEY123 in self.options:
                tags.append(TAG_SURVEY123EXPRESS)

            map_item = self.create_map(tags, snippet, title_suffix, True) 
            logging.info("Created map: %s", map_item)
            self.update_thumbnail(map_item[1])
        else:
            logging.info("Updating related map: %s", map_item)

        webmap_item:Item = map_item[1]

        self.update_featureforms(webmap_item)

        self.item_created = created

        timestamp = datetime.now().isoformat()
        if created:
            webmap_item.add_comment(f"Created by {tag} tool on {timestamp}")
        else:
            webmap_item.add_comment(f"Updated by {tag} tool on {timestamp}")

        return webmap_item

    #---------------------------------------------------------------------------

    def update_featureforms(self, webmap_item:Item) -> FeatureForm:
        webmap_data: dict = webmap_item.get_data()
        logging.debug("Web Map data: %s", jformat(webmap_data))

        layers:list = webmap_data.get("operationalLayers")
        tables:list = webmap_data.get("tables")
        # TODO: Find matching layer based on id
        survey_layer = layers[0]
        logging.debug("Survey layer: %s", jformat(survey_layer))

        logging.info("Updating layer formInfo: %s", survey_layer.get("title"))

        if logging.debug_level > 0:
            logging.debug("Current formInfo: %s", jformat(survey_layer.get("formInfo")))


        featureForm = FeatureForm(self.survey, self.options, self.wb)
        survey_feature_layer:FeatureLayer = self.survey.get_service_layer_by_url(survey_layer.get("url"))
        form = featureForm.get_form(survey_feature_layer)
        survey_layer["formInfo"] = form["formInfo"]
        self.add_form_status(form)

        if not OPTION_NOFEATURETEMPLATES in self.options:
            templates = form.get("templates")
            if templates is not None:
                logging.info("Updating templates definition for: %s", survey_layer)
                survey_feature_layer.manager.update_definition({"templates": templates})
                self.add_templates_worksheet(templates)

        repeat_nodesets = self.survey.xform.get_repeat_nodesets()
        for repeat_nodeset in repeat_nodesets:
            logging.info("Repeat nodeset: %s", repeat_nodeset)
            name = repeat_nodeset.split('/')[-1]

            for layer in layers:
                if layer.get("title") == name:
                    form = featureForm.get_form(self.survey.get_service_layer_or_table_by_url(layer.get("url")), repeat_nodeset)
                    layer["formInfo"] = form["formInfo"]
                    self.add_form_status(form)
                    logging.debug("Updated layer: %s", jformat(layer))
                    break

            for table in tables:
                if table.get("title") == name:
                    form = featureForm.get_form(self.survey.get_service_layer_or_table_by_url(table.get("url")), repeat_nodeset)
                    table["formInfo"] = form["formInfo"]
                    self.add_form_status(form)
                    logging.debug("Updated table: %s", jformat(table))
                    break
 
        logging.debug("Updated formInfo: %s", jformat(survey_layer["formInfo"]))


        logging.info("Updating Web Map item")
        webmap_item.update(item_properties={ "text": json.dumps(webmap_data, ensure_ascii=False) })

        if OPTION_NOFIELDMAPSCONFIG not in self.options:
            self.update_field_maps_config(webmap_item, form)

        if OPTION_SURVEY123 in self.options:
            self.update_survey123_resources(webmap_item, survey_layer, form)

        return featureForm
    
    def add_form_status(self, form:dict):
        self.forms.append(form)
        status_count = form.get("status_count")
        for i in range(len(status_count)):
            self.status_count[i] += status_count[i]

    #---------------------------------------------------------------------------

    def add_templates_worksheet(self, templates:list):
        if not templates or len(templates) == 0:
            return

        ws = self.wb.create_sheet("Feature Templates")

        ws.append([
            None,
            None,
            "Field Name", 
            "Value"
            ])

        for cell in ws["1:1"]:
            cell.style = 'header_style'

        ws.column_dimensions['A'].width = 15
        ws.column_dimensions['B'].width = 5
        ws.column_dimensions['C'].width = 30
        ws.column_dimensions['D'].width = 30

        for template in templates:
            ws.append([""])
            ws.append(["Name", template.get("name")])
            ws.append(["Description", template.get("description")])
            ws.append(["Drawing Tool", template.get("drawingTool")])

            prototype = template.get("prototype", {})

            ws.append([None, "Attributes"])
            for field_name, value in prototype.get("attributes", {}).items():
                ws.append([
                    None,
                    None, 
                    field_name, 
                    value
                    ])

    #---------------------------------------------------------------------------
    # https://developers.arcgis.com/python/latest/guide/accessing-item-resources/

    def update_field_maps_config(self, item:Item, form:dict):
        form_settings = form.get("settings")
        if form_settings is None:
            return  
        
        geometry = form_settings.get("geometry")
        if geometry is None:
            return
        
        minimum_horizontal_accuracy = geometry.get("miminumHorizontalAccuracy")
        if minimum_horizontal_accuracy is None:
            return

        if self.item_resources is None:
            self.item_resources = item.resources.list()
 
        zip_name = "field-maps-settings.zip"
        zip_path = os.path.join(tempfile.gettempdir(), zip_name)
        resource_name = "field-maps-settings.json"
        resource_path = os.path.join(self.survey.content_path, resource_name)

        field_maps_settings = {}

        add = True
        for resource in self.item_resources:
            if resource.get("resource") == resource_name:
                add = False
                item.resources.export(save_path=tempfile.gettempdir(), file_name=zip_name)
                with ZipFile(zip_path, 'r') as zip_file:
                    with zip_file.open(resource_name) as json_file:
                        field_maps_settings = json.load(json_file)
                os.remove(zip_path)
                break

        if field_maps_settings.get("version") is None:
            field_maps_settings["version"] = "3.3.0"

        collection = field_maps_settings.get("collection")
        if collection is None:
            collection = field_maps_settings["collection"] = {}

        accuracy = collection.get("accuracy")
        if accuracy is None:
            accuracy = collection["accuracy"] = {}

        accuracy["requiredAccuracy"] = minimum_horizontal_accuracy
        accuracy["accuracyUnits"] = "meters"

        with open(resource_path, 'w', encoding='utf-8') as resource_file:
            json.dump(field_maps_settings, resource_file, ensure_ascii=False, indent=4)

        if add:
            item.resources.add(file=resource_path, file_name=resource_name)
        else:
            item.resources.update(file=resource_path, file_name=resource_name)

    #---------------------------------------------------------------------------

    def update_survey123_resources(self, webmap_item:Item, layer:FeatureLayer, form:dict):
        logging.info("Updating Survey123 resources")

        form_id:str = layer["id"]
        form_prefix:str = f"form-{form_id}"

        form_settings = form.get("settings")
        if form_settings is not None:
            logging.info("Updating settings")
            self.add_or_update_resource_json(webmap_item, f"{form_prefix}-settings.json", form_settings)

        form_themes = self.survey.get_form_themes()
        if form_themes is not None:
            logging.info("Updating themes")
            self.add_or_update_resource_json(webmap_item, f"{form_prefix}-themes.json", form_themes)

        form_translations = self.survey.get_form_translations()
        if form_translations is not None:
            logging.info("Updating translations")
            self.add_or_update_resource_json(webmap_item, f"{form_prefix}-translations.json", form_translations)

        project_settings = self.get_express_project_settings()
        if project_settings is not None:
            logging.info("Updating project settings")
            self.add_or_update_resource_json(webmap_item, "survey123-settings.json", project_settings)

    #---------------------------------------------------------------------------

    def find_related_map(self, tag:str) -> tuple:
        item = self.survey.find_related_data_item('Web Map', tag)
        if item is not None:
            map = Map(item)
            return (map, item)

        return None

    #---------------------------------------------------------------------------

    def create_map(self, tags:list, snippet:str = None, title_suffix:str = None, link_to_survey:bool = False) -> tuple:
        map = Map()
        map.basemap.basemap = "arcgis-streets"

        for layer in self.survey.service_layers.layers:
            map.content.add(layer)

        for table in self.survey.service_layers.tables:
            map.content.add(table)

        if title_suffix is not None:
            title = f"{self.survey.survey_item.title} {title_suffix}"
        else:
            title = self.survey.survey_item.title

        item_properties = {
            "type": "Web Map",
            "title": title,
            "typeKeywords": [
                "ArcGIS Online",
                "Data Editing"
                ],
            "tags": tags,
            "snippet": snippet if snippet is not None else self.survey.survey_item.snippet,
            "description": self.survey.survey_item.description
            }

        logging.info("Creating map item")

        item = map.save(item_properties)

        if link_to_survey:
            logging.info("Linking map item to survey")
            self.survey.survey_item.add_relationship(item, "Survey2Data")

        return (map, item)

    #---------------------------------------------------------------------------

    def update_thumbnail(self, item:Item):
        logging.info("Updating thumbnail")
        thumbnail = self.survey.survey_item.download_thumbnail(save_folder= tempfile.gettempdir())
        item.update(thumbnail=thumbnail)
        os.remove(thumbnail)

    #-------------------------------------------------------------------------------
    # https://developers.arcgis.com/python/latest/guide/accessing-item-resources/
    
    def add_or_update_resource_json(self, item:Item, resource_name:str, properties:dict):

        if self.item_resources is None:
            self.item_resources = item.resources.list()
            if logging.debug_level > 0:
                logging.debug("Item resources: %s", jformat(self.item_resources))
 
        add:bool = True

        logging.info("Resource: %s", resource_name)
        logging.debug("Resource properties: %s", jformat(properties))

        for resource in self.item_resources:
            if resource.get("resource") == resource_name:
                add = False
                logging.info("Found existing resource: %s", jformat(resource))
                break

        resource_path = os.path.join(tempfile.gettempdir(), resource_name)
        with open(resource_path, 'w', encoding='utf-8') as resource_file:
            json.dump(properties, resource_file, ensure_ascii=False, indent=4)

        if add:
            try:
                result = item.resources.add(file=resource_path, file_name=resource_name)
                if result.get("success"):
                    logging.info("Added resource: %s", resource_name)
                else:
                    logging.error("Resource not added: %s - %s", resource_name, result)
            except Exception as e:
                logging.error("Failed to add resource: %s - %s", resource_name, e)
                print("Failed to add resource:", resource_name, "error:", e)
        else:
            try:
                result = item.resources.update(file=resource_path, file_name=resource_name)
                if result.get("success"):
                    logging.info("Updated resource: %s", resource_name)
                else:
                    logging.error("Resource not updated: %s - %s", resource_name, result)
            except Exception as e:
                logging.error("Failed to update resource: %s - %s", resource_name, e)
                print("Failed to update resource:", resource_name, "error:", e)
            
        os.remove(resource_path)

#-------------------------------------------------------------------------------

