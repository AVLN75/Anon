
"""
Copyright © 2024 ESRI
Trade Secrets: ESRI Proprietary and Confidential
Unpublished material - all rights reserved under the
Copyright Laws of the United States.
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts Dept
380 New York Street
Redlands, California, USA 92373
Email: contracts@esri.com
"""

#-------------------------------------------------------------------------------
unimplemented ="""
function NotImplementedOrSupported(functionName)
{
    return functionName + " is either not yet implemented by Survey2map or it is unsupported by Arcade expressions";
}
"""

bool_from_string ="""
function bool_from_string(inputString)
{
    if(inputString == 'true')
    {
        return true;
    }
    if(inputString == "false")
    {
        return false;
    }
}
"""
coalesce ="""
function coalesce(input1, input2)
{
  if(input1 != null)
  {
    return input1;
  }
  if(input2 != null)
  {
    return input2;
  }
  return null;
}
"""

decimal_date_time ="""
function decimal_date_time(InputDate)
{
    var dt = TOUTC(Date(InputDate));
    var epoch = ToUTC(Date(0));
    return DateDiff(dt, epoch,'days')
}
"""

decimal_time ="""
function decimal_time(InputDate)
{
    var dt = Date(InputDate);  
    var minutes = Minute(dt) + (Hour(dt) * 60 );
    
    return  ((minutes * 60) + Second(dt)) / 86400;
}
"""


contains ="""
function contains_string(string, substring)
{
    if(  Find(substring, string, 0) > -1 )
    {
        return true;
    }
    return false;
}
"""

ends_with ="""
function ends_with(sourceString, endsWithString)
{
    var foundString = Mid(sourceString, Count(sourceString) - Count(endsWithString), Count(sourceString) - 1)
    if(foundString == endsWithString)
    {
        return true;
    }
    else
    {
        return false;
    }
}
"""

not_ = """
function Not(inputValue)
{
  return !inputValue;
}
"""

startswith = """
function starts_with(sourceString, startsWithString)
{
    var foundString = Mid(sourceString, 0, Count(startsWithString))
    if(foundString == startsWithString)
    {
        return true;
    }
    else
    {
        return false;
    }
}
"""

Substr = """
function subStr(sourceString, startIndex, endIndex)
{
  var resultString = ""
  for(var i = startIndex; i < endIndex ;i++)
  {
    resultString += sourceString[i]
  }
  return resultString
}
"""

Today = """
function Today()
{
  return TimeZoneOffset(DateAdd(Today(), 12, "hours"));
}
"""

Exp10 = """
function Exp10(inputNumber)
{
  return Pow(inputNumber, 10);
}
"""

Log10 = """
function Log10(value)
{
  return Log(value) / 2.303;
}
"""
Pi_ = """
function _Pi()
{
  return Pi;
}
"""

substring_before = """
function substring_before(inputstring, searchString)
{
  return left(inputstring,Find(searchString, inputstring))
}
"""
substring_after = """
function substring_after(inputstring, searchString)
{
  if(Find(searchString, inputstring, 0) > -1 )
  {
    return Mid(inputstring,Find(searchString, inputstring) + Count(searchString), Count(inputstring));
  }
  return "";
}
"""

normalize_space = """
function normalize_space(inputstring)
{
  inputstring = Trim(inputstring());
  inputstring = Replace(inputstring, "  ", " ", true);
  return Replace(inputstring, "   ", " ", true);
}
"""

checklist = """
function Checklist(minResponses, maxResponses, responses)
{
    if (minResponses < 0 && maxResponses < 0)
    {
        return true;
    }
    //if max is not provided, set it to the length of the responses to mak the argument not applicable
    if (maxResponses < 0)
    {
        maxResponses = responses.Length;
    }
    var countYesResponses = Count(Filter(responses, isYes));
    if (countYesResponses >= minResponses && countYesResponses <= maxResponses)
    {
        return true;
    }
    return false;
}

function  isYes (i) 
{
  return i == "yes";
}
"""
