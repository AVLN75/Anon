"""
Copyright © 2025 ESRI

Trade Secrets: ESRI Proprietary and Confidential
Unpublished material - all rights reserved under the
Copyright Laws of the United States.

For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts Dept
380 New York Street
Redlands, California, USA 92373

Email: contracts@esri.com
"""

import os
import json
import tempfile
import logging
from pprint import pformat

from zipfile import ZipFile
import xml.etree.ElementTree as ET 

from arcgis.gis import GIS
from arcgis.gis import Item
from arcgis.features import FeatureLayerCollection, FeatureLayer, Table

import xforms as XF
from xforms import XForm

def jformat(object:object):
    return json.dumps(object, ensure_ascii=False, indent=4) if isinstance(object, dict) else pformat(object)

#-------------------------------------------------------------------------------

class Survey:
    gis: GIS
    survey_path:str = None
    content_path:str = None
    survey_content = None
    form_info:dict
    survey_name:str
    survey_id:str = None
    survey_info:dict = {}
    survey_item:Item
    survey_url:str = None
    xform:XForm
    service_item:Item
    service_layers:FeatureLayerCollection


    #---------------------------------------------------------------------------

    def __init__(self, gis: GIS):
        self.gis = gis

    #---------------------------------------------------------------------------

    def initialize_from_path(self, survey_path:str):
        self.survey_path = survey_path
        self.content_path = os.path.join(survey_path, "esriinfo")

        if not os.path.exists(self.content_path):
            self.content_path = survey_path

        with open(os.path.join(self.content_path, "forminfo.json"), "r", encoding="utf-8") as form_info_file:
            self.form_info = json.loads(form_info_file.read())
            logging.debug("formInfo: %s", jformat(self.form_info))
            self.survey_name = self.form_info['name']

        with open(os.path.join(self.content_path, self.survey_name + ".info"), "r", encoding="utf-8") as survey_info_file:
            self.survey_info = json.loads(survey_info_file.read())
            logging.debug("Survey info: %s", jformat(self.survey_info))

        with open(os.path.join(self.content_path, self.survey_name + ".xml"), "r", encoding="utf-8") as xform_file:
            xml = xform_file.read()
            self.xform = XForm(xml)

        with open(os.path.join(self.content_path, self.survey_name + ".itemInfo"), "r", encoding="utf-8") as item_info_file:
            item_info = json.loads(item_info_file.read())
            self.survey_id = item_info.get("id")

        if self.survey_id is not None:
            self.survey_item = self.gis.content.get(self.survey_id)
            self.survey_url = f"{self.gis.url}/home/item.html?id={self.survey_id}"

            self.initialize_service()


    #---------------------------------------------------------------------------

    def initialize_from_item(self, survey_id:str):
        self.survey_item = self.gis.content.get(self.survey_id)
        self.survey_content = self.survey_item.get_data()

        with ZipFile(self.survey_content) as survey_zip:
            for name in survey_zip.namelist():
                logging.debug("Survey file: %s", name)

            with survey_zip.open('esriinfo/forminfo.json') as forminfo_file:
                data = forminfo_file.read()
                self.form_info = json.loads(data.decode('utf-8'))
                logging.debug("formInfo: %s", jformat(self.form_info))
                self.survey_name = self.form_info['name']

            with survey_zip.open('esriinfo/' + self.survey_name + '.xml') as xform_file:
                self.xform = XForm(xform_file.read().decode('utf-8'))

            with survey_zip.open('esriinfo/' + self.survey_name + '.info') as survey_info_file:
                data = survey_info_file.read()
                self.survey_info = json.loads(data.decode('utf-8'))
                logging.debug("Survey info: %s", jformat(self.survey_info))

        self.initialize_service()

    #---------------------------------------------------------------------------

    def initialize_service(self):
        services = self.survey_item.related_items('Survey2Service', 'forward')
        if len(services) > 0:
            self.service_item = services[0]
            logging.info("Service id: %s item: %s", self.service_item.itemid, self.service_item)
        else:
            logging.critical("No related feature services found")
            exit()

        if logging.debug_level > 0:
            service_data = self.service_item.get_data()
            logging.debug("Service data: %s", service_data)

        self.service_layers = FeatureLayerCollection.fromitem(self.service_item)
        if logging.debug_level > 0:
            logging.debug("Layers:")
            featureLayer: FeatureLayer
            for featureLayer in self.service_layers.layers:
                logging.debug("FeatureLayer: %s", featureLayer)

            logging.debug("Tables:")
            for table in self.service_layers.tables:
                logging.debug("Table: %s", table)


    #---------------------------------------------------------------------------

    def get_service_layer_by_url(self, url:str) -> FeatureLayer:
        logging.info("Getting service layer: %s", url)
    
        for featureLayer in self.service_layers.layers:
            if featureLayer.url == url:
                logging.info("Found layer: %s", featureLayer)
                return featureLayer
        
        logging.error("Layer not found: %s", url)
        
    #---------------------------------------------------------------------------

    def get_service_table_by_url(self, url:str) -> Table:
        logging.info("Getting service table: %s", url)
    
        for table in self.service_layers.tables:
            if table.url == url:
                logging.info("Found table: %s", table)
                return table

        logging.error("Table not found: %s", url)
        
    #---------------------------------------------------------------------------

    def get_service_layer_or_table_by_url(self, url:str) -> FeatureLayer | Table:
        layer = self.get_service_layer_by_url(url)
        if layer is None:
            layer = self.get_service_table_by_url(url)
        
        return layer

    def get_layer_or_table_by_name(self, name:str) -> FeatureLayer | Table:
        for layer in self.service_layers.layers:
            if layer.properties.get("name") == name:
                return layer

        for table in self.service_layers.tables:
            if table.properties.get("name") == name:
                return table

    #---------------------------------------------------------------------------

    def get_form_themes(self) -> dict:
        displayInfo = self.survey_info.get("displayInfo")
        if displayInfo is None:
            return

        style = displayInfo.get("style")
        if style is None: 
            return
    
        if len(style) == 0:
            return

        theme = {
            "name": "Light",
            "mode": "light",
        }

        copy_property(style, "backgroundColor", theme, "bodyBackgroundColor")
        copy_property(style, "toolbarBackgroundColor", theme, "headerBackgroundColor")
        copy_property(style, "toolbarTextColor", theme, "headerTextColor")
        copy_property(style, "footerBackgroundColor", theme)
        copy_property(style, "footerTextColor", theme)
        copy_property(style, "inputBackgroundColor", theme)
        copy_property(style, "inputTextColor", theme)
        color = copy_property(style, "textColor", theme, "bodyTextColor")
        if color is not None:
            theme["fieldLabelColor"] = color
            theme["fieldDescriptionColor"] = color
            theme["groupLabelColor"] = color
            theme["groupDescriptionColor"] = color

        themes = {
            "themes": [theme]
        }

        return themes

    #---------------------------------------------------------------------------

    def get_form_translations(self) -> dict:
        if self.xform.translations is None:
            return
    
        translations = []

        default_translation_strings = self.xform.default_translation["strings"]
    
        for xform_translation in self.xform.translations:
            if xform_translation["default"] == True:
                continue

            strings: dict = {}

            for key, value in xform_translation["strings"].items():
                if value == "-":	
                    continue

                default_value = default_translation_strings.get(key)
                strings[default_value] = value

            translation = {
                "language": xform_translation["code"],
                "strings": strings
            }

            translations.append(translation)

            logging.debug("translation: %s", json.dumps(translation, ensure_ascii=False, indent=4))

        return {
            "translations": translations
        }


    #---------------------------------------------------------------------------

    def get_project_settings(self):
        settings = {
            "drafts": {
                "enabled": True,
            },
            "overview": {
                "enabled": True,
            },
            "tasks": {
                "enabled": True,
            },
        }

        return settings


    #---------------------------------------------------------------------------

    def find_related_data_item(self, type:str, tag:str = None) -> Item:
        items = self.survey_item.related_items('Survey2Data', 'forward')
        for item in items:
            if item.type.lower() == type.lower() and (tag is None or tag.lower() in (item_tag.lower() for item_tag in item.tags)):
                return item

        return None

#===============================================================================
#-------------------------------------------------------------------------------

def copy_property(source: dict, source_name: str, target: dict, target_name: str = None):
    if target_name is None:
        target_name = source_name

    value = source.get(source_name)
    if value is not None:
        target[target_name] = value
        return value

