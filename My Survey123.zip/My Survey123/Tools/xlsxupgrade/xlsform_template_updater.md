# XLSForm template updater

Update an XLSForm to the latest template. 

## Prerequisites

### Python 3.9 
* Windows Store: https://www.microsoft.com/en-us/p/python-39/9p7qfqmjrfp7
* Python website: https://www.python.org/downloads/

### Python Packages
* openpyxl 3.0.8 and later: https://openpyxl.readthedocs.io/
  * `python3 -m pip install openpyxl`

## Usage

`python3 xlsform_template_updater.py -x <filename>.xlsx`
