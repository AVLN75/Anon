#!/usr/bin/python3
# -------------------------------------------------------------------------------
# Copyright 2023 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# -------------------------------------------------------------------------------

import tempfile
import shutil
import os
import warnings
import sys
import re
import logging, datetime
from logging.handlers import RotatingFileHandler
from collections import Counter
import argparse
import openpyxl as xl
from openpyxl.styles import Alignment
from openpyxl.worksheet.table import Table
from openpyxl.utils import get_column_letter
from copy import copy
import json
from distutils.version import LooseVersion

sys.stdout = open(1, 'w', encoding='utf-8', closefd=False)

# -------------------------------------------------------------------------------

# Pre 3.10 surveys had a different implementation of the data validation which throws a warning message.
# This suppresses that message
warnings.simplefilter("ignore")


def format_survey(ws1, ws2):
    ws1_rows = ws1.iter_rows(min_row=2, max_row=ws1.max_row, min_col=1, max_col=1)
    ws2_rows = ws2.iter_rows(min_row=2, max_row=ws2.max_row, min_col=1, max_col=ws2.max_column)

    for row1, row2 in zip(ws1_rows, ws2_rows):
        has_style = [x for x in row1 if x.has_style]
        if len(has_style) == 1:
            fill = copy(has_style[0].fill)
            for x in row2:
                x.fill = fill


# Due to https://foss.heptapod.net/openpyxl/openpyxl/-/issues/1732 openpyxl will automatically set showErrorMessage and
# showInputMessage to True, this is not the case for all our data validation columns, so we need to go back and remove
# those settings for the correct data validation columns
def update_data_validation(workbook):
    ws = ["survey", "settings"]
    for worksheet in ws:
        current_ws = workbook[worksheet]
        if worksheet == "survey":
            # type column
            current_ws.data_validations.dataValidation[0].showErrorMessage = False
            current_ws.data_validations.dataValidation[0].showInputMessage = False
            current_ws.data_validations.dataValidation[0].allowBlank = True
            # name column
            current_ws.data_validations.dataValidation[1].showInputMessage = False
            current_ws.data_validations.dataValidation[1].allowBlank = True
            # appearance column
            current_ws.data_validations.dataValidation[6].showErrorMessage = False
            current_ws.data_validations.dataValidation[6].showInputMessage = False
            current_ws.data_validations.dataValidation[6].allowBlank = True
            # required & read only columns
            current_ws.data_validations.dataValidation[2].showErrorMessage = False
            current_ws.data_validations.dataValidation[2].showInputMessage = False
            current_ws.data_validations.dataValidation[2].allowBlank = True
            # bind::type column
            current_ws.data_validations.dataValidation[3].showInputMessage = False
            current_ws.data_validations.dataValidation[3].allowBlank = True
            # bind::esri:fieldType column
            current_ws.data_validations.dataValidation[4].showInputMessage = False
            current_ws.data_validations.dataValidation[4].allowBlank = True
            # bind::esri:fieldLength column
            current_ws.data_validations.dataValidation[5].showInputMessage = False
            current_ws.data_validations.dataValidation[5].allowBlank = True
        elif worksheet == "settings":
            # style column
            current_ws.data_validations.dataValidation[0].showErrorMessage = False
            current_ws.data_validations.dataValidation[0].showInputMessage = False
            current_ws.data_validations.dataValidation[0].allowBlank = True


def rebuild_table(ws2):
    try:
        # Find the table name
        ws_table = ws2.tables.items()[0][0]
        # Connect to the table
        my_table = ws2.tables[ws_table]
        # Obtain the table style info
        my_table_style = my_table.tableStyleInfo
        # Delete the table
        del ws2.tables[ws_table]

    except IndexError:
        pass

    try:
        # Define a new table given the new columns added, setting the headerRowCount to 0 disables the filters
        if ws2.max_row > 150:
            tab_rows = ws2.max_row
        else:
            tab_rows = 150
        tab = Table(displayName="{}".format(ws_table),
                    ref="$A$1:${}${}".format(get_column_letter(ws2.max_column), tab_rows), headerRowCount=1)
        # Style it the same as the old table
        tab.tableStyleInfo = my_table_style
        # Create the table
        ws2.add_table(tab)
        # print(ws2.filters)
    except:
        pass


def identify_multilingual_form(updated_col_header):
    a = False
    for x in updated_col_header:
        if x is not None:
            langs = re.search(r'\([^?!.*(.).*\1]*\)', x)
            if langs is not None:
                langs = langs[0]
                freq = Counter(langs)
                if len(freq) == len(langs):
                    a = True
    return a


def multilingual_rmv_def_cols(source_col_header, dest_col_header, dest_ws, logger):
    def_cols = ['label', 'hint', 'guidance_hint', 'required_message', 'constraint_message', 'label::language (xx)',
                'hint::language (xx)', 'guidance_hint::language (xx)', 'required_message::language (xx)',
                'constraint_message::language (xx)', 'image::language (xx)', 'audio::language (xx)',
                'video::language (xx)', 'media::image::language (xx)', 'media::audio::language (xx)',
                'media::video::language (xx)']
    dest_cois = [x for x in dest_col_header if x in def_cols]
    for col in dest_cois:
        dest_ws.delete_cols(dest_col_header.index(col) + 1, amount=1)
        dest_col_header = [x.value for x in dest_ws[1]]

    source_cois = [x for x in source_col_header if x in def_cols]
    for s_col in source_cois:
        logger.warning(
            "A multilingual survey was detected. Consider adding the language name and code to the header for the {parentColumn} column.".format(
                parentColumn=s_col))
        print("A multilingual survey was detected. Consider adding the language name and code to the header for the {parentColumn} column.".format(
                parentColumn=s_col))


def add_usr_cols(usr_cols, worksheet, wb2, ws2, header_ft, header_fill, source_workbook_header, ws1):
    if worksheet == "survey":
        AB_column_dimensions = str(wb2[worksheet].column_dimensions["A"].width)  # 24
        CAE_column_dimensions = str(wb2[worksheet].column_dimensions["C"].width)  # 27
        maj_column_dimensions = str(wb2[worksheet].column_dimensions["D"].width)  # 22
        AF_column_dimensions = str(wb2[worksheet].column_dimensions["AF"].width)  # 31
        AG_column_dimensions = str(wb2[worksheet].column_dimensions["AG"].width)  # 23
        AI_column_dimensions = str(wb2[worksheet].column_dimensions["AI"].width)  # 26
    elif worksheet == "choices":
        F_column_dimensions = str(wb2[worksheet].column_dimensions["F"].width)  # 22
        maj_column_dimensions = str(wb2[worksheet].column_dimensions["A"].width)  # 18
    elif worksheet == "settings":
        maj_column_dimensions = str(wb2[worksheet].column_dimensions["A"].width)  # 18
        G_column_dimensions = str(wb2[worksheet].column_dimensions["G"].width)  # 20
        H_column_dimensions = str(wb2[worksheet].column_dimensions["H"].width)  # 29

    try:
        # Find the table name
        ws_table = ws2.tables.items()[0][0]
        # Connect to the table
        my_table = ws2.tables[ws_table]
        # Obtain the table style info
        my_table_style = my_table.tableStyleInfo
        # Delete the table
        del ws2.tables[ws_table]

    except IndexError:
        pass

    for col in usr_cols:
        # Add the column in the same index
        ws2.insert_cols(col, amount=1)
        # # Give the column a name
        ws2.cell(row=1, column=col).value = usr_cols[col]
        # Style the column
        coi = ws2.cell(row=1, column=col)
        # coi.value = usr_cols[col]
        coi.font = header_ft
        coi.fill = header_fill
        coi.alignment = Alignment(horizontal="center")

        # Obtain a list of cells in the current column from the old xlsx file
        current_source_index = source_workbook_header.index(usr_cols[col])
        current_col = ws1.iter_cols(min_col=current_source_index + 1, max_col=current_source_index + 1,
                                    min_row=2, max_row=None)  # since iter_cols is a 1 based index we add 1
        # Copy the data over into the new column
        for column in current_col:
            for idx, cell in enumerate(column, 2):
                ws2.cell(row=idx, column=col).value = cell.value  # 1-indexing
                # ws2.cell(row=idx, column=col).fill = copy(cell.fill)
                ws2.cell(row=idx, column=col).font = copy(cell.font)
                ws2.cell(row=idx, column=col).alignment = copy(cell.alignment)
                ws2.cell(row=idx, column=col).border = copy(cell.border)

    updated_col_header = [x.value for x in ws2[1] if x.value is not None]

    if worksheet == 'survey':
        updated_dv_cols = {v: get_column_letter(k + 1) for k, v in enumerate(updated_col_header) if
                           v == 'type' or v == 'name' or v == 'required' or v == 'readonly' or v == 'bind::type' or v == 'bind::esri:fieldType' or v == 'bind::esri:fieldLength' or v == 'appearance'}
        # gives us {'type': 'A', 'name': 'B', 'appearance': 'O', 'required': 'P', 'readonly': 'U', 'bind::type': 'AE', 'bind::esri:fieldType': 'AF', 'bind::esri:fieldLength': 'AG'}
        ws2.data_validations.dataValidation[0].sqref = xl.worksheet.cell_range.MultiCellRange(
            ranges=('{}2:{}150'.format(updated_dv_cols['type'], updated_dv_cols['type'])))

        ws2.data_validations.dataValidation[1].sqref = xl.worksheet.cell_range.MultiCellRange(
            ranges=('{}2:{}150'.format(updated_dv_cols['name'], updated_dv_cols['name'])))

        ws2.data_validations.dataValidation[2].sqref = xl.worksheet.cell_range.MultiCellRange(
            ranges=('{}2:{}150'.format(updated_dv_cols['required'], updated_dv_cols['required']),
                    '{}2:{}150'.format(updated_dv_cols['readonly'], updated_dv_cols['readonly'])))

        ws2.data_validations.dataValidation[3].sqref = xl.worksheet.cell_range.MultiCellRange(
            ranges=('{}2:{}150'.format(updated_dv_cols['bind::type'], updated_dv_cols['bind::type'])))

        ws2.data_validations.dataValidation[4].sqref = xl.worksheet.cell_range.MultiCellRange(
            ranges=(
                '{}2:{}150'.format(updated_dv_cols['bind::esri:fieldType'], updated_dv_cols['bind::esri:fieldType'])))

        ws2.data_validations.dataValidation[5].sqref = xl.worksheet.cell_range.MultiCellRange(
            ranges=('{}2:{}150'.format(updated_dv_cols['bind::esri:fieldLength'],
                                       updated_dv_cols['bind::esri:fieldLength'])))

        ws2.data_validations.dataValidation[6].sqref = xl.worksheet.cell_range.MultiCellRange(
            ranges=('{}2:{}150'.format(updated_dv_cols['appearance'], updated_dv_cols['appearance'])))
    elif worksheet == 'settings':
        updated_dv_cols = {v: get_column_letter(k + 1) for k, v in enumerate(updated_col_header) if
                           v == 'style'}
        ws2.data_validations.dataValidation[0].sqref = xl.worksheet.cell_range.MultiCellRange(
            ranges=('{}2:{}150'.format(updated_dv_cols['style'], updated_dv_cols['style'])))

    try:
        # Define a new table given the new columns added, setting the headerRowCount to 0 disables the filters
        if ws2.max_row > 150:
            tab_rows = ws2.max_row
        else:
            tab_rows = 150
        tab = Table(displayName="{}".format(ws_table),
                    ref="$A$1:${}${}".format(get_column_letter(ws2.max_column), tab_rows), headerRowCount=1)
        # Style it the same as the old table
        tab.tableStyleInfo = my_table_style
        # Create the table
        ws2.add_table(tab)
        # print(ws2.filters)
    except:
        pass
    for column_cells, header in zip(ws2.columns, updated_col_header):
        col_letter = get_column_letter(column_cells[0].column)
        if (worksheet == "survey" and header == "type") or (worksheet == "survey" and header == "name"):
            ws2.column_dimensions[col_letter].width = AB_column_dimensions
        elif (worksheet == "survey" and header == "label") or (
                worksheet == "survey" and "guidance_hint::" in header) or (
                worksheet == "survey" and "label::" in header):
            ws2.column_dimensions[col_letter].width = CAE_column_dimensions
        elif worksheet == "survey" and "required_message::" in header:
            ws2.column_dimensions[col_letter].width = AF_column_dimensions
        elif worksheet == "survey" and header == "body::accuracyThreshold":
            ws2.column_dimensions[col_letter].width = 23
        elif worksheet == "survey" and header == "bind::esri:warning_message":
            ws2.column_dimensions[col_letter].width = 26
        elif worksheet == "survey":
            ws2.column_dimensions[col_letter].width = maj_column_dimensions

        elif worksheet == "choices" and "label::" in header:
            ws2.column_dimensions[col_letter].width = F_column_dimensions
        elif worksheet == "choices":
            ws2.column_dimensions[col_letter].width = maj_column_dimensions

        elif worksheet == "settings" and header == "style":
            ws2.column_dimensions[col_letter].width = G_column_dimensions
        elif worksheet == "settings" and header == "namespaces":
            ws2.column_dimensions[col_letter].width = H_column_dimensions
        elif worksheet == "settings":
            ws2.column_dimensions[col_letter].width = maj_column_dimensions


# loops through the survey, choices, and settings worksheets mapping fields from the original survey to the template,
# and copies data to those fields. The script will only be copying cells that have values
def update_survey(old_form, new_form, logger):
    # Connect to both the old XLSForm and the renamed template
    wb1 = xl.load_workbook(old_form)
    wb2 = xl.load_workbook(new_form)

    # Prepare formatting based on XLSForm template
    header_ft = copy(wb2['survey'].cell(row=1, column=1).font)
    header_fill = copy(wb2['survey'].cell(row=1, column=1).fill)
    tab_color = copy(wb2['survey'].sheet_properties.tabColor)
    column_dimensions = str(wb2['survey'].column_dimensions["A"].width)

    worksheets = ['survey', 'choices', 'settings']
    # Loop through the worksheets
    for worksheet in worksheets:
        # Connect to the worksheet in the source and destination workbooks, and identify column headers.
        ws1 = wb1[worksheet]
        source_workbook_header = [x.value for x in ws1[1]]
        ws2 = wb2[worksheet]
        destination_workbook_header = [x.value for x in ws2[1]]
        # Since the Advanced template has sample text in the survey, choices,
        # and settings worksheet we clear the text before copying content over
        if worksheet == 'survey' or worksheet == 'choices':
            ws2.delete_rows(2, 10)

        # If multilingual survey, removes the default columns.
        if identify_multilingual_form(source_workbook_header):
            multilingual_rmv_def_cols(source_workbook_header, destination_workbook_header, ws2, logger)
            destination_workbook_header = [x.value for x in ws2[1]]

        usr_cols = {k + 1: v for k, v in enumerate(source_workbook_header) if
                    v not in destination_workbook_header and v is not None and v != 'image' and v != 'audio' and v != 'label::language1' and v != 'hint::language1' and v != 'body::esri:Parameters' and v != 'allow_choice_duplicates' and v != 'list name'}
        # loop through column headers replacing min and max col with the index of the current column
        for c_name in source_workbook_header:
            if c_name in destination_workbook_header:
                # Find the index of the current column in both XLSForms
                current_source_index = source_workbook_header.index(c_name)
                current_destination_index = destination_workbook_header.index(c_name)
                # Obtain a list of cells in the current column from the old xlsx file
                current_col = ws1.iter_cols(min_col=current_source_index + 1, max_col=current_source_index + 1,
                                            min_row=2, max_row=None)  # since iter_cols is a 1 based index we add 1
                # current_col is a generator object, so we need to obtain all the cells in the object using the for
                # loops below
                for column in current_col:  # Which will always be one column
                    for idx, cell in enumerate(column, 2):
                        ws2.cell(row=idx, column=current_destination_index + 1).value = cell.value  # 1-indexing
                        # ws2.cell(row=idx, column=current_destination_index + 1).fill = copy(cell.fill)
                        ws2.cell(row=idx, column=current_destination_index + 1).font = copy(cell.font)
                        ws2.cell(row=idx, column=current_destination_index + 1).alignment = copy(cell.alignment)
                        ws2.cell(row=idx, column=current_destination_index + 1).border = copy(cell.border)

            elif worksheet == "choices" and c_name == 'image':
                # Find the index of the current column in both XLSForms
                current_source_index = source_workbook_header.index(c_name)
                current_destination_index = destination_workbook_header.index('media::image')
                # Obtain a list of cells in the current column from the old xlsx file
                current_col = ws1.iter_cols(min_col=current_source_index + 1, max_col=current_source_index + 1,
                                            min_row=2, max_row=None)  # since iter_cols is a 1 based index we add 1
                # current_col is a generator object, so we need to obtain all the cells in the object using the for
                # loops below
                for column in current_col:  # Which will always be one column
                    for idx, cell in enumerate(column, 2):
                        ws2.cell(row=idx, column=current_destination_index + 1).value = cell.value  # 1-indexing
                        # ws2.cell(row=idx, column=current_destination_index + 1).fill = copy(cell.fill)
                        ws2.cell(row=idx, column=current_destination_index + 1).font = copy(cell.font)
                        ws2.cell(row=idx, column=current_destination_index + 1).alignment = copy(cell.alignment)
                        ws2.cell(row=idx, column=current_destination_index + 1).border = copy(cell.border)

            elif worksheet == "choices" and c_name == 'audio':
                # Find the index of the current column in both XLSForms
                current_source_index = source_workbook_header.index(c_name)
                current_destination_index = destination_workbook_header.index('media::audio')
                # Obtain a list of cells in the current column from the old xlsx file
                current_col = ws1.iter_cols(min_col=current_source_index + 1, max_col=current_source_index + 1,
                                            min_row=2, max_row=None)  # since iter_cols is a 1 based index we add 1
                # current_col is a generator object, so we need to obtain all the cells in the object using the for
                # loops below
                for column in current_col:  # Which will always be one column
                    for idx, cell in enumerate(column, 2):
                        ws2.cell(row=idx, column=current_destination_index + 1).value = cell.value  # 1-indexing
                        # ws2.cell(row=idx, column=current_destination_index + 1).fill = copy(cell.fill)
                        ws2.cell(row=idx, column=current_destination_index + 1).font = copy(cell.font)
                        ws2.cell(row=idx, column=current_destination_index + 1).alignment = copy(cell.alignment)
                        ws2.cell(row=idx, column=current_destination_index + 1).border = copy(cell.border)

            elif worksheet == "choices" and c_name == 'list name':
                # Find the index of the current column in both XLSForms
                current_source_index = source_workbook_header.index(c_name)
                current_destination_index = destination_workbook_header.index('list_name')
                # Obtain a list of cells in the current column from the old xlsx file
                current_col = ws1.iter_cols(min_col=current_source_index + 1, max_col=current_source_index + 1,
                                            min_row=2, max_row=None)  # since iter_cols is a 1 based index we add 1
                # current_col is a generator object, so we need to obtain all the cells in the object using the for
                # loops below
                for column in current_col:  # Which will always be one column
                    for idx, cell in enumerate(column, 2):
                        ws2.cell(row=idx, column=current_destination_index + 1).value = cell.value  # 1-indexing
                        # ws2.cell(row=idx, column=current_destination_index + 1).fill = copy(cell.fill)
                        ws2.cell(row=idx, column=current_destination_index + 1).font = copy(cell.font)
                        ws2.cell(row=idx, column=current_destination_index + 1).alignment = copy(cell.alignment)
                        ws2.cell(row=idx, column=current_destination_index + 1).border = copy(cell.border)

        # Add user created columns that are not from an old template or have a null column header
        if len(usr_cols) > 0:
            add_usr_cols(usr_cols, worksheet, wb2, ws2, header_ft, header_fill, source_workbook_header, ws1)

        # Extend the table if the user has more than 150 rows
        if ws2.max_row > 150:
            rebuild_table(ws2)

        format_survey(ws1, ws2)

        # Let the user know what worksheet was just completed
        logger.info("Completed updating {worksheetName} worksheet".format(worksheetName=worksheet))
        print("Completed updating {worksheetName} worksheet".format(worksheetName=worksheet))

    # Check for external_choices worksheet
    if 'external_choices' in wb1.sheetnames:
        logger.info("Copying over external choices")
        print("Copying over external choices")
        # obtain the index of the external choices worksheet, so we can recreate it in the new xlsx file
        external_idx = wb1.sheetnames.index('external_choices')
        # create the new external choices worksheet and colorize it to match the other worksheets
        external_choices = wb2.create_sheet('external_choices', external_idx)
        external_choices.sheet_properties.tabColor = tab_color
        # Make a connection to the old workbook and obtain a list of headers in the external choices worksheet
        old_x_worksheet = wb1['external_choices']
        source_x_header = [x.value for x in old_x_worksheet[1]]
        # Loop through the column headers and add them to the new xlsx file and colorize
        for idx, header in enumerate(source_x_header, 1):
            # Add the column header and colorize it
            coi = external_choices.cell(row=1, column=idx)
            coi.value = header
            coi.font = header_ft
            coi.fill = header_fill
            coi.alignment = Alignment(horizontal="center")
            # Obtain a list of cells in the current column from the old xlsx file
            current_col = old_x_worksheet.iter_cols(min_col=idx, max_col=idx, min_row=2, max_row=None)
            # Copy over cell values for each column
            for column in current_col:
                for row_idx, cell in enumerate(column, 2):
                    external_choices.cell(row=row_idx, column=idx).value = cell.value
                    # external_choices.cell(row=row_idx, column=idx + 1).fill = copy(cell.fill)
                    external_choices.cell(row=row_idx, column=idx + 1).font = copy(cell.font)
                    external_choices.cell(row=row_idx, column=idx + 1).alignment = copy(cell.alignment)
                    external_choices.cell(row=row_idx, column=idx + 1).border = copy(cell.border)
        for column_cells in external_choices.columns:
            external_choices.column_dimensions[get_column_letter(column_cells[0].column)].width = column_dimensions
    # Update the data validation to workaround openpyxl bug
    update_data_validation(wb2)
    # Save the XLSForm
    wb2.save(new_form)
    # Close the XLSForms
    wb1.close()
    wb2.close()


def main(xlsform, locale):
    # Create a temp directory in order to download the latest XLSForm template
    if LooseVersion(".".join(re.search(r"\b\d+\.\d+\.\d+", sys.version)[0].split(".")[:2])) <= LooseVersion("3.9"):
        tmpdir = tempfile.TemporaryDirectory()
    else:
        tmpdir = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
    # Extract the directory path
    xls_directory = tmpdir.name
    advanced_template_directory = shutil.copy(os.path.join(sys.path[0], "Survey123_Template_Advanced.xlsx"),
                                              xls_directory)
    timestamp = datetime.datetime.now()
    head, tail = os.path.split(xlsform)

    debug_path = os.path.join(head, "debug")
    if not os.path.exists(debug_path):
        os.makedirs(debug_path)
    update_path = os.path.join(debug_path, "template_updater")
    if not os.path.exists(update_path):
        os.makedirs(update_path)

    # Set up logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logFileName = "template_update_{timestamp}".format(timestamp=timestamp.strftime('%Y-%m-%d %H-%M-%S'))
    fileHandler = logging.handlers.RotatingFileHandler('{}/{}.log'.format(update_path, logFileName), maxBytes=100000,
                                                       backupCount=5, encoding='utf-8')
    formatter = logging.Formatter(
        '%(asctime)s %(levelname)s %(relativeCreated)d \n%(filename)s %(module)s %(funcName)s %(lineno)d \n%(message)s\n')
    fileHandler.setFormatter(formatter)
    logger.addHandler(fileHandler)
    logger.propagate = False
    logger.info("Script starting at {timestamp}".format(timestamp=str(datetime.datetime.now())))
    # Check to ensure the input XLSForm is a xlsx file
    if os.path.splitext(xlsform)[1] == '.xls':
        logger.error("Invalid file type, please use .xlsx file")
        print("Invalid file type, please use .xlsx file")
        sys.exit(-2)
    # Obtain the name of the XLSForm
    xlsx_name = os.path.splitext(tail)[0]
    # Rename the XLSForm to <name>_<timestamp> so the user has a backup of their XLSForm
    old_xlsx_name = os.path.join(head,
                                 xlsx_name + "_{}.xlsx".format(timestamp.strftime('%Y_%m_%d_%H_%M_%S')))
    try:
        os.rename(os.path.join(head, xlsx_name + ".xlsx"), old_xlsx_name)
    except FileNotFoundError:
        logger.error(
            "XLSForm not found. Ensure the XLSForm is present in the survey folder and the file extension is .xlsx.")
        print("XLSForm not found. Ensure the XLSForm is present in the survey folder and the file extension is .xlsx.")
        sys.exit(-2)
    old_xlsx = shutil.move(old_xlsx_name, update_path)
    logger.info("Made a backup of the XLSForm in:\n{folderDirectory}".format(
        folderDirectory=os.path.join(update_path, xlsx_name + "_{}.xlsx".format(
            timestamp.strftime('%Y_%m_%d_%H_%M_%S')))))
    print("Made a backup of the XLSForm in:\n{folderDirectory}".format(
        folderDirectory=os.path.join(update_path, xlsx_name + "_{}.xlsx".format(
            timestamp.strftime('%Y_%m_%d_%H_%M_%S')))))
    # Copy the blank XLSForm template and rename it the same as the survey
    target_xlsx = advanced_template_directory
    # Let the user know what survey is currently being worked on
    logger.info("Currently working on survey: {surveyName}".format(surveyName=xlsx_name))
    print("Currently working on survey: {surveyName}".format(surveyName=xlsx_name))
    # We then update the form copying everything from the _old form.
    try:
        update_survey(old_xlsx, target_xlsx, logger)
        shutil.copy(advanced_template_directory, xlsform)
        logger.info("XLSForm upgrade complete")
        print("XLSForm upgrade complete")
        sys.exit()
    except Exception as e:
        logger.info("Unable to process survey: {surveyName}\nError: {errorMessage}".format(surveyName=xlsx_name,
                                                                                           errorMessage=e))
        print("Unable to process survey: {surveyName}\nError: {errorMessage}".format(surveyName=xlsx_name,
                                                                                           errorMessage=e))
        shutil.copy(old_xlsx, xlsform)
        logger.info("Backup replaced in survey folder.")
        print("Backup replaced in survey folder.")
        sys.exit(-2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-x",
        help="XLSX file path",
        required=True,
        dest="xlsform"
    )
    parser.add_argument(
        "-l",
        help="Please specify the locale to run the tool with",
        required=True,
        dest="locale"
    )
    args = parser.parse_args()
    xlsform = args.xlsform
    locale = args.locale.lower()
    main(xlsform=xlsform, locale=locale)
