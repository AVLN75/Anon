#!/usr/bin/python3
#-------------------------------------------------------------------------------
# Copyright 2023 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#-------------------------------------------------------------------------------

import json
import os
import io
import chardet

#-------------------------------------------------------------------------------

class i18nTools:
    """ i18n tools to set up Connect tool infrastructure """

    def __init__(self, locale, path):
        """ Constructor """
        self._supported_locales = ['ar', 'bs', 'bg', 'ca', 'zh-cn', 'zh-hk', 'zh-tw', 'hr', 'cs', 'da', 'nl', 'en', 'et', 'fi', 'fr',
                      'de', 'el', 'he', 'hu', 'id', 'it', 'ja', 'ko', 'lv', 'lt', 'nb', 'pl', 'pt-br', 'pt-pt', 'ro',
                      'ru', 'sr', 'sk', 'sl', 'es', 'sv', 'th', 'tr', 'uk', 'vi']
        
        self._locale = locale.replace("_", "-")

        self._path = path

    # -------------------------------------------------------------------------------

    def __str__(self):
        return self.i18n_locale()

    # -------------------------------------------------------------------------------

    def i18n_locale(self):
        """ Return the i18n locale """

        if self._locale in self._supported_locales:
            self._loc = self._locale
        elif self._locale[:2] in self._supported_locales:
            self._loc = self._locale[:2]
        else:
            self._loc = 'en'

        return self._loc
    
    # -------------------------------------------------------------------------------

    def load_json_strings(self):

        self.i18n_locale()

        try:
            file = io.open(os.path.join(self._path, 't9n', 'strings', self._loc + ".json"), 'rb').read()
            encoding = chardet.detect(file)['encoding']
            with open(os.path.join(self._path, 't9n', 'strings', self._loc + ".json"), encoding=encoding) as strings_json:
                strings = json.load(strings_json)
        except FileNotFoundError:
            self._loc = 'en'
            file = io.open(os.path.join(self._path, 't9n', 'strings', self._loc + ".json"), 'rb').read()
            encoding = chardet.detect(file)['encoding']
            with open(os.path.join(self._path, 't9n', 'strings', self._loc + ".json"), encoding=encoding) as strings_json:
                strings = json.load(strings_json)

        strings = {x: strings[x].replace("{{", "").replace("}}", "").replace("[[", "").replace("]]", "") for x in strings}

        return strings
    
    # -------------------------------------------------------------------------------

    def load_html_strings(self):
        self.i18n_locale()
        
        try:
            file = io.open(os.path.join(self._path, 't9n', 'html', self._loc + ".html"), 'rb').read()
            encoding = chardet.detect(file)['encoding']
            with open(os.path.join(self._path, 't9n', 'html', self._loc + ".html"), encoding=encoding) as html:
                html_string = html.read()
        except FileNotFoundError:
            self._loc = 'en'
            file = io.open(os.path.join(self._path, 't9n', 'html', self._loc + ".html"), 'rb').read()
            encoding = chardet.detect(file)['encoding']
            with open(os.path.join(self._path, 't9n', 'html', self._loc + ".html"), encoding=encoding) as html:
                html_string = html.read()

        return html_string


    