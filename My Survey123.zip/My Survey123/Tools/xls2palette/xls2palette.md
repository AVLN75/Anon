# xls2palette

Convert an XLSPalette template to a .palette file.

## Prerequisites

### Python 3.9 
* Windows Store: https://www.microsoft.com/en-us/p/python-39/9p7qfqmjrfp7
* Python website: https://www.python.org/downloads/

### Python Packages
* openpyxl: https://openpyxl.readthedocs.io/
  * `python3 -m pip install openpyxl`
* `python3 -m pip install chardet`

## Usage

`python3 xls2palette.py -i <filename>.xlsx`
