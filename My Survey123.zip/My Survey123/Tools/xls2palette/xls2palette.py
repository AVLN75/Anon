#!/usr/bin/python3
#-------------------------------------------------------------------------------
# Copyright 2023 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#-------------------------------------------------------------------------------

import os
import sys
import json
import argparse

from openpyxl import load_workbook
from openpyxl.workbook.workbook import Workbook
from openpyxl.worksheet.worksheet import Worksheet

dir_path = os.path.split(os.path.dirname(os.path.realpath(__file__)))[0]
sys.path.insert(0, os.path.join(dir_path, 'i18n_tools'))
from i18n import i18nTools

sys.stdout = open(1, 'w', encoding='utf-8', closefd=False)

#-------------------------------------------------------------------------------

kToolsetColumns:list = ["type", "label", "tool", "symbol", "textSymbol"]

kTITLE:str = "title"
kTYPE:str = "type"
kSYMBOL:str = "symbol"
kTEXTSYMBOL:str = "textSymbol"
kCOLOR:str = "color"
kSIZE:str = "size"
kWIDTH:str = "width"
kHEIGHT:str = "height"
kSTYLE:str = "style"
kFONT:str = "font"
kURL:str = "url"
kHORIZONTALALIGNMENT:str = "horizontalAlignment"
kVERTICALALIGNMENT:str = "verticalAlignment"

kEsriSLS:str = "esriSLS"
kEsriSLSSolid:str = "esriSLSSolid"
kEsriSLSDash:str = "esriSLSDash"
kEsriSLSDashDot:str = "esriSLSDashDot"
kEsriSLSDashDotDot:str = "esriSLSDashDotDot"
kEsriSLSDot:str = "esriSLSDot"
kEsriSLSNull:str = "esriSLSNull"

kStyleSLS:dict = {
    "null": kEsriSLSNull,
    "solid": kEsriSLSSolid,
    "dash": kEsriSLSDash,
    "dashdot": kEsriSLSDashDot,
    "dashdotdot": kEsriSLSDashDotDot,
    "dot": kEsriSLSDot
}

kEsriSFS:str = "esriSFS"
kEsriSFSBackwardDiagonal:str = "esriSFSBackwardDiagonal"
kEsriSFSCross:str = "esriSFSCross"
kEsriSFSDiagonalCross:str = "esriSFSDiagonalCross"
kEsriSFSForwardDiagonal:str = "esriSFSForwardDiagonal"
kEsriSFSHorizontal:str = "esriSFSHorizontal"
kEsriSFSNull:str = "esriSFSNull"
kEsriSFSSolid:str = "esriSFSSolid"
kEsriSFSVertical:str = "esriSFSVertical"

kStyleSFS:dict = {
    "backwarddiagonal": kEsriSFSBackwardDiagonal,
    "cross": kEsriSFSCross,
    "diagonalcross": kEsriSFSDiagonalCross,
    "forwardcross": kEsriSFSForwardDiagonal,
    "horizontal": kEsriSFSHorizontal,
    "null": kEsriSFSNull,
    "solid": kEsriSFSSolid,
    "vertical": kEsriSFSVertical
}

kEsriSMS:str = "esriSMS"
kEsriSMSCircle:str = "esriSMSCircle"
kEsriSMSCross:str = "esriSMSCross"
kEsriSMSDIamond:str = "esriSMSDiamond"
kEsriSMSSquare:str = "esriSMSSquare"
kEsriSMSX:str = "esriSMSX"
kEsriSMSTriangle:str = "esriSMSTriangle"

kStyleSMS:dict = {
    "circle": kEsriSMSCircle,
    "cross": kEsriSMSCross,
    "diamond": kEsriSMSDIamond,
    "square": kEsriSMSSquare,
    "x": kEsriSMSX,
    "triangle": kEsriSMSTriangle
}

kEsriPMS:str = "esriPMS"
kEsriPFS:str = "esriPFS"
kEsriTS:str = "esriTS"

kHorizontalAlignments:list = ["left", "center", "right"]
kVerticalAlignments:list = ["top","middle","bottom"]
kAnchors:dict = {
    "left": "left", 
    "center": "center", 
    "right": "right", 
    "top": "top", 
    "topleft": "topLeft",
    "topRight": "topRight",
    "bottom": "bottom", 
    "bottomleft": "bottomLeft",
    "bottomright": "bottomRight",
    "begin": "begin", 
    "end": "end"
}

kStyles:list = ["italic"]
kWeights:list = ["bold"]

#-------------------------------------------------------------------------------

def convertWorkbook(pathName, workbook:Workbook, strings):

    title = workbook.properties.title
    if not title:
        title = os.path.basename(os.path.splitext(pathName)[0])

    palette = {
        "title": title,
        "type": "drawTools"
    }

    if workbook.properties.description:
        palette["description"] = workbook.properties.description

    icon = parseIcon(workbook.properties.contentStatus)
    if icon:
        palette['icon'] = icon

    toolsets = []

    for worksheet in workbook.worksheets:
        toolset = convertWorksheet(worksheet, strings)
        if toolset:
            if len(toolset['tools']):
                print(strings['addingToolset'].format(title=toolset['title'], toolLength=len(toolset['tools'])))
                toolsets.append(toolset)
            else:
                print(strings['ignoreEmptyToolset'].format(title=toolset['title']))

    palette['toolsets'] = toolsets

    return palette

#-------------------------------------------------------------------------------

def convertWorksheet(worksheet:Worksheet, strings):
    header = None
    rows = []

    for row in worksheet.rows:
        if not header:
            header = [cell.value for cell in row]

            for toolsetColumn in kToolsetColumns:
                if not toolsetColumn in header:
                    print(strings['ignoreWorksheet'].format(worksheetTitle=worksheet.title, columnName=toolsetColumn))
                    return None
        
        else:
            values = {}
            for columnName in header:
                values[columnName] = row[header.index(columnName)].value

            rows.append(values)

    if not len(row):
        print(strings['emptyWorksheet'], worksheet.title)
        return None

    return parseToolset(worksheet.title, rows, strings)

#===============================================================================

def parseToolset(name, rows, strings) -> dict:
    nameValues = name.split("&")
    title = nameValues[0]
    toolset = {
        "title": title,
        "tools": []
    }

    if len(nameValues) > 1:
        icon = parseIcon(nameValues[1])
        if icon:
            toolset['icon'] = icon

    for row in rows:
        type = row.get(kTYPE)
        if not type:
            print(strings['noType'], row)
            continue

        label = row.get('label')
        symbolDef = row.get('symbol')

        if not label:
            print(strings['missingLabel'], row)
            continue

        tool = {
            "type": type,
            "label": label
        }

        symbol = None
        textSymbol = parseTextSymbol(row.get('textSymbol'))
        toolProperties = parseProperties(row.get('tool'), {})
        toolValues = toolProperties.values()


        if type == "line":
            symbol = parseLineSymbol(symbolDef)

            drawType = toolProperties.get(0)
            if drawType:
                tool['drawType'] = drawType

                if drawType and drawType.startswith("arrow"):
                    tool['drawType'] = 'line'

                    if "open" in toolValues:
                        arrowhead = "arrowheadOpen"
                    elif "closed" in toolValues:
                        arrowhead = "arrowheadClosed"
                    elif "filled" in toolValues:
                        arrowhead = "arrowheadFilled"
                    else:
                        arrowhead = "arrowheadOpen"

                    if arrowhead:
                        if drawType == "arrow" or drawType == "arrowto" or drawType == "arrowdouble":
                            tool['endDecoration'] = arrowhead

                        if drawType == "arrowfrom" or drawType == "arrowdouble":
                            tool['beginDecoration'] = arrowhead

        elif type == "area":
            symbol = parseFillSymbol(symbolDef)

            drawType = toolProperties.get(0)
            if drawType:
                tool['drawType'] = drawType

        elif type == "marker":
            symbol = parseMarkerSymbol(symbolDef)

        elif type == "text":
            pass

        else:
            print(strings['unknownType'].format(toolType=type))

        if symbol:
            tool[kSYMBOL] = symbol

        if textSymbol:
            tool['multiline'] = textSymbol['multiline'] or "multiline" in toolValues
            textSymbol.pop('multiline')

            anchor = textSymbol.get('anchor')
            if anchor:
                textSymbol.pop('anchor')
                if type != 'text':
                    tool['textAnchor'] = anchor

            tool[kTEXTSYMBOL] = textSymbol

        toolset['tools'].append(tool)

    return toolset

#-------------------------------------------------------------------------------

def parseLineSymbol(symbolDef:str) -> dict:
    properties = parseProperties(symbolDef)
    if not properties:
        return None

    symbol = {
        "type": kEsriSLS
    }

    if properties.get(kCOLOR):
        symbol[kCOLOR] = properties[kCOLOR]

    if properties.get(kWIDTH):
        symbol[kWIDTH] = int(properties[kWIDTH])

    style = properties.get('style')
    if style and style.startswith('[') and style.endswith(']'):
        style = json.loads(style)
    elif style:
        style = kStyleSLS.get(style)
    else:
        style = kEsriSLSSolid

    symbol[kSTYLE] = style

    return symbol

#-------------------------------------------------------------------------------

def parseFillSymbol(symbolDef:str) -> dict:
    properties = parseProperties(symbolDef)
    if not properties:
        return None

    symbol = {
        "type": kEsriSFS,
        "style": kEsriSFSSolid
    }

    if properties.get(kCOLOR):
        symbol[kCOLOR] = properties[kCOLOR]

    style = properties.get('style')
    if style:
        symbol[kSTYLE] = kStyleSFS.get(style)

    outline = {
        "type": kEsriSLS
    }

    outline = parseOutline(properties)
    if outline:
        symbol['outline'] = outline

    return symbol

#-------------------------------------------------------------------------------

def parseMarkerSymbol(symbolDef:str) -> dict:
    properties = parseProperties(symbolDef)
    if not properties:
        return None

    symbol = {
    }

    style = properties.get(0)
    if style:
        if '.' in style:
            type = kEsriPMS
            symbol[kURL] = style
        else:
            type = kEsriSMS
            style = kStyleSMS.get(style)
            if style:
                symbol[kSTYLE] = style

    else:
        if properties.get(kURL):
            type = kEsriPMS
            symbol[kURL] = properties.get(kURL)
        elif properties.get(kSTYLE):
            type = kEsriSMS
            style = kStyleSMS.get(properties.get(kSTYLE))
            if style:
                symbol[kSTYLE] = style


    symbol[kTYPE] = type

    if properties.get(kSIZE):
        size = int(properties.get(kSIZE))
        if type == kEsriSMS:
            symbol[kSIZE] = size
        else:
            symbol[kWIDTH] = size
            symbol[kHEIGHT] = size

    if type == kEsriSMS:
        if properties.get(kCOLOR):
            symbol[kCOLOR] = properties[kCOLOR]

    if type == kEsriSMS:
        outline = parseOutline(properties)
        if outline:
            symbol['outline'] = outline

    return symbol

#-------------------------------------------------------------------------------

def parseOutline(properties) -> dict:
    hasOutline = False

    outline = {
        "type": kEsriSLS
    }

    style = properties.get('outline.style')
    if style and style.startswith('[') and style.endswith(']'):
        outline[kSTYLE] = json.loads(style)
        hasOutline = True
    elif style:
        outline[kSTYLE] = kStyleSLS.get(style)
        hasOutline = True
    else:
        outline[kSTYLE] = kEsriSLSSolid

    if properties.get('outline.color'):
        outline[kCOLOR] = properties['outline.color']
        hasOutline = True

    if properties.get('outline.width'):
        outline[kWIDTH] = int(properties['outline.width'])
        hasOutline = True

    if hasOutline:
        return outline
    else:
        return None
    

#-------------------------------------------------------------------------------

def parseTextSymbol(symbolDef:str) -> dict:
    properties = parseProperties(symbolDef)
    if not properties:
        return None

    textSymbol = {
        "type": kEsriTS
    }

    if properties.get(kCOLOR):
        textSymbol[kCOLOR] = properties[kCOLOR]

    if properties.get("halo.color"):
        textSymbol['haloColor'] = properties.get("halo.color")

    if properties.get("halo.size"):
        textSymbol['haloSize'] = properties.get("halo.size")

    if properties.get("background"):
        textSymbol['backgroundColor'] = properties.get("background")

    if properties.get("border.color"):
        textSymbol['borderLineColor'] = properties.get("border.color")

    if properties.get("border.size"):
        textSymbol['borderLineSize'] = properties.get("border.size")

    if properties.get("alignment"):
        values = properties.get("alignment").split(",")

        for value in values:
            if value in kHorizontalAlignments:
                textSymbol[kHORIZONTALALIGNMENT] = value
        
            if value in kVerticalAlignments:
                textSymbol[kVERTICALALIGNMENT] = value

    font = {}
    if properties.get(kSIZE):
        font[kSIZE] = int(properties[kSIZE])

    values = properties.values()
    for value in values:
        if value in kStyles:
            font['style'] = value
    
        if value in kWeights:
            font['weight'] = value

    textSymbol[kFONT] = font

    value = properties.get("anchor")
    if value and value in kAnchors.keys():
        textSymbol['anchor'] = kAnchors.get(value)
    
    textSymbol['multiline'] = 'multiline' in values

    return textSymbol

#-------------------------------------------------------------------------------

def parseProperties(propertiesDef:str, defaultProperties:dict = None) -> dict:
    if not propertiesDef:
        return defaultProperties

    pairs = propertiesDef.split("&")
    if not len(pairs):
        return defaultProperties

    properties = {}

    arg = 0
    for pair in pairs:
        if pair:
            keyValue = pair.split("=",1)
            if len(keyValue) > 1:
                properties[keyValue[0]] = parseValue(keyValue[1])
            else:
                properties[arg] = parseValue(keyValue[0])
                arg += 1

    #print("def:", propertiesDef, "properties:", properties)

    return properties

#-------------------------------------------------------------------------------

def parseValue(value:str):
    if not value:
        return None

    return value.strip('"')

#-------------------------------------------------------------------------------

def parseIcon(propertiesDef):
    properties = parseProperties(propertiesDef)
    if not properties:
        return None

    iconValue = properties.get('icon')
    if not iconValue:
        return None

    if '.' in iconValue:
        icon = {
            "url": iconValue
        }
    else:
        icon = {
            "name": iconValue
        }

    return icon

#===============================================================================

argsParser = argparse.ArgumentParser()

argsParser.add_argument(
    "-i",
    help="Input XLSX palette",
    required=True,
    dest="xlFile"
)

argsParser.add_argument(
    "-o",
    help="Output palette",
    required=False,
    dest="paletteFile"
)
argsParser.add_argument(
    "-l",
    help="Please specify the locale to run the tool with",
    required=True,
    dest="locale"
)

args = argsParser.parse_args()

xlFile = args.xlFile
paletteFile = args.paletteFile
locale = args.locale.lower()

path = os.path.abspath(os.path.dirname(__file__))
i18n = i18nTools(locale, path)
strings = i18n.load_json_strings()

if not paletteFile:
    fileName, _ = os.path.splitext(os.path.basename(xlFile))
    paletteFile = os.path.join(os.path.dirname(xlFile), fileName + ".palette")


print(strings['initializationMessage'])
print("---------------------------------------------------------")

print(strings['input'], xlFile)
print(strings['output'], paletteFile)

try:
    workbook = load_workbook(filename=xlFile, read_only=True, data_only=True)
except Exception as e:
    print(strings['readError'], e)
    sys.exit(-1)

#print(workbook.properties)

palette = convertWorkbook(xlFile, workbook, strings)

try:
    with open(paletteFile, 'w', encoding='utf-8') as paletteFile:
        json.dump(palette, paletteFile, ensure_ascii=False, indent=4, sort_keys=False)
except Exception as e:
    print(strings['writeError'], e)
    sys.exit(-2)

print(strings['conversionCompleted'])

sys.exit()
