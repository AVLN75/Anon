# Convert chocie lists to CSV

Converts your choice lists to CSV files.

## Prerequisites

### Python 3.9 
* Windows Store: https://www.microsoft.com/en-us/p/python-39/9p7qfqmjrfp7
* Python website: https://www.python.org/downloads/

### Python Packages
* `python3 -m pip install openpyxl`
* `python3 -m pip install requests`
* `python3 -m pip install chardet`

## Usage

`python3 choices2csv.py -x <XLSFormPath> -l <locale>`
