#!/usr/bin/python3
# -------------------------------------------------------------------------------
# Copyright 2023 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# -------------------------------------------------------------------------------

import sys
import os
dir_path = os.path.split(os.path.dirname(os.path.realpath(__file__)))[0]
sys.path.insert(0, os.path.join(dir_path, 'i18n_tools'))
sys.path.insert(0, os.path.join(dir_path, 'translationtools'))
from openpyxl import load_workbook
import csv
import argparse
import warnings
from i18n import i18nTools
from translationtools import TranslationTools

sys.stdout = open(1, 'w', encoding='utf-8', closefd=False)

# Pre 3.10 surveys had a different implementation of the data validation which throws a warning message.
# This suppresses that message
warnings.simplefilter("ignore")

# -------------------------------------------------------------------------------


def id_table_list(survey_sheet, survey_header_row):
    ''' Identifies groups that use the table-list appearance '''
    ignore_lists = []
    if "type" in survey_header_row and "appearance" in survey_header_row:
        for q_type, appearance in zip(survey_sheet.iter_rows(min_row=2, max_row=survey_sheet.max_row,
                                                             min_col=survey_header_row.index(
                                                                 "type") + 1,
                                                             max_col=survey_header_row.index("type") + 1),
                                      survey_sheet.iter_rows(min_row=2, max_row=survey_sheet.max_row,
                                                             min_col=survey_header_row.index(
                                                                 "appearance") + 1,
                                                             max_col=survey_header_row.index("appearance") + 1)):
            if q_type[0].value == "begin group" and appearance[0].value == "table-list":
                for question in survey_sheet.iter_rows(min_row=q_type[0].row, max_row=survey_sheet.max_row,
                                                       min_col=survey_header_row.index(
                                                           "type") + 1,
                                                       max_col=survey_header_row.index("type") + 1):
                    if str(question[0].value).startswith('select_one ') or str(question[0].value).startswith('select_multiple '):
                        type_parts = question[0].value.split(" ")
                        if type_parts[1] not in ignore_lists:
                            ignore_lists.append(type_parts[1])
                    elif question[0].value == "end group":
                        break

    return ignore_lists

# -------------------------------------------------------------------------------


def id_rank(survey_sheet, survey_header_row):
    ''' Identifies rank question types '''
    ignore_lists = []
    if "type" in survey_header_row:
        for q_type in survey_sheet.iter_rows(min_row=2, max_row=survey_sheet.max_row,
                                             min_col=survey_header_row.index(
                                                 "type") + 1,
                                             max_col=survey_header_row.index("type") + 1):
            if str(q_type[0].value).startswith('rank '):
                type_parts = q_type[0].value.split(" ")
                if type_parts[1] not in ignore_lists:
                    ignore_lists.append(type_parts[1])
    return ignore_lists

# -------------------------------------------------------------------------------


def id_search_appearance(survey_sheet, survey_header_row):
    ''' Identifies questions using the search() appearance'''
    search_list = []
    appearance_column_idx = survey_header_row.index('appearance')
    appearance_column = tuple(survey_sheet.columns)[appearance_column_idx]
    for a in appearance_column:
        if a.value is not None and 'search' in a.value:
            search_row = survey_sheet[a.row]
            for cell in search_row:
                str_cell = str(cell.value)
                if str_cell is not None and (str_cell.startswith('select_one ') or str_cell.startswith('select_multiple ')):
                    search_list.append(str_cell.split(" ")[1])
    return search_list

# -------------------------------------------------------------------------------


def id_choice_lists(choices_ws, choices_hr, strings, dir):
    ''' Identifies choice lists marked for export '''
    if "esri_tool_convert_csv" not in choices_hr:
        print(strings['missingHeader'].format(html_dir=dir))
        exit()
    
    choice_lists = list(set([list_name[0].value for list_name, flag in zip(choices_ws.iter_rows(min_row=2, max_row=choices_ws.max_row, min_col=choices_hr.index("list_name")+1, max_col=choices_hr.index("list_name")+1), choices_ws.iter_rows(min_row=2,
                        max_row=choices_ws.max_row, min_col=choices_hr.index("esri_tool_convert_csv")+1, max_col=choices_hr.index("esri_tool_convert_csv")+1)) if list_name[0].value is not None and list_name[0].value != "" and list_name[0].value != " " and flag[0].value is not None and str(flag[0].value).lower() == 'yes']))
    if len(choice_lists) == 0:
        print(strings['noChoices'].format(html_dir=dir))
        exit()
    list_names = list(choices_ws.iter_cols(min_col=1, max_col=1,
                      min_row=2, max_row=choices_ws.max_row, values_only=True))[0]
    choices = {}
    for cl in choice_lists:
        choices.update({cl: {"start": (list_names.index(
            cl)) + 2, "end": (len(list_names) - list_names[::-1].index(cl) - 1) + 2}})    
    return choices

# -------------------------------------------------------------------------------


def aggregate_choice_lists(choices_sheet, full_hr, export_list, table_list, search_list, rank):
    ''' Aggregates choice lists marked for export as a dictionary '''
    choice_lists = {}
    unsupported_lists = []
    for list_name, idxof in export_list.items():
        if list_name not in table_list and list_name not in search_list and list_name not in rank:
            choice_list_col_header = []
            choice_list_rows = []
            for col, colidx in zip(choices_sheet.iter_cols(min_col=2, min_row=idxof['start'], max_row=idxof['end'], values_only=True), range(1, len(full_hr))):
                if not (all(x is None for x in col)) and full_hr[colidx] != "esri_tool_convert_csv":
                    choice_list_col_header.append(full_hr[colidx])
                    for val, idx in zip(col, range(len(col))):
                        if colidx > 1:
                            choice_list_rows[idx].append(val)
                        else:
                            choice_list_rows.append([val])

            choice_lists.update(
                {list_name: {"header_row": choice_list_col_header, "values": choice_list_rows}})
        else:
            unsupported_lists.append(list_name)
    return (choice_lists, unsupported_lists)

# -------------------------------------------------------------------------------


def write_csv(choice_lists, media_folder):
    ''' Generates the CSV's in the media folder '''
    csv_files = []
    for list_name in choice_lists:
        with open(os.path.join(media_folder, '{0}.csv'.format(list_name)), 'w', newline='', encoding="utf-8-sig") as csv_out:
            csv_writer = csv.writer(csv_out)
            csv_writer.writerow(choice_lists[list_name]['header_row'])
            for r in choice_lists[list_name]['values']:
                csv_writer.writerow(r)
            csv_files.append(list_name)
    return csv_files

# -------------------------------------------------------------------------------


def swizzle_select(survey_sheet, survey_header_row, csv_files):
    ''' Migrates select_one/select_multiple to select_x_from_file '''
    type_column_idx = survey_header_row.index('type')
    type_column = tuple(survey_sheet.columns)[type_column_idx]
    for c in type_column:
        if c.value is not None and 'or_other' not in c.value and (c.value.startswith('select_one ') or c.value.startswith('select_multiple ')):
            type_parts = c.value.split(" ")
            if type_parts[1] in csv_files:
                type_parts[0] = '{0}_from_file'.format(type_parts[0])
                type_parts[1] = '{0}.csv'.format(type_parts[1])
                c.value = " ".join(type_parts)
        elif c.value is not None and 'or_other' in c.value:
            type_parts = c.value.split(" ")
            csv_files.remove(type_parts[1])

# -------------------------------------------------------------------------------


def id_choice_deletion(choices_header_row, csv_files, choices_backup):
    ''' Identifies choice lists that have been exported for removal '''
    delete_ranges = []
    list_names = tuple(choices_backup.columns)[
        choices_header_row.index('list_name')]
    this_range = {"start": None, "count": None}
    this_row = 1
    for l in list_names:
        if l.value is not None and l.value not in csv_files:
            # Finish out the current range if present
            if this_range["start"] is not None:
                this_range["count"] = this_row - this_range["start"]
                delete_ranges.append(this_range)
                this_range = {"start": None, "count": None}
        elif l.value is not None:
            if this_range["start"] is None:
                this_range["start"] = this_row
        this_row = this_row + 1
    if this_range["start"] is not None:
        this_range["count"] = this_row - this_range["start"]
        delete_ranges.append(this_range)
    return delete_ranges

# -------------------------------------------------------------------------------


def format_results_ws(results_ws, strings, rtl):
    from openpyxl.styles import Font, colors, Alignment
    from openpyxl.worksheet.table import Table, TableStyleInfo
    if rtl is False:
        results_ws.column_dimensions['A'].width = 100
        results_ws.column_dimensions['B'].width = 50
        results_ws.column_dimensions['C'].width = 13
    else:
        results_ws.column_dimensions['A'].width = 13
        results_ws.column_dimensions['B'].width = 50
        results_ws.column_dimensions['C'].width = 100

    for row in range(2, results_ws.max_row + 1):
        if rtl is False:
            hyperlink_cell = results_ws.cell(row, 3)
        else:
            hyperlink_cell = results_ws.cell(row, 1)
        link = hyperlink_cell.value
        hyperlink_cell.value = strings['headerLearnMore']
        hyperlink_cell.hyperlink = link
        hyperlink_cell.style = "Hyperlink"
        hyperlink_cell.font = Font(size=11, u='single', color=colors.BLUE)
        
        if rtl is False:
            message_cell = results_ws.cell(row, 1)
        else:
            message_cell = results_ws.cell(row, 3)
        message_cell.alignment = Alignment(wrap_text=True)

    tab = Table(displayName="Table1", ref=f"A1:C{results_ws.max_row}")
    style = TableStyleInfo(name='TableStyleMedium4', showRowStripes=True, showColumnStripes=False)
    tab.tableStyleInfo = style
    results_ws.add_table(tab)

# -------------------------------------------------------------------------------


def warn_unsupported_choice_lists(locale, strings, dir_path, choicelists, dir):
    ''' Warns the user if they've marked choice lists for export but are used in unsupported questions '''
    import openpyxl
    import datetime
    # Warn user that some choice lists will not be exported
    debug_path = os.path.join(dir_path, "debug", "convertchoicelists")
    if not os.path.exists(debug_path):
        os.makedirs(debug_path)
    results_xlsx = os.path.join(debug_path,
                            f"convert_choices-{str(datetime.datetime.now().strftime('%Y%m%d%H%M%S'))}.xlsx")
    results_wb = openpyxl.Workbook()
    results_ws = results_wb.active
    results_ws.title = strings['worksheetName']
    if locale[:2] not in ['ar', 'he']:
        results_ws.append([strings['headerMessage'], strings['headerChoiceLists'], strings['headerLearnMore']])
        results_ws.append([strings['warningMessage'], ", ".join(choicelists), "https://doc.arcgis.com/en/survey123/desktop/create-surveys/connecttools.htm"])
        rtl = False
    else:
        results_ws.append([strings['headerLearnMore'], strings['headerChoiceLists'], strings['headerMessage']])
        results_ws.append(["https://doc.arcgis.com/en/survey123/desktop/create-surveys/connecttools.htm", ", ".join(choicelists), strings['warningMessage']])
        rtl = True
    format_results_ws(results_ws, strings, rtl)
    results_wb.save(results_xlsx)
    print(strings["choiceListsMessage"].format(html_dir=dir, xlsxPath=str(results_xlsx), xlsxName=os.path.basename(results_xlsx)))

# -------------------------------------------------------------------------------
    

def main(xlsform, locale):
    """ main """

    path = os.path.abspath(os.path.dirname(__file__))
    i18n = i18nTools(locale, path)
    strings = i18n.load_json_strings()
    tools = TranslationTools(strings, "")

    dir = "rtl" if str(i18n) == "ar" or str(i18n) == "he" else "ltr"

    (dir_path, xlsx_name) = os.path.split(xlsform)
    media_folder = os.path.join(dir_path, "media")
    if not os.path.exists(media_folder):
        os.mkdir(media_folder)
    print(strings['workingMessage'].format(html_dir=dir, xlsx_name=xlsx_name))
    
    try:
        open(xlsform, "a")
    except PermissionError:
        print(strings['fileOpen'].format(html_dir=dir))
        exit()

    wb = load_workbook(filename=xlsform)
    survey_sheet = wb['survey']
    choices_sheet = wb['choices']
    survey_header_row = [c.value for c in survey_sheet[1]]
    choices_header_row = [c.value for c in choices_sheet[1]]
    
    # Identify choice lists marked for export
    export_list = id_choice_lists(choices_sheet, choices_header_row, strings, dir)

    # Scan survey worksheet to identify questions that don't support select_from_file
    search_list = id_search_appearance(survey_sheet, survey_header_row)
    table_list = id_table_list(survey_sheet, survey_header_row)
    rank = id_rank(survey_sheet, survey_header_row)

    # Obtain a dictionary of rows in the choices worksheet
    choice_lists = aggregate_choice_lists(
        choices_sheet, choices_header_row, export_list, table_list, search_list, rank)
    if len(choice_lists[1]) > 0:
        warn_unsupported_choice_lists(locale, strings, dir_path, choice_lists[1], dir)

    # Write CSV files
    csv_files = write_csv(choice_lists[0], media_folder)
    
    # Update Survey worksheet creating select_x_from_file listname.csv
    swizzle_select(survey_sheet, survey_header_row, csv_files)

    # Create a backup choices sheet
    choices_backup = wb.copy_worksheet(choices_sheet)
    wb.move_sheet(choices_backup, -abs(len(wb.sheetnames)-3))
    choices_backup.title = 'choices_backup'

    # Identify the ranges of rows that need to be deleted
    delete_ranges = id_choice_deletion(
        choices_header_row, csv_files, choices_sheet)

    # As deleting rows alters the row counts, reverse the ranges to start from the end and delete up to the begining
    delete_ranges.reverse()
    for rng in delete_ranges:
        choices_sheet.delete_rows(rng["start"], rng["count"])

    tools._rebuild_datavalidation(wb)
    wb.save(xlsform)
    wb.close()

# -------------------------------------------------------------------------------


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-x",
        help="Please specify the path to the XLSForm",
        required=True,
        dest="xlsform"
    )
    parser.add_argument(
        "-l",
        help="locale",
        required=True,
        dest="locale"
    )
    args = parser.parse_args()
    xlsform = args.xlsform
    loc = args.locale.lower()
    main(xlsform=xlsform, locale=loc)
